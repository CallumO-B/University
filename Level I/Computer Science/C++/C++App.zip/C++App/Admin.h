#pragma once
#include <iostream>
#include "Menu.h"
#include "Database.h"

using namespace std;
using namespace Menus;
using namespace Database_Application;

class Admin
{

public:


	void admin_menu(Database^ database);

private:

	Menu menu;

	void create_new_user(Database^ database);
	
	void remove_user(Database^ database);

	void clear_inputstream();
};