#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <iostream>
#include <string>
#include "Database.h"
#include "Menu.h"
#include "Date.h"

using namespace Database_Application;
using namespace Menus;
using namespace std;
class Course

{
public:

	Course();
	void CourseMenu(Database^ db);
	void addCourse(Database^ db, string programme_id);

	string search_for_course(Database^ database);

private:

	Menu menu;
	Date date;

	//Course Variables
	string course_code;
	string Course_name;
	string level;
	string credit_ammount;

	//Assessment Variables
	int num_of_assessments;

	string* assessment_name;
	string* assessment_id;
	string* assessment_deadline;
	string* research_task;

	//Assignment Variables
	string programme_name;
	string sweighting[4];
	int weighting[4];
	int total_weighting;

	//Course();
	//update menu
	void updateMenu(Database^ db);
	///////////////////////////////////////
	void updateCourseName(Database^ db);
	void updateCourseLevel(Database^ db);
	void updateCourseCreditAmmount(Database^ db);
	void updateAssessmentName(Database^ db);
	//Get functions
	void addCourse(Database^ db);
	void addAssessment(Database^ db);
	void getAssessmentAssignment(Database^db);
	void getCreditValue(string& credit_ammount);
	void getLevel(string& level);

	//show functions
	void showCourse(const bool& message);
	void showAssessment(const bool& message, int num);
	//save functions
	void saveCourse(Database^ db);
	void saveAssessment(Database^ db, int num);
	void saveAssessmentAssignment(Database^db);
	//checks weighting is equal to 100
	int checkWeighting(int total_weighting, int weighting[]);
	//deletes course and assessments assigned to it 
	void removeCourse(Database^ db);
	void removeAssessment(Database^ db);
	//search fuctions
	void SearchMenu(Database^db);
	///////////////////////course search/////////////////////////////////////
	void searchAllCourses(Database^db);
	void searchForCourseCode(Database^ db);
	void searchForCourseName(Database^ db);
	//////////////////assessment search////////////////////////////
	void searchForAssessmetsAssignedToCourse(Database^ db);
	void searchAllAssessments(Database^db);
	void searchForAssessmentName(Database^ db);
	void searchForAssessmnetId(Database^ db);

	//misc functions
	void flushInputStream();
	void informationMessageContinue(const string& s);
	void clearScreen();

};