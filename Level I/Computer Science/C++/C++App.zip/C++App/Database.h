
/*
*	Database Class
*	
*	This class enables manipulation of a database. 
*	It allows commands to be sent to a MySQL database
*	It can also read any data sent back by the database, 
*	including query results and errors/exceptions.
*
*	Keiran Brown - 15000194
*
*/

#pragma once
#include <string>
#include <vector>

typedef short unsigned int shuint;

namespace Database_Application
{
	
	using namespace std;
	using namespace System;
	using namespace System::Collections;
	using namespace MySql::Data::MySqlClient;

	ref class Database

	{
	public:

		

		Database();

		//SELECT column FROM table.	Values returned to passed vector by reference.
		void sql_select(string column, string table, vector<string> &values_to_return);
		//SELECT column FROM table WHERE specify_column=specify_value.	Values returned to passed vector by reference.
		void sql_select(string column, string table, string specify_column, string specify_value, vector<string> &values_to_return);

		//INSERT INTO table (columns[n], ...) VALUES (values[n], ...).
		void sql_insert(const string columns[], int columns_size, string table, const string values[], int values_size);

		//UPDATE table SET specify_column=new_value WHERE query_column=query_value.
		void sql_update(string specify_column, string table, string new_value, string query_column, string query_value);

		//DELETE FROM table WHERE specify_column=specify_value.
		void sql_delete(string table, string specify_column, string specify_value);

		void change_database(string database_name);
		void login();


		void keyword_search(const string search_column, const string table, vector<string> &rows, bool return_all_fields);
		bool search_string(string key_term, string comparison);

		//These allow you to pass your own SQL directly to the database.
		//Perform an SQL action that will return values (atm; this only return a single column, I am still working out how to fix!).
		void perform_sql_action(string sql_command, vector<string> &return_values);
		//Perform an SQL action that returns nothing (everything but SELECT).
		void perform_sql_action(string sql_command);

		int get_last_exception();

		/*
		ERRORS are not returnes to the passed vector, they are printed to the system console
		so both "perform_sql_actions(args)" functions will return any errors.
		*/

	private:
		

		MySqlConnection^ conn;
		MySqlDataReader^ dataReader;
		int last_exception;



	};

}

