#include "Admin.h"


void Admin::admin_menu(Database^ database)
{

	clear_inputstream();

	int choice = 1;

	do {

		string options[] = {

			"Return",
			"Create User",
			"Delete User"

		};

		choice = menu.create_menu("Please choose an option", options, 3, true);

		switch (choice)
		{

		case 0:

			return;

			break;

		case 1:

			create_new_user(database);

			break;

		case 2:

			remove_user(database);

			break;

		}
	} while (choice > 0);

}

void Admin::create_new_user(Database^ database)
{

	cout << "Press enter to continue" << endl;
	clear_inputstream();

	cout << "Spaces not allowed in any input" << endl;

	cout << "Please enter new user's username" << endl;
	string user;
	cin >> user;

	clear_inputstream();

	cout << "Please enter new the user's password" << endl;
	string password;
	cin >> password;

	database->perform_sql_action("CREATE USER '" + user + "'@'localhost' IDENTIFIED BY '" + password + "'");

	string options[] = {

		"Student",
		"Tutor",
		"Admin"

	};

	int choice = menu.create_menu("Which type of user is this?", options, 3, true);

	switch (choice)
	{

	case 0:

		database->perform_sql_action("GRANT SELECT ON uni_database.programme TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT SELECT ON uni_database.course TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT SELECT, INSERT, UPDATE ON uni_database.student TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT SELECT ON uni_database.student_programme TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT SELECT ON uni_database.student_course TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT SELECT ON uni_database.programme_course TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT SELECT ON uni_database.course_assessment TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT SELECT ON uni_database.student_assessment TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT SELECT ON uni_database.programme_research TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT SELECT ON uni_database.uni_information TO '" + user + "'@'localhost'");



		break;

	case 1:


		database->perform_sql_action("GRANT ALL ON uni_database.assessment TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT ALL ON uni_database.student_programme TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT ALL ON uni_database.student_course TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT ALL ON uni_database.programme_course TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT ALL ON uni_database.course_assessment TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT ALL ON uni_database.student_assessment TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT ALL ON uni_database.programme_research TO '" + user + "'@'localhost'");

		database->perform_sql_action("GRANT SELECT, INSERT ON uni_database.student TO '" + user + "'@'localhost'");

		database->perform_sql_action("GRANT SELECT, UPDATE ON uni_database.course TO '" + user + "'@'localhost'");

		database->perform_sql_action("GRANT SELECT ON uni_database.programme TO '" + user + "'@'localhost'");
		database->perform_sql_action("GRANT SELECT ON uni_database.uni_information TO '" + user + "'@'localhost'");


		break;


	case 2:

		database->perform_sql_action("GRANT ALL PRIVILEGES ON *.* TO '" + user + "'@'localhost' WITH GRANT OPTION");
		
		break;

	}

	cout << "User created";

}

void Admin::remove_user(Database^ database)
{

	cout << "Press enter to continue" << endl;
	clear_inputstream();

	cout << "Please Specify Username" << endl;
	string user;
	cin >> user;

	int choice = menu.yes_no_menu("Are you sure you would like to remove this student?");

	if(choice)
		database->perform_sql_action("DROP USER '" + user + "'@'localhost'");
	else
	{

		cout << "User not removed" << endl;
		return;

	}

	cout << "User removed" << endl;
	return;


}

void Admin::clear_inputstream()
{

	//Clear input buffer and ignore all chars until a newline.
	cin.clear();
	cin.ignore(INT_MAX, '\n');

	return;

}