#include "Backup.h"



void Backup::backup_menu(Database^ database)
{

	string options[] = {

		"Return",
		"Backup",
		"Restore"

	};

	int choice = menu.create_menu("Please choose an option", options, 3, true);

	switch (choice)
	{

	case 0:

		return;

		break;

	case 1:

		backup(database);

		break;

	case 2:

		restore(database);

		break;

	}

}

void Backup::backup(Database^ database)
{

	clear_inputstream();

	string options[] = {

		"Return",
		"All",
		"Students",
		"Courses",
		"Programmes"

	};

	int choice = menu.create_menu("What would you like to backup?", options, 5, true);

	switch (choice)
	{

	case 0:

		return;

		break;
	
	case 1:

		backup_all(database);

		break;

	case 2:

		backup_students(database);

		break;


	case 3:

		backup_courses(database);

		break;

	case 4:

		backup_programmes(database);

		break;

	}
	

}

void Backup::backup_all(Database^ database)
{

	//Backup all items.
	backup_students(database);
	backup_courses(database);
	backup_programmes(database);

}

void Backup::backup_students(Database^ database)
{

	vector<string> students;

	//Get Todays date for file name.
	Date today;
	today.set_to_current_date();

	//Open a new file for writing.
	ofstream student_file;
	student_file.open("Student_backup_" + to_string(today.get_day()) + "-" + to_string(today.get_month()) + "-" + to_string(today.get_year()) + ".txt", ios::beg);

	//Check for failures.
	if (student_file.fail())
	{

		cout << "File opening Failed" << endl;
		return;

	}

	//Get all students from database.
	database->sql_select("*", "student", students);

	//Check if vector is empty, return if so.
	if (students.size() == 0)
	{

		cout << "No Students in Database" << endl;
		return;

	}

	//Output each student row to the file.
	for (unsigned int i = 0; i < students.size(); i++) {

		student_file << students[i] << endl;

	}
	
	//Inform user of completion.
	cout << "Students Backed Up to Student_Backup File" << endl;

	return;

}

void Backup::backup_courses(Database^ database)
{

	vector<string> courses;

	//Get Todays date.
	Date today;
	today.set_to_current_date();

	//Open file for writing.
	ofstream course_file;
	course_file.open("Course_backup_" + to_string(today.get_day()) + "-" + to_string(today.get_month()) + "-" + to_string(today.get_year()) + ".txt", ios::beg);

	//Get all courses from database.
	database->sql_select("*", "course", courses);

	//Check for no courses in database, return if so.
	if (courses.size() == 0)
	{

		cout << "No Courses in Database" << endl;
		return;

	}

	//Print each course row to file.
	for (unsigned int i = 0; i < courses.size(); i++) {

		course_file << courses[i] << endl;

	}

	//Inform user of completion.
	cout << "Courses Backed Up to Student_Backup File" << endl;

	return;

}

void Backup::backup_programmes(Database^ database)
{

	vector<string> programmes;

	//Get todays date for file name.
	Date today;
	today.set_to_current_date();

	//Open file for writing to.
	ofstream programme_file;
	programme_file.open("Programme_backup_" + to_string(today.get_day()) + "-" + to_string(today.get_month()) + "-" + to_string(today.get_year()) + ".txt", ios::beg);

	//Get all programmes from database.
	database->sql_select("*", "programme", programmes);

	//Check for if there are no programmes, return if so.
	if (programmes.size() == 0)
	{

		cout << "No Students in Database" << endl;
		return;

	}

	//Print all programmes to a file.
	for (unsigned int i = 0; i < programmes.size(); i++) {

		programme_file << programmes[i] << endl;

	}

	//Inform user of completion.
	cout << "Programmes Backed Up to Student_Backup File" << endl;

	return;

}

void Backup::restore(Database^ database)
{

	string options[] = {

		"All",
		"Students",
		"Courses",
		"Programmes"

	};

	//Ask user which they would like to restore.
	int choice = menu.create_menu("Which would you like to restore?", options, 4, true);


	//Go to chosen restoration function.
	switch (choice)
	{

	case 0:

		restore_all(database);

		break;

	case 1:

		restore(database, "STUDENT");

		break;

	case 2:

		restore(database, "COURSE");

		break;

	case 3:

		restore(database, "PROGRAMME");

		break;

	}

	return;
}

void Backup::restore_all(Database^ database)
{

	//Restore all items.
	restore(database, "STUDENT");
	restore(database, "COURSE");
	restore(database, "PROGRAMME");

	return;

}

void Backup::restore(Database^ database, string type)
{

	ifstream file;
	
	//Ask user about file name.
	cout << "Press enter to continue" << endl;
	clear_inputstream();

	cout << "Please enter name of backup file" << endl;
	string file_name;
	getline(cin, file_name);

	//Open file for reading.
	file.open(file_name, ios::beg);

	//Check for failures, return if so.
	if (file.fail())
	{

		cout << "Failed to open file" << endl;
		return;

	}

	//Vector to return each row to.
	vector<string> rows;

	//values in each row.
	string * values;

	//Which table and values used.
	string test_value, test_table;

	//Dynamic array for field names.
	string * fields;

	int field_no;

	//Set parameters according to table selected.
	if(type == "STUDENT")
	{

		//Number of fields.
		field_no = 9;

		test_value = "student_id";
		test_table = "student";

		//Dynamic arrays for storage.
		fields = new string[9];
		values = new string[9];


		//Field Headers.
		fields[0] = "student_id";
		fields[1] = "first_name";
		fields[2] = "last_name";
		fields[3] = "house_number";
		fields[4] = "street";
		fields[5] = "town_city";
		fields[6] = "postcode";
		fields[7] = "date_of_birth";
		fields[8] = "visa_expiry";

	}
	else if (type == "COURSE")
	{

		field_no = 4;

		test_value = "course_code";
		test_table = "course";

		fields = new string[4];
		values = new string[4];

		fields[0] = "course_code";
		fields[1] = "course_name";
		fields[2] = "course_level";
		fields[3] = "credit_amount";

	}
	else if (type == "PROGRAMME")
	{

		field_no = 7;

		test_value = "programme_id";
		test_table = "programme";

		fields = new string[7];
		values = new string[7];

		fields[0] = "programme_id";
		fields[1] = "programme_name";
		fields[2] = "degree_type";
		fields[3] = "attendance_mode";
		fields[4] = "begin_date";
		fields[5] = "end_date";
		fields[6] = "date_created";

	}
	
	//Read entire file for values.
	while (!file.eof())
	{

		//Current row.
		string row;

		//Get the next line from file.
		getline(file, row);

		//Extract the values from the string.
		extract_values(values, row, field_no);
		
		//Insert values into correct table.
		database->sql_insert(fields, field_no, test_table, values, field_no);

	}

}


void Backup::encrypt(string & in_string)
{
	
	cout << "Enter the password to set for this file" << endl;
	string password;
	cin >> password;

	for (int i = 0; i < in_string.length(); i++)
	{

		for (int j = 0; j < password.length(); j++)
			in_string[i] += password[j];

	}


}

void Backup::decrypt(string & in_string)
{

	cout << "Enter the password to set for this file" << endl;
	string password;
	cin >> password;

	for (int i = 0; i < in_string.length(); i++)
	{

		for (int j = 0; j < password.length(); j++)
			in_string[i] -= password[j];

	}

}

void Backup::extract_values(string values_arr[], const string values_str, const int size)
{

	//String to store any value that is obtained and an integer to track which value is being taken.
	string current_value;
	int current_index = 0;

	//Get each value in the string in turn.
	for (unsigned int i = 0; i < values_str.length(); i++)
	{

		//If a delimiter is encountered, then another value has been found, increment counter.
		if (values_str[i] == ';')
		{
			//Check for empty values and put this into the string.
			if (current_value.length() == 0)
				values_arr[current_index] == "NULL";
			else //Otherwise, enter the value into the array at the correct index.
				values_arr[current_index] = current_value;
			current_value = "";
			current_index++;

		}
		else //Add on each character that isnt a delimiter to the current value.
			current_value += values_str[i];


	}



}

void Backup::clear_inputstream()
{

	//Clear input buffer and ignore all chars until a newline.
	cin.clear();
	cin.ignore(INT_MAX, '\n');

	return;

}