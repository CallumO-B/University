#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <array>
#include "Student.h"
#include "Database.h"
#include "Mark.h"

typedef string * strptr;

class Transcript {

public:

	//Displays a transcript for a particular student.
	string display_transcript(Database^ database, const string student_id);
	//Precondition: Database instance initialised, student ID is initialised with a student's ID that exists.
	//Postcondition: Will display the transcript of the student based on the passed student ID.

	//Print out a batch of transcripts of each of the specified students in the array.
	void display_transcript(Database^ database, const string student_ids[], const int number_of_ids);
	//Precondition: Database instance initialised, array of student IDs filled with strings containing student IDs and an integer specifying the size of the array all initialised also.
	//Postcondition: A transcript will be displayed for each student ID in the array, these may also be printed to a file.

	//Prints out a transcript to a text file.
	void print_to_file(ofstream & file_stream, string output);
	//Precondition: File output stream not initialised yet, only declared, output string initialised with data.
	//Postcondition: Output string will be written to a file titled with today's date, if it already exists, the string will be appended onto any old data in the file.


private:

	Date today;
	string degree_result;
	string programme_id, programme_name, qualification, start_date, end_date, attendance_mode;
	string student_id, student_name, visa_expiry;
	string key = "Key:\n-\tMark Not Yet Granted\n[R]\t Reassessment Granted\nWS\tWeighting\n#\tProvisional Mark\n-1\t Not yet Attempted\n Note, Degree aggregate may be incorrect if not all assessments have been taken.";
	double degree_aggregate;
	bool status, research_task_found = false;


	//Structure to store an assessment's details.
	struct assessment_details {

		string name;
		string weighting, mark, attempt, assessment_id;
		string level, grade;
		bool result;

	};

	//Structure to store a course's details.
	struct course_details {

		vector <assessment_details> assessments;
		string course_code, course_name;
		string weighting, mark, credit, attempt;
		string level, grade, begin_year, end_year;
		bool result;

	};
	
	struct level {

		assessment_details research_task;
		course_details courses[2];
		string grade, mark, credit;
		char current_level;
		bool result;
		

	};


	level student_levels[3];


	void get_details(Database^ database, const string student_id);

	void extract_values(string values_arr[], const string values_str, const int size);
	void find_programme_details(Database^ database);
	void find_student_details(Database^ database, const string student_id);
	void find_course_details(Database^ database);
	void find_assessment_details(Database^ database);
	
	void calculate_course_stats();			//Cycle through all assessments on each course and average marks.
	void calculate_degree_aggregate();

	void clear_transcript();

	void find_courses_at_level(Database^ database, const vector<string> course_details, vector<string> &return_values, const char level);

	void print_all(Database^ database, ofstream &file_stream, const string student_ids[], const int number_of_ids);
	void print_data(string output);
	void print_data(string output, ofstream &file_stream);
};

class Unregistered {};