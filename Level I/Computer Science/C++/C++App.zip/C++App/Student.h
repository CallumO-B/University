
/*
*	Student Manipulator Class
*
*	Enables Selection, Insertion, Amending and Deletion of
*	students from a database using a general format for a
*	table.
*
*	Keiran Brown - 15000194
*	
*	Uses: Database Connector C++; Menu Constructor & Date Class
*/

#pragma once
#include "Database.h"
#include "Menu.h"
#include "Date.h"

#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include <ctime>

using std::cin;
using std::cout;
using std::string;
using namespace Menus;
using namespace Database_Application;

typedef short unsigned int shuint;
typedef unsigned int uint;
typedef string* strptr;


class Student
{

public:

	//Deliberately empty constructor.
	Student();

	//The Main Menu of the student editor.
	void main_menu(Database^ database);
	//Precondition:	Database instance initialised to be passed on to the menu.
	//Postcondition: Main menu will exit without making any changes to the Database instance.

	//This function goes through search process to have the user find a student ID.
	string get_student_id(Database^ database);
	//Precondition:	Database instance initialised, variable to catch student ID that will return, needed.
	//Postcondition:  Will return a student ID in the form of a string to a string variable.
	// - - - - - - -  Will return "EXIT" if user exits search or "NO STUDENTS FOUND" if search returns nothing.

	//Returns string containing ALL a particular student's details.
	string get_student_details(Database^ database, string student_id);
	//Precondition: Database instance initialised, student ID initialised and should be correct.
	//Postcondition: Will return all details associated with that particular student from the database.

protected:
	
	//Inserts students using a file.
	void insert_student_by_file(Database^ database, vector<string> &student_ids);
	//Precondition: Database instance initialised, modifyable vector instance able to hold strings and can hold any amount of strings.
	//Postcondition: Passed vector is filled with student IDs and students are inserted into the database from a file specified by the user.

private:

	//Local menu instance for creating menus for user input.
	Menu menu;

	//Local date instance for tracking dates.
	Date date;

	string current_task;
	strptr student_fields, student_values;

	//This function allows users to view student information.
	void view_student(Database^ database);

	//This group of functions allows a student to be inserted, inputs are fixed and a programme must be chosen.
	void new_student(Database^ database);
	//This function inserts student files either manually or using a file.
	void insert_student_values(Database^ database);
	string choose_programme(Database^ database);
	string input_date(Database^ database, string date_type);
	string input_email();

	//This function allows a student to be ammended.
	void ammend_student(Database^ database);

	//This function allows a student to be removed.
	void remove_student(Database^ database);

	//This function reformats a string with ';' delims for nicer output.
	void fix_delimiters(string &value);

	//These functions perform a keyword search of the database, the table in the overloaded function defaults to student.
	void keyword_search(Database^ database, string column, vector<string> &rows);
	string find_student(Database^ database, string student_id);
	void keyword_search(Database^ database, string column, string table, vector<string> &rows);

	//These functions finds a particular student by asking the user for information.
	void search_for_student(Database^ database, vector<string> &returned_values);
	void search_student_by_course(Database^ database, vector<string> &returned_values);
	void search_student_by_address(Database^ database, vector<string> &returned_values);
	void search_student_by_name(Database^ database, vector<string> &returned_values);

	//This function gets the minimum age a student needs to be from the university information table in the database.
	int minimum_student_age(Database^ database);

	//Function to get the teh student tables fields.
	void get_table_fields(Database^ database, vector<string> &my_values);


	bool search_string(string key_term, string comparison);

	//Clears the input stream.
	void clear_inputstream();



};
