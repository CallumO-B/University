//Karl Myers 15008411
//last modified 03/03/17
//Some snippets of code taken from examples given by Dr Stewart Blakeway///////////////////////// 

#include "Database.h"
#include "Course.h"
#include <string>

using namespace Database_Application;
using namespace std;


///////////////////Course menu to access othe menus and remove functions 
	void Course::CourseMenu(Database^ db)
	{
		string user_choice;
		int choice = 0;
		flushInputStream();
		do
		{
			do
			{
				clearScreen();
				cout << "=============================\n";
				cout << " Course Menu\n";
				cout << " ------------\n";
				cout << "1. Add Course \n";
				cout << "2. Update Menu\n";
				cout << "3. Remove Course\n";
				cout << "4. Remove Assessement\n";
				cout << "5. Search Menu\n";
				cout << "0. exit menu\n";
				cout << "=============================\n";
				cout << "Menu choice: ";
				cin >> user_choice;

				choice = stoi(user_choice);

			} while ((choice < 0) || (choice > 5));

			switch (choice)
			{
			case 1:
				addCourse(db);
				break;
			case 2:
				updateMenu(db);
				break;
			case 3:
				removeCourse(db);
				break;
			case 4:
				removeAssessment(db);
				break;
			case 5:
				SearchMenu(db);
				break;
			case 0:
				return;
				break;
			default:
				cout << "Somthing went wrong!";
				
			}
		} while (choice != 0);
		return;
	}


	Course::Course()//construtor
	{

	};


	

	//Show Function Definitions
	void Course::showCourse(const bool& message)
	{
		
		clearScreen();

			cout << "Course Details\n";
			cout << "===============\n";
			cout << "cousre code is; " << course_code << endl;
			cout << "Course name is : " << Course_name << endl;
			cout << "Course Level is : " << level << endl;
			cout << "Course Credit Ammount is : " << credit_ammount << endl;
		
		if (message)
			informationMessageContinue(" press enter to return to the menu.");
	}

	void Course::showAssessment(const bool& message, int num)
	{
		clearScreen();
		
			cout << "Assessment Details\n";
			cout << "===============\n";
			cout << "Assessment Name is: " << assessment_name[num] << endl;
			cout << "Assessment weighting is: " << weighting[num] << endl;
		
		if (message)
			informationMessageContinue(" press enter to return to the menu.");
	}

	//Allow entry of courses which are to be enrolled onto a particular programme.
	void Course::addCourse(Database^ db, string programme_id)
	{
		//Go to adding course.
		addCourse(db);

		//Insert the relation between the last entered course and the programme.
		db->perform_sql_action("INSERT INTO programme_course (programme_id, course_code) VALUES (" + programme_id + ", \"" + course_code + "\"");

	}

	//Get Function Definitions
	void Course::addCourse(Database^ db)
	{
		clearScreen();
		flushInputStream();
		cout << "Add New Course\n";
		cout << "===============\n";

		cout << "Enter course code: ";
		getline(cin, course_code);

		cout << "Enter Course Name: ";
		
		getline(cin, Course_name);

		getLevel(level);
		

		getCreditValue(credit_ammount);
		

		char choice;
		showCourse(false);
		cout << "Course record added. Would you like to save this record (yes/no)? ";
		flushInputStream();
		cin.get(choice);
		if (choice == 'y' || choice == 'Y')
		{
			saveCourse(db);
			addAssessment(db);
		}
		else
		{
			cout << "Course not saved.";
			informationMessageContinue(" press enter to return to the menu.");
		}

		
		return;
	}
	void Course::addAssessment(Database^db)
	{

		cout << "How many assessments would you like you add to this course?" << endl;

		cin >> num_of_assessments;
		
		assessment_name = new string[num_of_assessments];
		assessment_id = new string[num_of_assessments];
		assessment_deadline = new string[num_of_assessments];
		research_task = new string[num_of_assessments];

		flushInputStream();
		for (int i = 0; i < num_of_assessments; i++)
		{

			flushInputStream();
			cout << "Add New Assessment\n";
			cout << "===============\n";

			cout << "Enter Assessment Name: ";
			getline(cin,assessment_name[i]);
			cout << assessment_name[i] << endl;

			cout << "Enter Assessment weighting: ";
			cin >> sweighting[i];
			weighting[i] = stoi(sweighting[i]);

			flushInputStream();

			cout << "Enter Assessment deadline" << endl;
			date.input_date();
			date.get_sql_date(assessment_deadline[i]);
			

			//Enter whether this assessment is a research task.
			char ans;

			do
			{

				cout << "Is this assessment a research task? (Y/N)" << endl;
				cin >> ans;

				ans = toupper(ans);

			} while (ans != 'Y' && ans != 'N');

			if (ans == 'Y')
				research_task[i] = '0';
			else
				research_task[i] = '1';

			char choice;
			flushInputStream();
			showAssessment(false, i);
			cout << "Assessment record added. Would you like to save this record (yes/no)? ";
			cin.get(choice);
			if (choice == 'y' || choice == 'Y')
			{
				saveAssessment(db, i);
			}
			else
			{
				cout << "Assessment not saved.";
				i--;
			}
		}

		getAssessmentAssignment(db);

		delete[] assessment_name, assessment_deadline;
	}

	////////////assigns assessments to course//////////////////////////
	void Course::getAssessmentAssignment(Database^db)
	{
		
		total_weighting=checkWeighting(total_weighting,weighting);
		if (total_weighting != 100)
			do {
				cout << "Somthing went wrong, assessment weightings do not = 100%\n";
				cout << "re-enter weightings\n";
				for (int i = 0; i < num_of_assessments; i++)
				{
					cout << "Enter Assessment weighting\n";
					cin >> sweighting[i];

					weighting[i] = stoi(sweighting[i]);
				}
				total_weighting = checkWeighting( total_weighting,weighting);

			} while (total_weighting != 100);
			saveAssessmentAssignment(db);
	}

	//////////////Save functions ask user if they wish to save, and saves to the database/////////////////////// 
	void Course::saveCourse(Database^db)
	{
		//Database^ db = gcnew Database("UNI");
		flushInputStream();
		
			string columns[] = { "course_code","course_name","course_level", "credit_amount" };
			int columns_size = 4;
			const string table = "course";
			string values[] = { course_code, Course_name, level, credit_ammount };
			int values_size = 4;
			db->change_database("UNI_database");
			db->sql_insert(columns, columns_size, table, values, values_size);
		
		return;
	};
	void Course::saveAssessment(Database^ db, int num)
	{

			string columns[] = {"assessment_name", "research_task" };
			int columns_size = 2;
			const string table = "assessment";
			string values[] = {assessment_name[num], research_task[num] };
			int values_size = 2;
			db->sql_insert(columns, columns_size, table, values, values_size);

			vector<string> assessment_id_query;
			db->change_database("UNI_database");
			db->perform_sql_action("SELECT MAX(assessment_id) FROM assessment", assessment_id_query);

			assessment_id[num] = assessment_id_query[0];
		
		return;
	};
	void Course::saveAssessmentAssignment(Database^db)
	{
		
		for (int i = 0; i < num_of_assessments; i++)
		{
			if ((course_code == " "))
				cout << "record set is empty! - Nothing saved!\n";
			else
			{
				string columns[] = {"course_code","assessment_id","weighting", "deadline" };
				int columns_size = 4;
				const string table = "course_assessment";
				string values[] = {course_code ,assessment_id[i], sweighting[i], assessment_deadline[i]};
				int values_size = 4;
				db->change_database("UNI_database");
				db->sql_insert(columns, columns_size, table, values, values_size);
			}
		}
	}


	/////////////update menu for accessing  update functions ////////////////////////////
	void Course::updateMenu(Database^db)
	{
		flushInputStream();
		clearScreen();
		int choice;
		do
		{
			do
			{
				cout << "=============================\n";
				cout << " Update Menu\n";
				cout << " ------------\n";
				cout << "1. Update Course Name\n";
				cout << "2. Update Course Level\n";
				cout << "3. Update Cousre Credit Amount\n";
				cout << "4. Update Assessment name\n";
				cout << "0. Return to Course Menu\n";
				cout << "=============================\n";
				cout << "Menu choice: ";
				cin >> choice;
			} while ((choice < 0) || (choice > 4));

			switch (choice)
			{
			case 1:
				updateCourseName(db);
				break;
			case 2:
				updateCourseLevel(db);
				break;
			case 3:
				updateCourseCreditAmmount(db);
				break;
			case 4:
				updateAssessmentName(db);
				break;
			case 0:
				CourseMenu(db);
				break;
			default:
				cout << "Somthing went wrong!";
				
			}
		} while (choice != 0);
		return;
	}
	///////////////////////Updates the course Name, by entering course code///////////////////////
	void Course::updateCourseName(Database^db)
	{
		char choice;
		cout << "Do you know the course code? (yes/no)? ";
		flushInputStream();
		cin.get(choice);
		if (choice == 'y' || choice == 'Y')
		{
			clearScreen();
			flushInputStream();
			string specify_column = "course_name";
			string table = "course";
			string new_value;
			string query_column = "course_code";
			string query_value;
			flushInputStream();
			cout << "Enter course code: ";
			getline(cin, query_value);
			cout << "Enter New Name:  ";
			getline(cin, new_value);
			db->change_database("UNI_database");
			db->Database::sql_update(specify_column, table, new_value, query_column, query_value);
			informationMessageContinue(" press enter to return to the menu.\n");
		}
		else
		{

			searchAllCourses(db);
			flushInputStream();
			string specify_column = "course_name";
			string table = "course";
			string new_value;
			string query_column = "course_code";
			string query_value;
			flushInputStream();
			cout << "Enter course code: ";
			getline(cin, query_value);
			cout << "Enter New Name:  ";
			getline(cin, new_value);
			db->change_database("UNI_database");
			db->Database::sql_update(specify_column, table, new_value, query_column, query_value);
			informationMessageContinue(" press enter to return to the menu.\n");

		}
	}
	///////////////////////updates course level, by entering course code/////////////////////
	void Course::updateCourseLevel(Database^ db)
	{
		char choice;
		cout << "Do you know the course code? (yes/no)? ";
		flushInputStream();
		cin.get(choice);
		string specify_column = "course_level";
		string table = "course";
		string new_value;
		string query_column = "course_code";
		string query_value;
		if (choice == 'y' || choice == 'Y')
		{
			clearScreen();
			flushInputStream();
			flushInputStream();
			cout << "Enter course Code: ";
			getline(cin, query_value);
			getLevel(level);
			new_value = level;
			db->change_database("UNI_database");
			db->Database::sql_update(specify_column, table, new_value, query_column, query_value);
			informationMessageContinue(" press enter to return to the menu.\n");
		}
		else
		{
			searchAllCourses(db);
			flushInputStream();
			cout << "Enter course code: ";
			getline(cin, query_value);
			cout << "Enter New Name:  ";
			getline(cin, new_value);
			db->change_database("UNI_database");
			db->Database::sql_update(specify_column, table, new_value, query_column, query_value);
			informationMessageContinue(" press enter to return to the menu.\n");

		}
	}
	//////////////////////////updates course credit ammount, by entering the course code///////////////////
	void Course::updateCourseCreditAmmount(Database^ db)
	{
		clearScreen();
		flushInputStream();
		char choice;
		cout << "Do you know the course code? (yes/no)? ";
		flushInputStream();
		cin.get(choice);
		string specify_column = "credit_amount";
		string table = "course";
		string new_value;
		string query_column = "course_code";
		string query_value;
		flushInputStream();
		if (choice == 'y' || choice == 'Y')
		{
			cout << "Enter course Code: ";
			getline(cin, query_value);
			getCreditValue(credit_ammount);
			new_value = credit_ammount;
			db->change_database("UNI_database");
			db->Database::sql_update(specify_column, table, new_value, query_column, query_value);
			informationMessageContinue(" press enter to return to the menu.\n");
		}
		else
		{
			searchAllCourses(db);
			cout << "Enter course Code: ";
			getline(cin, query_value);
			getCreditValue(credit_ammount);
			new_value = credit_ammount;
			db->change_database("UNI_database");
			db->Database::sql_update(specify_column, table, new_value, query_column, query_value);
			informationMessageContinue(" press enter to return to the menu.\n");
		}
	}
	////////////////////updates assessment name by entering assessment id////////////////////////
	void Course::updateAssessmentName(Database^ db)
	{
		char choice;
		cout << "Do you know the course code? (yes/no)? ";
		cin >> choice;
		clearScreen();
		flushInputStream();
		string specify_column = "assessment_name";
		string table = "assessment";
		string new_value;
		string query_column = "assessment_id";
		string query_value;
		flushInputStream();
		if (choice == 'y' || choice == 'Y')
		{
			cout << "Enter assessment_id: ";
			getline(cin, query_value);
			cout << "Enter New assessment name: ";
			getline(cin, new_value);
			db->change_database("UNI_database");
			db->Database::sql_update(specify_column, table, new_value, query_column, query_value);
			informationMessageContinue(" press enter to return to the menu.\n");
		}
		else
		{
		searchAllAssessments(db);
		cout << "Enter assessment_id: ";
		getline(cin, query_value);
		cout << "Enter New assessment name: ";
		getline(cin, new_value);
		db->change_database("UNI_database");
		db->Database::sql_update(specify_column, table, new_value, query_column, query_value);
		informationMessageContinue(" press enter to return to the menu.\n");
		}
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//delete function deletes the cousre by course code or course name
	void Course::removeCourse(Database^ db)
	{
		char choice;
		cout << "Do you know the course code? (yes/no)? ";
		flushInputStream();
		cin.get(choice);
		if (choice == 'y' || choice == 'Y')
		{
			string table = "course";
			string specify_column = "course_code";
			string specify_value;
			cout << "Enter Cousre Code: ";
			cin >> specify_value;
			
			vector<string> course_details;
			db->change_database("UNI_database");
			db->sql_select("*", "course", "course_code", specify_value, course_details);

			if (course_details.size() == 0)
				cout << "Course Not Found!" << endl;
			else
			{
				cout << "Course: " << course_details[0];
				int choice = menu.yes_no_menu("Would you like to delete this course?");

				if (choice == 1)
				{
					db->change_database("UNI_database");
					db->Database::sql_delete(table, specify_column, specify_value);
				}
				else
					return;
			}
		}
		else
		{
			flushInputStream();
			string table = "course";
			string specify_column = "course_name";
			string specify_value;
			cout << "Enter Course name: ";
			getline(cin, specify_value);

			vector<string> course_details;
			db->change_database("UNI_database");
			db->sql_select("*", "course", "course_code", specify_value, course_details);

				if (course_details.size() == 0)
					cout << "Course Not Found!" << endl;
				else
				{
					cout << "Course: " << course_details[0];
					int choice = menu.yes_no_menu("Would you like to delete this course?");

					if (choice == 1)
					{
						db->change_database("UNI_database");
						db->Database::sql_delete(table, specify_column, specify_value);
					}
					else
						return;
				}

			
			}
			
			informationMessageContinue(" press enter to return to the menu.\n");
		}
	//delete function deletes the assessment by assessmnet code or name
	void Course::removeAssessment(Database^ db)
	{
		char choice;
		cout << "Do you know the Assessment code? (yes/no)? ";
		flushInputStream();
		cin.get(choice);
		if (choice == 'y' || choice == 'Y')
		{
			string table = "Assessment";
			string specify_column = "assessment_id";
			string specify_value;
			cout << "Enter assessment id : ";
			cin >> specify_value;

			vector<string> assessment_details;
			db->change_database("UNI_database");
			db->sql_select("*", "assessment", "assessment_id", specify_value, assessment_details);

			if (assessment_details.size() == 0)
				cout << "Assessment Not Found!" << endl;
			else
			{
				cout << "Assessment: " << assessment_details[0];
				int choice = menu.yes_no_menu("Would you like to delete this Assessment?");

				if (choice == 1)
				{
					db->change_database("UNI_database");
					db->Database::sql_delete(table, specify_column, specify_value);
				}
				else
					return;
			}

		}
		else
		{
			flushInputStream();
			string table = "assessment";
			string specify_column = "assessment_name";
			string specify_value;
			cout << "Enter assessment name: ";
			getline(cin, specify_value);

			vector<string> assessment_details;
			db->change_database("UNI_database");
			db->sql_select("*", "assessment", "assessment_name", specify_value, assessment_details);

			if (assessment_details.size() == 0)
				cout << "Assessment Not Found!" << endl;
			else
			{
				cout << "Assessment: " << assessment_details[0];
				int choice = menu.yes_no_menu("Would you like to delete this assessment?");

				if (choice == 1)
				{
					db->change_database("UNI_database");
					db->Database::sql_delete(table, specify_column, specify_value);
				}
				else
					return;
			}

		}

		informationMessageContinue(" press enter to return to the menu.");
	}
	///////////////////////////////////Menu to access search functions ////////////////////////////////////////////////////
	void Course::SearchMenu(Database^db)
	{
		flushInputStream();
		clearScreen();
		int choice;
		do
		{
			do
			{
				cout << "=============================\n";
				cout << " Search Menu\n";
				cout << " ------------\n";
				cout << "1. Search for all courses\n";
				cout << "2. Search for course by name\n";
				cout << "3. Search for course by course code\n";
				cout << "4. Search for assessments asigned to course\n";
				cout << "5. Search for all assessments\n";
				cout << "6. Search for Assessment by name\n";
				cout << "7. Search for Assessment by assessment ID\n";
				cout << "0. Return to Course Menu\n";
				cout << "=============================\n";
				cout << "Menu choice: ";
				cin >> choice;
			} while ((choice < 0) || (choice > 7));

			switch (choice)
			{
			case 1:
				searchAllCourses(db);
				break;
			case 2:
				searchForCourseName(db);
				break;
			case 3:
				searchForCourseCode(db);
				break;
			case 4:
				searchForAssessmetsAssignedToCourse(db);
				break;
			case 5:
				searchAllAssessments(db);
				break;
			case 6:
				searchForAssessmentName(db);
				break;
			case 7:
				searchForAssessmnetId(db);
				break;
			case 0:
				CourseMenu(db);
				break;
			default:
				cout << "Somthing went wrong!";
				
			}
		} while (choice != 0);
		return;
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////Functions for searching courses ///////////////////////////////
	
	//////////////Searches for all courses and prints to the console/////////////
	void Course::searchAllCourses(Database^db)
	{
		flushInputStream();
		clearScreen();
		vector<string> values_to_return;
		db->change_database("UNI_database");
		db->sql_select("*", "course", values_to_return);
		//cout << values_to_return.size() << endl;
		clearScreen();
		cout << "code|Name|Level|Credits\n";
		cout << "============================\n";
		for (unsigned int i = 0; i < values_to_return.size(); i++)
			cout << values_to_return[i] << endl;

		informationMessageContinue(" press enter\n");
	}

	//////////////////////Searches for cousre by name and prints to the console ////////////////////////////////// 
	void Course::searchForCourseName(Database^ db)
	{
		flushInputStream();
		clearScreen();
		
		string column = "*";
		string table = "course";
		string specify_column = "course_name";
		string specify_value;
		vector<string> values_to_return;
		cout << "Enter Course name: ";
		getline(cin, specify_value);
		db->change_database("UNI_database");
		db->Database::sql_select(column, table, specify_column, specify_value, values_to_return);

		clearScreen();

		cout << "code|Name|Level|Credits\n";
		cout << "===========================\n";
		for (unsigned int i = 0; i < values_to_return.size(); i++)
		cout << values_to_return[i] << endl;

		informationMessageContinue(" press enter to return to the menu.\n");
		
	}
	/////////////////Searches for the cousre by course code and prints to the console ///////////////////////////////////
	void Course::searchForCourseCode(Database^ db)
	{
		flushInputStream();
		clearScreen();
		string column = "*";
		string table = "course";
		string specify_column = "course_code";
		string specify_value;
		vector<string> values_to_return;
		cout << "Enter Course Code: ";
		getline(cin, specify_value);
		db->change_database("UNI_database");
		db->Database::sql_select(column, table, specify_column, specify_value, values_to_return);

		clearScreen();
		cout << "code|Name|Level|Credits\n";
		cout << "===========================\n";
		for (unsigned int i = 0; i < values_to_return.size(); i++)
			cout << values_to_return[i] << endl;
		informationMessageContinue(" press enter to return to the menu.\n");
	
	}
	//////////////////////functions for searching assessments////////////////////////////////////////

	////////// Searches for Assessments assigned to a course and prints to screen//////////////////////////////
	void Course::searchForAssessmetsAssignedToCourse(Database^ db)
	{
		flushInputStream();
		clearScreen();
		string column = "*";
		string table = "course_assessment";
		string specify_column = "course_code";
		string specify_value;
		vector<string> values_to_return;
		cout << "Enter Course Code: ";
		getline(cin, specify_value);
		db->change_database("UNI_database");
		db->Database::sql_select(column, table, specify_column, specify_value, values_to_return);

		clearScreen();

		cout << "C_code|A_id|Weight\n";
		cout << "=====================\n";
		for (unsigned int i = 0; i < values_to_return.size(); i++)
			cout << values_to_return[i] << endl;
		informationMessageContinue(" press enter to return to the menu.\n");
		
	}
	//////////////////////searches for all assessments and prints to the screen /////////////////////////
	void Course::searchAllAssessments(Database^db)
	{
		flushInputStream();
		clearScreen();
		vector<string> values_to_return;
		db->change_database("UNI_database");
		db->sql_select("*", "assessment", values_to_return);

		clearScreen();
		cout << "A_id|A_Name\n";
		cout << "===================\n";
		for (unsigned int i = 0; i < values_to_return.size(); i++)
			cout << values_to_return[i] << endl;

		informationMessageContinue(" press enter\n");
	}
//////////////////searches for assessments by name ////////////////////////////////////////
	void Course::searchForAssessmentName(Database^ db)
	{
		flushInputStream();
		clearScreen();
		string column = "*";
		string table = "assessment";
		string specify_column = "assessment_name";
		string specify_value;
		vector<string> values_to_return;
		cout << "Enter assessment Name: ";
		getline(cin, specify_value);
		db->change_database("UNI_database");
		db->Database::sql_select(column, table, specify_column, specify_value, values_to_return);
		clearScreen();
		cout << "A_id|A_Name\n";
		cout << "==================\n";
		for (unsigned int i = 0; i < values_to_return.size(); i++)
			cout << values_to_return[i] << endl;

		informationMessageContinue(" press enter to return to the menu.\n");
	}
	/////////////////////////searches for assessment by id and prints to the console //////////////////////
	void Course::searchForAssessmnetId(Database^ db)
		{
		flushInputStream();
		clearScreen();
			string column = "*";
			string table = "assessment";
			string specify_column = "assessment_id";
			string specify_value;
			vector<string> values_to_return;
			cout << "Enter Assessment Id: ";
			getline(cin, specify_value);
			db->change_database("UNI_database");
			db->Database::sql_select(column, table, specify_column, specify_value, values_to_return);
			clearScreen();
			cout << "A_id|A_id\n";
			cout << "==================\n";
			for (unsigned int i = 0; i < values_to_return.size(); i++)
				cout << values_to_return[i] << endl;

			informationMessageContinue(" press enter to return to the menu.\n");
		
		}

	/*void Course::searchForCourseAssisgnedToProgramme(Database^ db)
	{
		//Database^ db = gcnew Database("UNI");
		string column = "course_code";
		string table = "programme_course";
		string specify_column = "course_code";
		string specify_value;
		vector<string> values_to_return;
		cout << "Enter Course Code";
		getline(cin, specify_value);
		db->Database::sql_select(column, table, specify_column, specify_value, values_to_return);
		informationMessageContinue(" press enter to return to the menu.");
	}*/
	//////////////////////////////////////////////////////////////////////////////////////////////////////

	//////////////////miscFunctions//////////////////////////////////////////
	//////////////////////Checks the input forr level is correct, returns ans error message and promts for re-entry///////////
	void Course::getLevel(string& level)
	{
		bool incorrectLevelValue;
		do
		{
			//flushInputStream();
			incorrectLevelValue = false;
			cout << "Enter the level (C, I, H or M) of the course: ";
			getline(cin, level);

			//Convert level to uppercase for simpler evaluation.
			level[0] = toupper(level[0]);

			if (!(level == "C" || level == "I" || level == "H"||"M" ))
			{
				cout << "Invalid level value. Allowed values are:\n";
				cout << " C for Certificate Level (1st Year)\n";
				cout << " I for Intermediate Level (2nd Year)\n";
				cout << " H for Honours Level (3rd Year)\n";
				cout << " M for Masters Level (Post Graduate)\n";
				incorrectLevelValue = true;
				cout << " you entered: " << level << endl;
			}
		} while (incorrectLevelValue);
	}

	////////////////////Checks input for credit value is correct, reurns an error message and promts for re-entry///////////////
	void Course::getCreditValue(string& credit_ammount)
	{
		//flushInputStream();
		bool incorrectCreditValue;
		do
		{
			incorrectCreditValue = false;
			cout << "Enter the credit value of the course: ";
			cin >> credit_ammount;

			if (!(credit_ammount == "0" || credit_ammount == "15" || credit_ammount == "30" || credit_ammount == "45" || credit_ammount == "60" || credit_ammount == "90" || credit_ammount == "120"))
			{
				cout << "Invalid credit value. Allowed values are:\n";
				cout << " 0 for no credit bearing\n";
				cout << " 15 for 15 credits\n";
				cout << " 30 for 30 credits\n";
				cout << " 45 for 45 credits\n";
				cout << " 60 for 60 credits\n";
				cout << " 90 for 90 credits\n";
				cout << " 120 for 120 credits\n";
				incorrectCreditValue = true;
			}
		} while (incorrectCreditValue);

	}
///////////////////////////////////////////input a screen cleaners/////////////////////////////////
	void Course::flushInputStream()
	{
		cin.ignore(100, '\n');
	}
	void Course::clearScreen()
	{
		cout << string(50, '\n');
	}
///////////////////////returns the user to menus/////////////////////////////
	void Course::informationMessageContinue(const string& s)
	{
		string tmp;
		cout << s;
		getline(cin, tmp);
	}
///////////////sums assessment weightings///////////////////////////////////////
	int Course::checkWeighting(int total_weighting, int weighting[])
	{
		total_weighting = 0;

		for (int i = 0; i < num_of_assessments; i++)
			total_weighting += weighting[i];

		return total_weighting;
	}

	string Course::search_for_course(Database^ database) {

		string options[] = {

			"Return to Previous Menu",
			"Search by Course Name",
			"Enter a Course Code"

		};

		unsigned int choice = menu.create_menu("Please choose how you would like to search", options, 3, true);

		switch (choice) {

		case 0:

			return "NO COURSES CHOSEN";

			break;

		case 1:
		{
			cout << "Please enter a course name" << endl;

			string search_term;

			flushInputStream();

			getline(cin, search_term);

			vector<string> search_values;

			database->perform_sql_action("SELECT course_code, course_name FROM course WHERE course_name=\"" + search_term + "\"", search_values);

			string* search_return_values = new string[search_values.size()];

			for (unsigned int i = 0; i < search_values.size(); i++) {
				search_return_values[i] = search_values[i];
				cout << search_return_values[i] << " " << search_values[i] << endl;
			}

			choice = menu.create_menu("Please select a course", search_return_values, search_values.size(), true);

			string chosen_course_code;

			for (unsigned int i = 0; i < search_return_values[choice].length(); i++) {

				if (search_return_values[choice][i] == ';')
					break;
				else
					chosen_course_code += search_return_values[choice][i];

			}

			return chosen_course_code;

		}
			break;
		
		case 2:

			cout << "Please enter a Course Code" << endl;

			string course_code;

			flushInputStream();
			getline(cin, course_code);

			return course_code;

			break;

		}

		return "FAILED TO SELECT OPTION";

	}