// Created by Callum Owen-Bridge (15002504) latest version 22/03/2017
#include "programme_course.h"

Programme_course::Programme_course() {}

// menu function for programme course
void Programme_course::programmeCourse_menu(Database^ db) {
	
	db->change_database("uni_database");
	
	string options[] = { "Return to Main Menu", "View courses on programme", "Add course to programme", "Amend programme course"};

	int choice = 1;
	while (choice > 0) {
		int choice = menu.create_menu("Please choose an option", options, 4, true);
		

		switch (choice) {

		case 0:

			return;

			break;

		case 1:
			view_programmeCourse(db);
			break;

		case 2:
			add_ProgrammeCourse(db);
			break;

		case 3:
			amend_ProgrammeCourse(db);
			break;
		}
	}
}

// allows the user to add courses to a programme
void Programme_course::add_ProgrammeCourse(Database^ db) {

	int amountC, amountH, amountI, amount;
	string * course_code, * weighting, *endYear, *beginYear;
	string programme_id, begin_y, end_y, columns[5] = { "programme_id", "course_code", "begin_year", "end_year", "weighting" }, menu_options;              
	vector<string> values, ids;
	bool loop = true;
	
	menu.clear_screen();

	//do-while allows user to execute function again
	do 
	{
	
    clear_inputstream();
	db->perform_sql_action("SELECT * FROM programme", ids);

	// if statment tells user no values are present 
	if (ids.size() == 0)
	{
		cout << "no programmes in database" << endl;
		return;
	}

	//for loop to print out programme details 
	for (unsigned int i = 0; i < ids.size(); i++)
	{
		cout << "ID  ||  name  ||  degree type  ||  attendance mode  ||  begin date  ||  end date  ||  date created  ||" << endl;
		cout << ids[i] << endl;
		cout << endl;
	}

	cout << endl;
	cout << "Enter programme ID" << endl;
	getline(cin, programme_id);
	input_checker(programme_id);

	clear_inputstream();
	cout << "How many courses will be on level C?" << endl;
	cin>> amountC;

	cout << "How many courses will be on level I?" << endl;
	cin >> amountI;

	cout << "How many courses will be on level H?" << endl;
	cin >> amountH;

	amount = amountC + amountI + amountH;

	// try catch to catch ran out of memory exception
	try
	{
		course_code = new string[amount];
		weighting = new string[amount];
		endYear = new string[amount];
		beginYear = new string[amount];
	}
	catch (bad_alloc)
	{
		cout << "Ran out of memory";
		exit(0);
	}

	int course_code_num = 0;

	for (int i = 0; i < amountC; i++)
	{
		cout << "Enter Course code for level C" << endl;
		clear_inputstream();
		getline(cin, course_code[course_code_num]);
		input_checker(course_code[course_code_num]);
		if(amountC==1)
			weighting[course_code_num] = "100";
		else
		weighting[course_code_num] = "50";

		clear_inputstream();
		cout << "Enter begin year of course" << endl;
		getline(cin, begin_y);
		input_checker(begin_y);
		beginYear[course_code_num] = begin_y;

		// do-while makes sure user enters an end year larger than or equal to begin year
		do {
			clear_inputstream();
			cout << "Enter end year of course" << endl;
			getline(cin, end_y);
			input_checker(end_y);
			if (end_y < begin_y)
				cout << "end year is not more than or equal to begin year/n please re-enter end year";
			else
			{
				endYear[course_code_num] = end_y;
				break;
			}
		} while (loop);

		course_code_num++;
	}

	for (int i = 0; i < amountI; i++) {
		cout << "Enter Course code for level I" << endl;
		clear_inputstream();
		getline(cin, course_code[course_code_num]);
		input_checker(course_code[course_code_num]);
		if (amountC == 1)
			weighting[course_code_num] = "100";
		else
			weighting[course_code_num] = "50";

		clear_inputstream();
		cout << "Enter begin year of course" << endl;
		getline(cin, begin_y);
		input_checker(begin_y);
		beginYear[course_code_num] = begin_y;

		// do-while makes sure user enters an end year larger than or equal to begin year
		do {
			clear_inputstream();
			cout << "Enter end year of course" << endl;
			getline(cin, end_y);
			input_checker(end_y);
			if (end_y < begin_y)
				cout << "end year is not more than or equal to begin year/n please re-enter end year";
			else
			{
				endYear[course_code_num] = end_y;
				break;
			}
		} while (loop);

		course_code_num++;
	}

	for (int i = 0; i < amountH; i++) {
		cout << "Enter Course code for level H" << endl;
		clear_inputstream();
		getline(cin, course_code[course_code_num]);
		input_checker(course_code[course_code_num]);
		if (amountC == 1)
			weighting[course_code_num] = "100";
		else
			weighting[course_code_num] = "50";

		clear_inputstream();
		cout << "Enter begin year of course" << endl;
		getline(cin, begin_y);
		input_checker(begin_y);
		beginYear[course_code_num] = begin_y;

		// do-while makes sure user enters an end year larger than or equal to begin year
		do {
			clear_inputstream();
			cout << "Enter end year of course" << endl;
			getline(cin, end_y);
			input_checker(end_y);
			if (end_y < begin_y)
				cout << "end year is not more than or equal to begin year/n please re-enter end year";
			else
			{
				endYear[course_code_num] = end_y;
				break;
			}
		} while (loop);

		course_code_num++;
	}

	

	// check to see if values are correct before isnerting into database
	cout << "Programme id:   " + programme_id << endl;

	// prints values 
	for (int i = 0; i < amount; i++)
	{
		cout << "   Course code:   " + course_code[i] <<"  Weighting:  "<<weighting[i]<< endl;
		cout << "  Begin year  " + beginYear[i] + "  End year  " + endYear[i] << endl;
	}
	//	if values are incorrect user can go through function again
	if (menu.yes_no_menu("Is the above correct ?"))
	{
		

		for (int i = 0; i < amount; i++) 
		{
			string values[5] = { programme_id, course_code[i], beginYear[i], endYear[i], weighting [i]};

			//try catch 
			try 
			{

				db->sql_insert(columns, 5, "programme_course", values, 5);

			}
			catch (MySqlException^ e)
			{
				
				cout << "Exception: " << e->Number;
				cout << "Non-Specified Course Code not Entered" << endl;
			
			};
		}

		cout << "Programme course added" << endl;
		if (!menu.yes_no_menu("Would you like to add another programme course?"))
			break;
	}

	else
		cout << " Function Restarting " << endl;
	
	}while (amount);

	// pointer arrays are deleted to release memory
	delete[] course_code, weighting, endYear, beginYear;
	return;
}

// allows user to amend programe course table 
void Programme_course::amend_ProgrammeCourse(Database^ db) {
	string programme_id, course_code, newcourse_code, begin_y, newbegin_y, end_y, newend_y;
	bool loop = true;
	vector<string> endYear, beginYear, course_codes, programmeDetails, courseName;

	menu.clear_screen();
	cout << "Which part of programme course would you like to edit?" << endl;
	string options[] = { "Return", "Edit course on programme","Edit begin year of programme course", "Edit end year of programme course" };

	int choice = menu.create_menu("Please choose an option", options, 4, true);
	while (choice > 0) {
		//Database to be passed around as needed.

		switch (choice) {

		case 0:

			return;

			break;

			//case 1 allows the user to change course codes on programme
		case 1:

			// do-while allows user to execute function again 
			do{
				//do-while allows user to find correct programme
				do {
					clear_inputstream();

					vector<string> prog_list;

					db->sql_select("programme_id, programme_name", "programme", prog_list);

					cout << "Assessment ID | Assessment Name\n";

					for (int i = 0; i < prog_list.size(); i++)
						cout << prog_list[i] << endl;

					cout << "\n";

					cout << "Enter programme ID" << endl;
					getline(cin, programme_id);
					input_checker(programme_id);
					db->sql_select("*", "programme", "programme_id", programme_id, programmeDetails);

					// tells user value is not in database
					if (programmeDetails.size() == 0)
					{
						cout << "no programmes match that programme id" << endl;
						return;
					}

					cout << "ID  ||  name  ||  degree type  ||  attendance mode  ||  begin year  ||  end year  ||  date created  ||" << endl;
					cout << programmeDetails[0]<< endl;

				} while (!menu.yes_no_menu("Is this the correct programme?"));

				clear_inputstream();

            // to set the vector size to 0
				course_codes.resize(0);

            // show courses on selected programme
			db->sql_select("course_code", "programme_course", "programme_id", programme_id, course_codes);

			// tells user value is not in database
			if (course_codes.size() == 0)
			{
				cout << "no courses found for that programme id" << endl;
				return;
			}

			for(unsigned int i=0; i<course_codes.size(); i++)
				cout << "courses currently in programme: " << course_codes[i] << endl;

			clear_inputstream();
			cout << "Enter Course code to be changed" << endl;
			getline(cin, course_code);
			input_checker(course_code);

			clear_inputstream();
			cout << "Enter new Course code" << endl;
			getline(cin, newcourse_code);
			input_checker(newcourse_code);

			clear_inputstream();
			cout << "Is this correct?" << endl;

			//ask user if values are correct before entering into database
			if (menu.yes_no_menu("Programme id:   " + programme_id + "   Course code:   " + newcourse_code))
			{
				clear_inputstream();

				db->perform_sql_action("UPDATE programme_course SET course_code=\""+newcourse_code+'\"'+" WHERE "+ " programme_id" + "="+programme_id+ " AND course_code=\"" + course_code + '\"');

				// to set the vector size to 0
				course_codes.resize(0);
				db->sql_select("course_code", "programme_course", "programme_id", programme_id, course_codes);

				// tells user value does not exist in database
				if (course_codes.size() == 0)
				{
					cout << "no courses found for that programme id" << endl;
					return;
				}

				cout << "Course amended" << endl;
				cout << "Here is the new value added to the selected programme" << endl;

				for (unsigned int i = 0; i<course_codes.size(); i++)
					cout << "Courses on programme: " << course_codes[i] << endl;

				if (!menu.yes_no_menu("Would you like to edit another programme course?")) 
				{
					loop = false;
					return;
				}
			}
			
			else 
				cout << "function will restart" << endl;

	    	}while (loop);

		break;

		// case2 amends begin year
		case 2:
			
			//allows user to execute function again
			do{
				// allows user to find correct programme
				do {

					clear_inputstream();
					cout << "Enter programme ID" << endl;
					getline(cin, programme_id);
					input_checker(programme_id);

					db->sql_select("*", "programme", "programme_id", programme_id, programmeDetails);

					// tells user that value does nopt exist in database
					if (programmeDetails.size() == 0)
					{
						cout << "no programmes match that programme id" << endl;
						return;
					}

					cout << "ID  ||  name  ||  degree type  ||  attendance mode  ||  begin date  ||  end date  ||  date created  ||" << endl;
					cout << programmeDetails[0] << endl;

				} while (!menu.yes_no_menu("Is this the correct programme?"));

				// to set the vector size to 0
				course_codes.resize(0);
				db->sql_select("course_code", "programme_course", "programme_id", programme_id, course_codes);

				// tells user that value does not exist in database
				if (course_codes.size() == 0)
				{
					cout << "no courses found for that programme id" << endl;
					return;
				}

				for (unsigned int i = 0; i<course_codes.size(); i++)
					cout << "courses currently in programme: " << course_codes[i] << endl;

				// do while allows user to find the correct course
				do {
					clear_inputstream();
					cout << "Enter the course_code you would like to edit the begin year of" << endl;
					getline(cin, course_code);
					input_checker(course_code);

					db->sql_select("course_name", "course", "course_code", course_code, courseName);

					// tells user that the value does not exist in database
					if (courseName.size() == 0)
					{
						cout << "no courses found for that course code" << endl;
						return;
					}

					cout << "course_code:  " << course_code << "Course name: " << courseName[0] << endl;

				} while (!menu.yes_no_menu("Is this the correct course?"));

			
			db->perform_sql_action("SELECT begin_year FROM programme_course  WHERE  programme_id=\"" + programme_id + "\" AND course_code=\"" + course_code + '\"', beginYear);

			// tells user that the value does not exist in database
			if (beginYear.size() == 0)
			{
				cout << "no programme found for that course code and programme id " << endl;
				return;
			}

			cout << "Here is the begin year you would like to edit:   " << beginYear[0]<< endl;

			clear_inputstream();
			cout << "Enter new begin year" << endl;
			getline(cin, newbegin_y);
			input_checker(newbegin_y);

			cout << "Is this correct?" << endl;

			// asks user if values are correct before entering into database
			if (menu.yes_no_menu("Programme name:   " + programme_id + " Course code: " + course_code +"   Begin year:   " + newbegin_y))
			{
				db->perform_sql_action("UPDATE programme_course SET begin_year=\"" + newbegin_y + '\"' + " WHERE " + "programme_id" + "=\"" + programme_id + "\" AND course_code=\"" + course_code + '\"');

				cout << "Begin year amended" << endl;

				if (!menu.yes_no_menu("Would you like to edit another programme course?")) 
				{

					loop = false;
					return;
					
				}
					
			}

			else
				cout << "function will restart" << endl;

		    }while (loop);

			break;

			//case 3 amends end year
		case 3:

			//allows user to execute function again
			do {

				//allows user to find correct program
				do {

					clear_inputstream();
					cout << "Enter programme ID" << endl;
					getline(cin, programme_id);
					input_checker(programme_id);

					db->sql_select("*", "programme", "programme_id", programme_id, programmeDetails);

					// tells user that the value does not exist in database
					if (programmeDetails.size() == 0)
					{
						cout << "no programmes match that programme id" << endl;
						return;
					}

					cout << "ID  ||  name  ||  degree type  ||  attendance mode  ||  begin date  ||  end date  ||  date created  ||" << endl;
					cout << programmeDetails[0] << endl;

				} while (!menu.yes_no_menu("Is this the correct programme?"));

				// to set the vector size to 0
				course_codes.resize(0);
				db->sql_select("course_code", "programme_course", "programme_id", programme_id, course_codes);

				// tells user that the value does not exist in database
				if (course_codes.size() == 0)
				{
					cout << "no courses found for that programme id" << endl;
					return;
				}

				for (unsigned int i = 0; i<course_codes.size(); i++)
					cout << "courses currently in programme: " << course_codes[i] << endl;

				// do-while alows user to find correct course
				do {

					cout << "Enter the course_code you would like to edit the begin year of" << endl;
					getline(cin, course_code);
					input_checker(course_code);

					db->sql_select("course_name", "course", "course_code", course_code, courseName);

					// tells user that the value does not exist in database
					if (courseName.size() == 0)
					{
						cout << "no courses found for that course code" << endl;
						return;
					}
					cout << "course_code:  " << course_code << "Course name: " << courseName[0] << endl;

				} while (!menu.yes_no_menu("Is this the correct course?"));

			
				db->perform_sql_action("SELECT end_year FROM programme_course  WHERE  programme_id=\"" + programme_id + "\" AND course_code=\"" + course_code + '\"', endYear);

				// tells user that the value does not exist in database
				if (endYear.size() == 0)
				{
					cout << "no programme found for that course code and programme id" << endl;
					return;
				}
				db->perform_sql_action("SELECT begin_year FROM programme_course  WHERE  programme_id=\"" + programme_id + "\" AND course_code=\"" + course_code + '\"', beginYear);

				// tells user that the value does not exist in database
				if (beginYear.size() == 0)
				{
					cout << "no programme found for that course code or programe id" << endl;
					return;
				}

				cout << "Here is the end year you would like to edit:   " << endYear[0] << endl;
				cout << "Here is the begin year you would like to edit:   " << beginYear[0] << endl;

				clear_inputstream();
				cout << "Enter new end year (must be more than or equal to begin year)" << endl;
				getline(cin, newend_y);
				input_checker(newend_y);

				cout << "Is this correct?" << endl;

				//asks user if values are correct before entering into database
				if (menu.yes_no_menu("Programme name:   " + programme_id + " Course code: " + course_code + "  end year:   " + newend_y))
				{

					db->perform_sql_action("UPDATE programme_course SET end_year=\"" + newend_y + '\"' + "WHERE" + "programme_id" + "=\"" + programme_id + "\" AND course_code=\"" + course_code + '\"');

					cout << "end year amended" << endl;

					// to set the vector size to 0
					endYear.resize(0);
					db->sql_select("end_year", "programme_course", "programme_id", programme_id, endYear);

					// tells user that the value does not exist in database
					if (endYear.size() == 0)
					{
						cout << "no programme found for that programme id" << endl;
						return;
					}

					cout << "Here is the new value added to " << programme_id << "   " << endYear[0] << endl;

					if (!menu.yes_no_menu("Would you like to edit another programme course?")) {

						loop = false;
						return;

					}
				}

				else
					cout << "function will restart" << endl;

			} while (loop);

			break;
		}
	}
	return;
}

void Programme_course::view_programmeCourse(Database^ db) {
	string programme_id;
	vector<string> course, programmeDetails, course_bYear, course_eYear;
	bool loop = true;

	// do-while allows user to execute function again
	do {

		// allows user to find correct programme
		do {

			clear_inputstream();

			vector<string> prog_list;

			db->sql_select("programme_id, programme_name", "programme", prog_list);

			cout << "Assessment ID | Assessment Name\n";

			for (int i = 0; i < prog_list.size(); i++)
				cout << prog_list[i] << endl;

			cout << "\n";

			cout << "Enter programme ID" << endl;
			getline(cin, programme_id);
			input_checker(programme_id);

			db->sql_select("*", "programme", "programme_id", programme_id, programmeDetails);

			// tells user that the value does not exist in database
			if (programmeDetails.size() == 0)
			{
				cout << "no programmes match that programme id" << endl;
				return;
			}

			cout << "ID  ||  name  ||  degree type  ||  attendance mode  ||  begin date  ||  end date  ||  date created  ||" << endl;
			cout << programmeDetails[0] << endl;

		} while (!menu.yes_no_menu("Is this the correct programme?"));

		db->sql_select("course_code", "programme_course", "programme_id", programme_id, course);

		for (unsigned int i = 0; i < course.size(); i++)
		{
			db->perform_sql_action("SELECT begin_year FROM programme_course WHERE programme_id= " + programme_id + " AND course_code =\"" + course[i] + "\"", course_bYear);
			db->perform_sql_action("SELECT end_year FROM programme_course WHERE programme_id= " + programme_id + " AND course_code =\"" + course[i] + "\"", course_eYear);
		}

		// tells user that the value does not exist in database
		if (course.size() == 0)
		{
			cout << "no courses found for that programme id" << endl;
			return;
		}

		for (unsigned int i = 0; i < course.size(); i++)
		{
			cout << "Course code  ||  begin year  ||  end year  ||" << endl;
			cout <<course[i]<<"  "<<course_bYear[i] << "  " <<course_eYear[i]<< endl;
		}

	} while (menu.yes_no_menu("Would you like to view another course programme"));
	return;
}



//  input checker function allows user to re enter value
void Programme_course::input_checker(string inputs[]) {
	bool result = false;

	//do-while loops until the value is correct
	do
	{

		for (int i = 0; i < sizeof(inputs); i++)
			cout << "Value entered: " << inputs[i] << endl;

		if (menu.yes_no_menu("Are the above values correct "))
			result = true;

		else {
			clear_inputstream();
			cout << "Please re-enter both values" << endl;
			for (int i = 0; i < sizeof(inputs); i++)
			{
				clear_inputstream();
				getline(cin, inputs[i]);
			}
		}
	} while (!result);
}

//  input checker function allows user to re enter value
void Programme_course::input_checker(string& input) {
	bool result = false;

	//do-while loops until the value is correct
	do
	{
		cout << "Value entered:  " << input << endl;

		if (menu.yes_no_menu("Are the above values correct "))
			result = true;

		else
		{
			clear_inputstream();
			cout << "Please re-enter value " << endl;
			getline(cin, input);
		}
	} while (!result);
}

// clears the input stream
void Programme_course::clear_inputstream() {
	//Clear input buffer and ignore all chars until a newline.
	cin.clear();
	cin.ignore(INT_MAX, '\n');
}