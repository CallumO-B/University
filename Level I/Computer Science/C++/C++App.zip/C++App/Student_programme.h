// Created by Callum Owen-Bridge (15002504) latest version 22/03/2017
#pragma once
#include "Database.h"
#include "Student.h"
#include "Student_Course.h"
#include "Menu.h"
#include "Date.h"
#include "programme.h"
#include <iostream>
#include <string>
#include <vector>

using namespace std;
using namespace Database_Application;

// inheritance used to access functions from student and programme 
class Student_programme : public Student, Programme
{
public:

	Student_programme();

	// preconditon: gathers student ids and programme id
	//postcondition: enrols atudents on programme
	void enrol_on_programme(Database^ db);

	// preconditon:reads a file of students
	//postcondition: enrols many students on a program
	void enrol_many_on_programme(Database^ db);

	// preconditon:collects student id and programme id
	//postcondition: removes student from programme
	void remove_student_from_programme(Database^ db);

private:
	Student_Course student_course;
	Menu menu;
};