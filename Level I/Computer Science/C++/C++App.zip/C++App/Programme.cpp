// Created by Callum Owen-Bridge (15002504) latest version 22/03/2017

#include "Programme.h"

Programme::Programme() {}

// programme menu
void Programme::programme_menu(Database^ db) 
{

	db->change_database("uni_database");

	string options[] = {"Return", "View programme", "Amend programme", "Add programme", "Delete programme", "View students on a programme"};
	int choice=6;
	

	while (choice > 0) {
		int choice = menu.create_menu("Please choose an option", options, 6, true);

		switch (choice) {

		case 0:

			return;

			break;

		case 1:

			view_programme(db);

			break;

		case 2:

			amend_programme(db);

			break;

		case 3:

			add_programme(db);
	
			break;

		case 4:

			delete_programme(db);

			break;

		case 5:

			view_studentsOnprogramme(db);

			break;

		}

	}
}
 
// add a programme
void Programme::add_programme(Database^ db) {
	string name, research, degree_type, start_date, end_date, attendance_mode, values[6], columns[6] = {"programme_name", "degree_type", "attendance_mode", "begin_date", "end_date", "date_created"};
	char loop;
	bool loop2 = true;  loop = true;
	int number_values = 4;
	vector<string> assessment_id, programme_id;

	menu.clear_screen();

	//allows user to execute function again
	do {
		
		clear_inputstream();
		cout << "what will the programme be called ?" << endl;
		getline(cin, name);
		input_checker(name);
		values[0] = name;

		clear_inputstream();
		cout << "what will the research task be called ?" << endl;
		getline(cin, research);
		input_checker(research);

		clear_inputstream();
		cout << "what is the degree type ?" << endl;
		getline(cin, degree_type);
		input_checker(degree_type);
		values[1] = degree_type;

		clear_inputstream();
		cout << "Is this programnme full time or part time (Enter 'FT' for full time or 'PT' for part time)" << endl;
		getline(cin, attendance_mode);
		input_checker(attendance_mode);
		values[2] = attendance_mode;

		clear_inputstream();
		cout << "when is the start date ?" << endl;
		s_date.input_date();
		start_date = to_string(s_date.get_day());
		start_date += "/";
		start_date += to_string(s_date.get_month());
		start_date += "/";
		start_date += to_string(s_date.get_year());
		s_date.get_sql_date(values[3]);

		//do while makes sure user enters an end date more than the start date
		do {

		clear_inputstream();
		cout << "when is the end date ?" << endl;
		e_date.input_date();
		end_date = to_string(e_date.get_day());
		end_date += "/";
		end_date += to_string(e_date.get_month());
		end_date += "/";
		end_date += to_string(e_date.get_year());
		e_date.get_sql_date(values[4]);

			if (e_date < s_date)
				cout << "end date is less than start date, please re-enter end date";
			else
				break;

		} while (loop);

		date.set_to_current_date();
		date.get_sql_date(values[5]);

		//allows user to choose which part of the program to change if entered incorrectly
		do{

			clear_inputstream();
			cout << "Name: " << name << "  Research task: "<<research<<"  degree type:  " << degree_type << "  Programme start date:  " << start_date << endl;
			cout << "  Programme end date:  " << end_date << " Attendance mode: "<<attendance_mode<<" Date created: "<< values[5] <<endl;
			
			//asks user if the values are correct before entering into database
			if (menu.yes_no_menu("Is this the Programme you would like to store?"))
			{
				clear_inputstream();

				db->sql_insert(columns, 6, "programme", values, 6);
				db->perform_sql_action("SELECT MAX(programme_id) FROM programme", programme_id);

				//sql functions used to assign research task
				db->perform_sql_action("INSERT INTO assessment (assessment_name, research_task) VALUES(\"" + research + "\", 1)");
				db->perform_sql_action("SELECT MAX(assessment_id) FROM assessment", assessment_id);
				//tells user value does not exist
				if (assessment_id.size() == 0)
				{
					cout << "no assessment matches that assessment id" << endl;
					return;
				}

				//tells user value does not exist
				if (programme_id.size() == 0)
				{
					cout << "no programmes match that programme id" << endl;
					return;
				}

				db->perform_sql_action("INSERT INTO programme_research (programme_id, assessment_id, weighting) VALUES(" + programme_id[0] +", "+ assessment_id[0] +", 34)");

				cout <<" programme has been added"<<endl;

				if (!menu.yes_no_menu("Would you like to add another programme"))
					return;
			}

			// allows user to edit a certain part of the values previously entered
			else
			{
				clear_inputstream();
				string options[] = { "Return", "Amend Programme Name", "Amend Degree Type ", "Amend Start Date", "Amend End Date", "Amend Attendance Mode", "Amend research task name" };
				int choice = 1;

				while (choice > 0) {
					choice = menu.create_menu("Please select which one you would like to correct", options, 7, true);

					switch (choice) {

					case 0:


						break;

					case 1:
						clear_inputstream();
						cout << " Enter programme name  " << endl;
						getline(cin, name);
						input_checker(name);
						values[0] = name;
						break;

					case 2:
						clear_inputstream();
						cout << " Enter degree type  " << endl;
						getline(cin, degree_type);
						input_checker(degree_type);
						values[1] = degree_type;
						break;

					case 3:

						// do while to ensure the start date is less than end date
						do {
							clear_inputstream();
							cout << "when is the start date ?" << endl;
							s_date.input_date();
							start_date = to_string(s_date.get_day());
							start_date += "/";
							start_date += to_string(s_date.get_month());
							start_date += "/";
							start_date += to_string(s_date.get_year());

							if (s_date > e_date)
								cout << "start date is more than end date, please re-enter start date";

							else
							{
								values[2] = start_date;
								break;
							}

						} while (loop);
						break;

					case 4:

						// do while to emsure end date is not less than start date 
						do {
							clear_inputstream();
							cout << "when is the end date ?" << endl;
							e_date.input_date();
							end_date = to_string(e_date.get_day());
							end_date += "/";
							end_date += to_string(e_date.get_month());
							end_date += "/";
							end_date += to_string(e_date.get_year());
							e_date.get_sql_date(values[4]);

							if (e_date < s_date)
								cout << "end date is less than start date, please re-enter end date";

							else
							{
								values[3] = end_date;
								break;
							}

						} while (loop);
						break;

					case 5:

						clear_inputstream();
						cout << " Attendance mode  " << endl;
						getline(cin, attendance_mode);
						input_checker(attendance_mode);
						values[4] = attendance_mode;

						break;

					case 6:

						clear_inputstream();
						cout << " Research task name  " << endl;
						getline(cin, research);
						input_checker(research);

						break;
					}
				}
			}
		} while (loop2);
	} while (loop);
  return;
}

// amend a programme
void Programme::amend_programme(Database^ db) {
	string degree_type, start_date, end_date, research, attendance_mode, columns[5] = {"ID: ", "Name: ","Degree type: ", "Start date: ", "End date: "}, id, newname;
	vector<string> value, details, name, beginDate, endDate;

	menu.clear_screen();

	// do while allows user to find correct programme
	do {
		clear_inputstream();

		vector<string> assessments;

		db->sql_select("assessment_id, assessment_name", "assessment", assessments);

		cout << "Assessment ID | Assessment Name\n";

		for (int i = 0; i < assessments.size(); i++)
			cout << assessments[i] << endl;

		cout << "\n";

		cout << " what is the programme id you would like to edit " << endl;
		getline(cin, id);
		input_checker(id);

		db->perform_sql_action("SELECT * FROM programme WHERE programme_id =\"" + id + '\"', details);

		//tells user value does not exist
		if (details.size() == 0)
		{
			cout << "no programmes found for that programme id" << endl;
			return;
		}

		cout << "ID  ||  name  ||  degree type  ||  attendance mode  ||  begin date  ||  end date  ||  date created  ||" << endl;
		cout << details[0] << endl;

		db->perform_sql_action("SELECT programme_name FROM programme WHERE programme_id =\"" + id + '\"', name);

	} while (!menu.yes_no_menu("Is this the Programme you would like to amend?"));

	// menu allows user to amend specific parts of the programme
	string options[] = { "Return to previous", "Amend programme name", "Amend degree type ", "Amend start date", "Amend end date", "Amend attendance mode", "Amend research task name" };
	int choice = 1;

	while (choice > 0) {
		choice = menu.create_menu("Please choose which part of the programme you would to to amend", options, 7, true);
		switch (choice) {

		case 0:

			return;

			break;

		case 1:

			clear_inputstream();
			cout << " Enter new programme name  " << endl;
			getline(cin, newname);
			input_checker(newname);

			db->perform_sql_action("UPDATE programme SET programme_name =\"" + newname + '\"' + " WHERE " + "programme_name" + "=\"" + name[0] + "\" AND programme_id=\"" + id + '\"');

			cout << " Programme has been amended " << endl;

			break;

		case 2:

			clear_inputstream();
			cout << " Enter new degree type for:  " << name[0] << endl;
			getline(cin, degree_type);
			input_checker(degree_type);

			db->perform_sql_action("UPDATE programme SET degree_type =\"" + degree_type + '\"' + " WHERE " + "programme_name" + "=\"" + name[0] + "\" AND programme_id=\"" + id + '\"');

			cout << " Programme has been amended " << endl;

			break;

		case 3:

			// ensures start date is less than end date
			do {

				clear_inputstream();

				cout << " Enter new start date for:  " << name[0] << endl;

				s_date.input_date();
				start_date = to_string(s_date.get_day());
				start_date += "/";
				start_date += to_string(s_date.get_month());
				start_date += "/";
				start_date += to_string(s_date.get_year());

				db->perform_sql_action("SELECT end_date FROM programme WHERE programme_id =\"" + id + '\"', endDate);
				e_date.set_sql_date(endDate[0]);

			} while (s_date > e_date);

			db->perform_sql_action("UPDATE programme SET begin_date =\"" + start_date + '\"' + " WHERE " + "programme_name" + "=\"" + name[0] + "\" AND programme_id=\"" + id + '\"');

			cout << " Programme has been amended " << endl;

			break;

		case 4:

			// ensures end date is not less than start date
			do {

				clear_inputstream();

				cout << " Enter new end date for:  " << name[0] << endl;

				e_date.input_date();
				end_date = to_string(e_date.get_day());
				end_date += "/";
				end_date += to_string(e_date.get_month());
				end_date += "/";
				end_date += to_string(e_date.get_year());

				db->perform_sql_action("SELECT begin_date FROM programme WHERE programme_id =\"" + id + '\"', beginDate);
				s_date.set_sql_date(beginDate[0]);

			} while (e_date < s_date);

			db->perform_sql_action("UPDATE programme SET end_date =\"" + end_date + '\"' + " WHERE " + "programme_name" + "=\"" + name[0] + "\" AND programme_id=\"" + id + '\"');

			cout << " Programme has been amended " << endl;

			break;

		case 5:

			clear_inputstream();
			cout << " Enter new attendance mode:  " << name[0] << endl;
			getline(cin, attendance_mode);
			input_checker(attendance_mode);

			db->perform_sql_action("UPDATE programme SET attendance_mode =\"" + attendance_mode + '\"' + " WHERE " + "programme_name" + "=\"" + name[0] + "\" AND programme_id=\"" + id + '\"');
			cout << " Programme has been amended " << endl;

			break;

		case 6:

			clear_inputstream();
			cout << " Enter new research task name  " << name[0] << endl;
			getline(cin, research);
			input_checker(research);

			db->perform_sql_action("UPDATE programme_research SET research_name =\"" + research+ '\"' + " WHERE " + "assessment_name" + "=\"" + name[0] + "\" AND programme_id=\"" + id + '\"');
			cout << " Programme has been amended " << endl;

			break;
		}
	}	
	return;
}

// delete a programme
void Programme::delete_programme(Database^ db) {
	string id;
	vector<string>  programme_values, name;
	bool loop=true;
	menu.clear_screen();

	//allows user to execute function again
	do{
		do {
			
			clear_inputstream();

			vector<string> assessments;

			db->sql_select("assessment_id, assessment_name", "assessment", assessments);

			cout << "Assessment ID | Assessment Name\n";

			for (int i = 0; i < assessments.size(); i++)
				cout << assessments[i] << endl;

			cout << "\n";

			cout << " what is the id of the programme you would like to delete" << endl;
			getline(cin, id);
			input_checker(id);
			
			db->perform_sql_action("SELECT * FROM programme  WHERE  programme_id =\"" + id + '\"', programme_values);

			//tells user value does not exist
			if (programme_values.size() == 0)
			{
				cout << "no programmes found for that programme id" << endl;
				return;
			}

			cout << "ID  ||  name  ||  degree type  ||  attendance mode  ||  begin date  ||  end date  ||  date created  ||" << endl;
			cout << programme_values[0]<< endl;

		} while (!menu.yes_no_menu("Is this the correct programme?"));

		// asks user if the values are correct before entering into database
		if (menu.yes_no_menu("Is this the correct programme that you would like to delete"))
		{
			db->sql_delete("programme", "programme_id", id);

			cout << id << " Has been deleted " << endl;

			if (!menu.yes_no_menu("Would you like to delete another programme"))
				break;
		}

		else
			cout << " restarting function " << endl;

	} while (loop);

	return;

	}

// view a programme
void Programme::view_programme(Database^ db) {
	string name, id, degree_type, start_date, end_date;
	vector<string>  programme_values, programmes;

	menu.clear_screen();

	//allows user to execute program again
	do {
		// allows user to find correct program
		do {
			
			clear_inputstream();

			vector<string> prog_list;

			db->sql_select("programme_id, programme_name", "programme", prog_list);

			cout << "Assessment ID | Assessment Name\n";

			for (int i = 0; i < prog_list.size(); i++)
				cout << prog_list[i] << endl;

			cout << "\n";

			db->perform_sql_action("SELECT programme_id, programme_name FROM programme ", programmes);

			for (unsigned int i =0; i<programmes.size(); i++)
				cout <<programmes[i] << endl;

			cout << " what is the id of the programme you would like to view" << endl;
			getline(cin, id);
			input_checker(id);

			db->perform_sql_action("SELECT * FROM programme WHERE programme_id =" + id, programme_values);

			//tells user value does not exist
			if (programme_values.size() == 0)
			{
				cout << "no programme found for that programme id" << endl;
				return;
			}

			cout << "ID  ||  name  ||  degree type  ||  attendance mode  ||  begin date  ||  end date  ||  date created  ||" << endl;
			cout << programme_values[0]<<endl;

		} while (!menu.yes_no_menu("Is this the correct programme?"));

	} while (menu.yes_no_menu("Would you like to view another programme enter "));
	return;
}

//view students enrolle on programme
void Programme::view_studentsOnprogramme(Database^ db) {
	string programme_id;
	vector<string> course, students, programme_values, firstName, lastName;

	menu.clear_screen();

	// allows user to execute function again
	do {
		// allows user to find correct programme
		do {

			clear_inputstream();

			cout << "Enter programme ID" << endl;
			getline(cin, programme_id);
			input_checker(programme_id);
			
			db->perform_sql_action("SELECT * FROM programme  WHERE  programme_id =\"" + programme_id + '\"', programme_values);

			//tells user value does not exist
			if (programme_values.size() == 0)
			{
				cout << "no programmes found for that programme id" << endl;
				return;
			}

			cout << "ID  ||  name  ||  degree type  ||  attendance mode  ||  begin date  ||  end date  ||  date created  ||" << endl;
			cout << programme_values[0]<< endl;

		} while (!menu.yes_no_menu("Is this the correct programme? "));
		
		vector<string> ids;

			db->sql_select("student_id", "student_programme", "programme_id", programme_id, ids);

			//tells user value does not exist
			if (ids.size() == 0)
			{
				cout << "no students have been enrolled onto that programme" << endl;
				return;
			}
	
	    // displays student name and id
		for (unsigned int i = 0; i < ids.size(); i++)
		{

			db->sql_select("first_name ", "student", "student_id", ids[i], firstName);

			//tells user value does not exist
			if (students.size() == 0)
			{
				cout << "no students found in database" << endl;
				return;
			}

			db->sql_select("last_name ", "student", "student_id", ids[i], lastName);

			//tells user value does not exist
			if (students.size() == 0)
			{
				cout << "no students found in database" << endl;
				return;
			}

			cout << ids[i] << endl;
			cout << "Student:  " << ids[i]<<"  "<<firstName[i] << "  "<<lastName[i] << endl;
		}

	} while (menu.yes_no_menu("Would you like to view another programme containing students "));
	return;
}


//  input checker function allows user to re enter value
void Programme::input_checker(string inputs[]) {
	bool result = false;

	//do-while loops until the value is correct
	do
	{

		for (int i = 0; i < sizeof(inputs); i++)
			cout << "Value entered: " << inputs[i] << endl;

		if (menu.yes_no_menu("Are the above values correct "))
			result = true;

		else {
			clear_inputstream();
			cout << "Please re-enter both values" << endl;
			for (int i = 0; i < sizeof(inputs); i++)
			{
				clear_inputstream();
				getline(cin, inputs[i]);
			}
		}
	} while (!result);
}

//  input checker function allows user to re enter value
void Programme::input_checker(string& input) {
	bool result = false;

	//do-while loops until the value is correct
	do
	{
		cout << "Value entered:  " << input << endl;

		if (menu.yes_no_menu("Are the above values correct "))
			result = true;

		else
		{
			clear_inputstream();
			cout << "Please re-enter value " << endl;
			getline(cin, input);
		}
	} while (!result);
}

// clears the input stream
void Programme::clear_inputstream() {
	//Clear input buffer and ignore all chars until a newline.
	cin.clear();
	cin.ignore(INT_MAX, '\n');
}


