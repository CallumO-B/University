
/*
*	Date Class
*
*	Able to store dates, takes input from a user and splits
*	the date parts into a struct. Uses math functions on
*	dates when binary operators used to evaluate "value" of dates. 
*
*	Keiran Brown
*
*	Uses: Menu Constructor.
*/

#pragma once
#include <string>
#include <iostream>
#include <ctime>
#include <math.h>
#include "Menu.h"

using namespace std;
using namespace Menus;

//A small type definition for a short unsigned integer, used frequently as mostly small integer values are used here not going beyond '10^3'.
typedef short unsigned int shuint;

class Date
{

public:

	//Date constructor, this is empty as no initialisation is required, information needed from elsewhere.
	Date();

	/*Takes input from a user and splits the date input up, regardless of 
	delmiter used.*/
	void input_date();
	//Precondition: There are no preconditions when this function is called.
	//Postcondition: The user will be prompted to enter a date, which will be verified and saved into the instance of the Date class.

	//This function takes in an SQL style date and saves the data into the instance of the Date class.
	void set_sql_date(string sql_date);
	//Precondition: The string must be initialised with an SQL date.
	//Postcondition: The date contained in the string will be saved into the instance of the Date class.

	/*The parameters specify how the date should be set as shown in the 
	definition below.*/
	void set_date(shuint day, shuint month, shuint year);
	//Precondition: All integers initialised with correct values. So following the rules of a date (e.g. month is not more than 12).
	//Postcondition: Integers are stored inside the instance of the Date class.

	/*This function automatically gets the current system time (using "ctime" library) 
	and sets the date accordingly*/
	void set_to_current_date();
	//Precondition: There are no preconditions for this function.
	//Postcondition: The system time is used to initialised the instance of the Date class with the current date.

	/*This function will take in a string by reference and set the string to the date
	string (using the date that has been set) in the format that can be input to SQL*/
	void get_sql_date(string & date_string);
	//Precondition: An empty string is passed that has been declared, but not initialised.
	//Postcondition: The passed string will be initialised with a date in a format that is accepted by SQL.

	//This operator, evaluates if the: day, month and year, are all equal in two dates.
	bool operator==(Date& other);

	/*These functions evaluate which date "value" is greater or less. These also make 
	use of the equals operator overload where appropriate.*/
	bool operator>(Date& other);
	bool operator<(Date& other);
	bool operator>=(Date& other);
	bool operator<=(Date& other);

	//Accessor functions allowing access to parts of the date. 
	shuint get_day();
	shuint get_month();
	shuint get_year();
	//Precondition: A variable of type integer is declared and ready to catch the returned integer from any of these three accessor functions.
	//Postcondition: The parameter specified is retrieved from the instance of the Date class and returned from the function.

	//Returns whether the date instance has been initialised. (Returns "date_entered" bool value).
	bool is_entered();

private:

	//Structure for storing the different parts of the date in a small scope.
	struct Date_Parts
	{
		
		int day = 1;
		int month = 1;
		int year = 1900;

	};

	//Tracks whether the date has been entered or not.
	bool date_entered = false;

	//A very large integer for storing the value of the date. 
	long long date_value;

	//The menu is used for user friendly input.
	Menu menu;

	//Declare a structure to hold the date's parts.
	Date_Parts date_parts;

	//A string for keeping hold of the SQL friendly format of the currently held date.
	string sql_format_date;
	
	unsigned long long get_date_value();

};