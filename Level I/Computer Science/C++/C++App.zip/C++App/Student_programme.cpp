// Created by Callum Owen-Bridge (15002504) latest version 22/03/2017
#include "Student_programme.h"

Student_programme::Student_programme() {}

// enrol student onto programme
void Student_programme::enrol_on_programme(Database^ db) {
	string programme_id, level, student_id, columns[] = { "student_id","programme_id" };
	bool second_val = false;
	vector<string>  courses_level, courses, programmeDetails, value, assessment_id;
	int attempt;

	//allows user to execute function again
	do {
		menu.clear_screen();

		db->perform_sql_action("SELECT * FROM programme", programmeDetails);

		//tells user value does not exist
		if (programmeDetails.size() == 0)
		{
			cout << "no programmes in database" << endl;
			return;
		}

		//displays program details
		for (unsigned int i = 0; i < programmeDetails.size(); i++)
		{
			cout << "ID  ||  name  ||  degree type  ||  attendance mode  ||  begin date  ||  end date  ||  date created  ||" << endl;
			cout << programmeDetails[i] << endl;
		}

		cout << "Which student would you like to enrol  " << endl;
		student_id = get_student_id(db);

		//tells user value does not exist
		if (student_id == "NO STUDENTS FOUND")
		{
			cout << "No students found" << endl;
			return;
		}

		// due to inheritance student_programme class can use functions from Programme class
		Programme::clear_inputstream();

		cout << "Which programme would you like to enrol the student on (Enter programme id)" << endl;
		getline(cin, programme_id);

		Programme::input_checker(programme_id);

		db->perform_sql_action("SELECT assessment_id FROM programme_research WHERE programme_id = "+ programme_id, assessment_id);

		//tells user value does not exist
		if (assessment_id.size() == 0)
		{
			cout << "no assessments match that programme id" << endl;
			return;
		}

		db->perform_sql_action("INSERT INTO student_assessment (student_id, assessment_id) VALUES ("+ student_id +", " + assessment_id[0] +" )");

		Programme::clear_inputstream();
		cout << "What level would you like to enrol the student on" << endl;
		getline(cin, level);
		Programme::input_checker(level);

		db->perform_sql_action("INSERT INTO student_programme (student_id, programme_id) VALUES (" + student_id + ", " + programme_id + ")");
		cout << "Student has been enrolled onto the programme" << endl;

		db->sql_select("course_code", "course", "course_level", level, courses_level);

		//tells user value does not exist
		if (courses_level.size() == 0)
		{
			cout << "no courses found for that level" << endl;
		}

		db->sql_select("course_code", "programme_course", "programme_id", programme_id, courses);

		//tells user value does not exist
		if (courses.size() == 0)
		{
			cout << "no courses found for that programme id" << endl;
		}

		// try catch to catch ran out of memory exception
		try
		{
			string* enrol_courses = new string[courses.size()];
		}
		catch(bad_alloc)
		{
			cout << "Ran out of memory";
			exit(0);
		}

		Programme::clear_inputstream();
		cout << "Student will now be enrolled onto the courses associated with this programme" << endl;

		//for lops and if statment used to enrol students onto program
		for (unsigned int i = 0; i < courses_level.size(); i++)
		{
			for (unsigned int j = 0; j < courses.size(); j++)
			{
				if (courses_level[i] == courses[j])
				{
					cout << courses[j] << endl;
					cout << "How many attempts has the student made for this course (if first attempt enter 1)" << endl;
					cin >> attempt;
					student_course.enrol_student(db, student_id, courses[j], to_string(attempt));
					cout << "Student has been enrolled onto the course" << endl;
				}
			}
		}
	} while (menu.yes_no_menu("Would you like to enrol another student onto a programme? "));
}

// enrol many students on programme
void Student_programme::enrol_many_on_programme(Database^ db) {
	string student_id, course_name, dates, file_name, level;
	ifstream in_stream;
	int attempt;
	vector<string> course, value, courses_level, courses;
	char delimeter;

	menu.clear_screen();

	//allows user to execute function again
	do {

	  	string programme_id;
		cout << "Please enter the programme id you would like to enrol these students onto" << endl;
		cin >> programme_id;

		vector<string> ids;
		insert_student_by_file(db, ids);

		for (unsigned int i = 0; i < ids.size(); i++)
			db->perform_sql_action("INSERT INTO student_programme (student_id, programme_id) VALUES (" + ids[i] + ", " + programme_id + ")");

		// closes file stream
		in_stream.close();

		Programme::clear_inputstream();
		cout << "What level would you like to enrol the student on" << endl;
		getline(cin, level);
		Programme::input_checker(level);

		db->sql_select("course_code", "course", "course_level", level, courses_level);

		//tells user value does not exist
		if (courses_level.size() == 0)
		{
			cout << "no courses found for that level" << endl;
		}

		db->sql_select("course_code", "programme_course", "programme_id", programme_id, courses);

		//tells user value does not exist
		if (courses.size() == 0)
		{
			cout << "no courses found for that programme id" << endl;
		}

		string* enrol_courses;
		//try catch to catch the ran out of memory exception
		try
		{
			enrol_courses = new string[courses.size()];
		}
		catch (bad_alloc)
		{
			cout << "Ran out of memory";
			exit(0);
		}
		
		Programme::clear_inputstream();
		cout << "Student will now be enrolled onto the courses associatedd with this programme" << endl;

		cout << "How many attempts has the student made for this course (if first attempt enter 1)" << endl;
		cin >> attempt;

		// foor loops and if statment enrols stduent onto programme
		for (unsigned int i = 0; i < courses_level.size(); i++)
		{
			for (unsigned int j = 0; j < courses.size(); j++)
			{
				
				if (courses_level[i] == courses[j])
				{
					for (unsigned int k = 0; k < courses.size(); k++)
					{
						cout << courses[j] << endl;
						student_course.enrol_student(db, ids[k], courses[j], to_string(attempt));
						cout << "Student has been enrolled onto the course" << endl;
					}
				}
			}
		}

		delete[] enrol_courses;
	} while (menu.yes_no_menu("Would you like to enrol another batch of students onto a programme? "));
	return;
}

// remove student from programme
void Student_programme::remove_student_from_programme(Database^ db) {
	string programme_id, student_id, course_code;
	bool loop = true;
	vector<string>  programmeDetails;

	menu.clear_screen();

	//allows user to execute function again
	do {

		//allows user to find correct program
		do {

			Programme::clear_inputstream();
			cout << "Please enter the programme id you would like to remove a student from" << endl; ///////// change /////////
			cin >> programme_id;
			input_checker(programme_id);

			db->sql_select("*", "programme", "programme_id", programme_id, programmeDetails);

			//tells user value does not exist
			if (programmeDetails.size() == 0)
			{
				cout << "no programmes found for this programme id" << endl;
				return;
			}

			cout << "Here is the programme for " << programme_id<< endl;

		} while (!menu.yes_no_menu("Is this the correct programme ? "));

		cout << "Which student would you like to remove from the course: " << programme_id<< endl;
		student_id=get_student_id(db);

		//tells user value does not exist
		if (student_id == "NO STUDENTS FOUND")
		{
			cout << "No students found" << endl;
			return;
		}

		//asks user if the values are correct before entering into database
		if (menu.yes_no_menu("Would you like to remove student id:  " + student_id + "  from programme:  " + programme_id))
		{
			db->sql_delete("student_course", "student_id", student_id);

			cout << "Student removed" << endl;

			if (!menu.yes_no_menu("Would you like to remove another student? "))
				break;
		}

		else
			cout << "Function restarting" << endl;

	} while (loop);
	return;
}