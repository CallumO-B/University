#include "Database.h"
#include <iostream>
#include <string>
#include <vector>
#include <conio.h>

#include <msclr\marshal_cppstd.h>


using namespace std;
using namespace System;
using namespace System::Collections;
using namespace MySql::Data::MySqlClient;
using namespace Database_Application;



Database::Database()
{

	login();

}

void Database::login()
{

	cout << "Please login to database" << endl;

	string user_name, password = "";

	cout << "Enter Username: " << endl;
	cin >> user_name;

	cout << endl << "Enter Password: " << endl;

	//Track how many characters are currently entered to console by user.
	int num_of_chars = 0;

	//Create char to store password character.
	char pass_char;

	//While user is entering password and has not hit return "\r".
	while ((pass_char = _getch()) != '\r')
	{

		//Check for backspaces entered and that the number of characters is not zero.
		if (pass_char == '\b' && num_of_chars > 0)
		{

			//Decrease the number of characters.
			num_of_chars--;

			//Erase once, overwrite last printed char with a space and go back again.
			cout << "\b \b";
			password.pop_back();

		}
		else
		{

			num_of_chars++;

			//Otherwise add the current char to the password and put a "*" in the console.
			password.push_back(pass_char);
			_putch('*');
		}


	}

	cout << "\n\n";

	string login_info;

	login_info += "username=" + user_name + ';';

	login_info += "password=" + password + ';';
	login_info += "convert zero datetime=True";

	String^ login_info_convert = gcnew String(login_info.c_str());

	//Remove information from strings.
	user_name = password = "";

	//Default setup to be concatenated with gathered info...
	String^ connectionInfo = "datasource=localhost;port=3306;";

	connectionInfo = String::Concat(connectionInfo, login_info_convert);

	login_info_convert = "";

	try
	{

		cout << "Attempting connection...";

		conn = gcnew MySqlConnection(connectionInfo);
		conn->Open();

	}
	catch (MySqlException^ ex)
	{

		Console::WriteLine("\nException: " + ex->Number);

		if (ex->Number == 1042)//Connection Exception.
		{

			Console::WriteLine("\nUnable to connect, please ensure database connection.");
			//conn->Close();
			//exit(0);

		}
		else if (ex->Number == 0)//Incorrect Login Exception.
		{

			Console::WriteLine("\nIncorrect Login, Please try again.");

		}
		else
		{

			Console::WriteLine("\nUnknown Exception");

		}

		conn->Close();
		login();
	}

	connectionInfo = "";

	conn->Close();

}

void Database::change_database(string database_name)
{

	conn->Open();

	String^ database_name_convert = gcnew String(database_name.c_str());

	try
	{

		conn->ChangeDatabase(database_name_convert);

	}
	catch (Exception^ex)
	{

		Console::WriteLine(ex->Message);

	}



	conn->Close();


}

//Selects from table, only field specified. ~ SELECT column FROM db_table ~
void Database::sql_select(string column, string table, vector<string> &values_to_return)
{

	//Construct query as a std::string.
	string query_construct = "SELECT " + column + " FROM " + table;

	//Perform action and then read datastream.
	perform_sql_action(query_construct, values_to_return);

}

//Selects from table, field and condition specified. ~ SELECT column FROM table WHERE specify_column=specify_value ~
void Database::sql_select(string column, string table, string specify_column, string specify_value, vector<string> &values_to_return)
{

	//Construct query as a std::string.
	string query_construct = "SELECT " + column + " FROM " + table + " WHERE " + specify_column + "=\"" + specify_value + "\"";

	perform_sql_action(query_construct, values_to_return);

}

//Inserts an array of data into a table of field specified by another array, all lengths passed. ~ INSERT INTO db_table (col[0], col[1], ...) VALUES (val[0], val[1], ...) ~
void Database::sql_insert(const string columns[], int columns_size, string table, const string values[], int values_size)
{

	string query_construct = "INSERT INTO " + table + " (" + columns[0];

	for (shuint i = 1; i < columns_size; i++)
	{

		query_construct += ", " + columns[i];

	}

	query_construct += ") VALUES (\"" + values[0] + '\"';

	for (shuint i = 1; i < values_size; i++)
	{

		query_construct += ", \"" + values[i] + '\"';

	}

	query_construct += ')';

	//Send query off.
	perform_sql_action(query_construct);


}

//Updates value of specified field where value of that/another field is equal to specified value. ~ UPDATE table SET specify_column=new_value WHERE query_column=query_value ~
void Database::sql_update(string specify_column, string table, string new_value, string query_column, string query_value)
{

	string query_construct = "UPDATE " + table + " SET " + specify_column + "=\"" + new_value + '\"' + " WHERE " + query_column + "=\"" + query_value + '\"';

	perform_sql_action(query_construct);

}

void Database::sql_delete(string table, string specify_column, string specify_value)
{

	string query_construct = "DELETE FROM " + table + " WHERE " + specify_column + "=\"" + specify_value + "\"";

	perform_sql_action(query_construct);

}

//Searches for keywords in a table in a certain column, returns each row matched.
void Database::keyword_search(const string search_column, const string table, vector<string> &rows, bool return_all_fields)
{

	cout << "Press enter to continue..." << endl;

	//Get user input.
	cout << "\nPlease enter the term you would like to search" << endl;


	string key_term;
	getline(cin, key_term);

	cout << "You entered: " << key_term << endl;

	vector<string> comparison, full_details;

	//Perform keyword search.
	change_database("uni_database");
	perform_sql_action("SELECT " + search_column + " FROM " + table, comparison);

	if(return_all_fields)
		perform_sql_action("SELECT * FROM " + table, full_details);

	for (size_t i = 0; i < comparison.size(); i++) {

		if (search_string(key_term, comparison[i]))
			if (return_all_fields)
				rows.push_back(full_details[i]);
			else
				rows.push_back(comparison[i]);

	}

	return;

}

bool Database::search_string(string key_term, string comparison) {

	//Check for strings that are too short, prevents stack overflow!
	if (key_term.length() <= 1) {

		return false;

	}

	//Track when searches start.
	bool start_search = false;

	//Trackers, keyword index, matched and different chars.
	size_t j = 0, matches = 0, differences = 0;

	//Iterate through comparison string.
	for (size_t i = 0; i < comparison.length() && j < key_term.length(); i++) {

		//Look for matches.
		if (comparison[i] == key_term[j]) {

			//Start the search...
			start_search = true;
			matches++;

		}

		//After finding at lease one match, start tracking differences.
		if (start_search && (comparison[i] != key_term[j]))
			differences++;

		//Increment key index to forward search.
		if (start_search)
			j++;

	}

	//If started search and matched, return true.
	if (start_search && (matches > differences))
	{

		return true;

	}
	//If started the search and not matched, return false.
	else if (start_search && (matches < differences))
	{

		return false;

	}
	//Otherwise, call function again with first keyword char removed.
	else
	{

		key_term.erase(0, 1);
		return search_string(key_term, comparison);

	}


}

//Takes in commands and converts strings to allow SQL comms to take place. Catches exceptions from connections.
void Database::perform_sql_action(string sql_command, vector<string> &return_values)
{

	conn->Open();

	sql_command += ';';

	//Debug display.
	//cout << endl << "Your SQL command is: " + sql_command << endl;

	String^ query = gcnew String(sql_command.c_str());

	//Create command on connection.
	MySqlCommand^ connCmd = gcnew MySqlCommand(query, conn);

	try
	{

		//Execute command.
		dataReader = connCmd->ExecuteReader();

		//cout << "Performing command...";

		int field_count = dataReader->FieldCount;

		while (dataReader->Read())
		{



			//Create dynamic array that will carry all fields.
			string *row;
			row = new string[field_count];

			//Read all fields
			for (shuint i = 0; i < field_count; i++)
			{


				//Check for null values.
				if (dataReader->IsDBNull(i))
				{

					//Enter a NULL in to account for error.
					row[i] == "NULL";


				}//End if

				else if (dataReader->GetDataTypeName(i) == "DATE")
				{

					//Convert date to readable format from database.
					String^ date_read = dataReader->GetDateTime(i).ToString("dd/MM/yyyy");
					row[i] = msclr::interop::marshal_as<std::string>(date_read);

				}

				else

				{

					//If no other conditions satisfied, read field normally.
					String^ string_read = dataReader->GetString(i);
					row[i] = msclr::interop::marshal_as<std::string>(string_read);



				}//End Else

			}//End For

			string current_row;

			//Concatenate elements to form a row.
			for (shuint i = 0; i < field_count; i++)
			{

				current_row += row[i];

				if (field_count > 1)
					current_row += ';';

			}

			//Push row onto vector.
			return_values.push_back(current_row);

		}//End While

		last_exception = 0;

	}//End Try
	catch (MySqlException^ex) //Catch any exceptions.

	{

		last_exception = ex->Number;

		String^ output_message = ex->Message;

		//Write said exceptions to console.
		Console::WriteLine("\nException: " + output_message);



		if (output_message->Contains("Unable to connect to any of the specified MySQL hosts"))
		{

			Console::WriteLine("Please ensure connection to database");

		}

		conn->Close();

		return_values.resize(0);
		return;

	}//End Catch

	//Debug
	//cout << "Successful!" << endl;

	conn->Close();

}

void Database::perform_sql_action(string sql_command)
{

	conn->Open();

	sql_command += ';';

	//Debug
	cout << endl << "Your SQL command is: " + sql_command << endl;

	String^ query = gcnew String(sql_command.c_str());

	//Create command on connection.
	MySqlCommand^ connCmd = gcnew MySqlCommand(query, conn);

	try
	{

		//Execute command.
		dataReader = connCmd->ExecuteReader();

		//cout << "Performing command..." << endl;

		last_exception = 0;

	}
	catch (MySqlException^ex)
	{	//Catch any exceptions.

		//Write said exceptions to console.
		Console::WriteLine("\nException: " + ex->Message);

		last_exception = ex->Number;

		conn->Close();
		return;

	}

	//Debug
	//cout << "Successful!" << endl;

	conn->Close();

}

int Database::get_last_exception() {

	int exception = last_exception;

	last_exception = 0;

	return exception;

}