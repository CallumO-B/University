#include "Assessment.h"


void Assessment::assessment_menu(Database^ database)
{


	//Options for menu.
	string options[] = {

		"Return to Previous Menu",
		"Create a New Assessment",
		"View an Assessment",
		"Amend an Assessment",
		"Remove an Assessment"

	};

	int choice = 1;

	//Keep asking user until '0' is chosen and function exits.
	do {

		//Ask user which function they would like to go to.
		choice = menu.create_menu("Please choose an option", options, 5, true);

		//Clear screen after choosing a function.
		menu.clear_screen();

		//Go to appropriate function based on user choice.
		switch (choice)
		{

		case 0:

			return;

			break;

		case 1:

			create_assessment(database);

			break;

		case 2:

			view_assessment(database);

			break;

		case 3:

			amend_assessment(database);

			break;

		case 4:

			remove_assessment(database);

			break;

		}
	} while (choice > 0);

	return;

}

void Assessment::create_assessment(Database^ database)
{

	menu.clear_screen();

	//Ask user for the Assessment name.
	cout << "Please enter an Assessment Name" << endl;

	//Clear inputstream for successful user entry.
	clear_inputstream();
	
	//Get Assessment name from user.
	string name;
	getline(cin, name);

	//Ask user if this is a Research Task or not.
	int research_task = menu.yes_no_menu("Is this Assessment a Research Task?");

	//Display the new Assessments details.
	cout << "Assessment Name: " << name << endl;
	cout << "Research Task: " << bool(research_task) << endl;

	//Ask user if they would like to insert these details for a new Assessment.
	int choice = menu.yes_no_menu("Are you sure you would like to insert these values?");

	//If they chose yes.
	if(choice)
	{

		//Insert the details into Assessment table.
		database->perform_sql_action("INSERT INTO assessment (assessment_name, research_task) VALUES (\"" + name + "\", " + to_string(research_task) + ")");

		//Inform user of successful entry.
		cout << "Assessment Inserted" << endl;

	}
	else //If the user chose No.
	{

		//Inform user that the assessment has not been entered.
		cout << "Assessment Not Inserted" << endl;

	}

	return;

}

void Assessment::view_assessment(Database^ database)
{
	
	//Ask user to find assessment.
	string id = find_assessment(database);

	//Store assessment details in a vector.
	vector<string> assessment;

	//Select all details for that Assessment based on that ID.
	database->sql_select("*", "assessment", "assessment_id", id, assessment);

	//Check if no assessments were returned.
	if (assessment.size() == 0)
	{

		//Inform user and return from funtion.
		cout << "No Assessments Found!" << endl;
		return;

	}

	//Change the delimiters for readability.
	fix_delimiters(assessment[0]);

	//Clear screen to view chosen Assessment.
	menu.clear_screen();

	//Output field headers and corresponding Assessment details.
	cout << "Assessment ID | Assessment Name | Research Task" << endl;
	cout << assessment[0] << endl;

	//Allow user to view before pressing enter to return.
	cout << "Press Enter to Continue" << endl;
	clear_inputstream();
	clear_inputstream();

	return;

}

void Assessment::amend_assessment(Database^ database)
{

	//Ask user to find assessment, get the Assessment ID.
	string assessment_id = find_assessment(database);

	//Options for menu.
	string options[] = {

		"Return",
		"Assessment Name",
		"Research Task"

	};

	//Display options, ask user which field they would like to edit.
	int choice = menu.create_menu("Which Item Would You Like to Amend?", options, 3, true);

	//Go to case, based on user choice.
	switch (choice)
	{

	case 0:

		return;

		break;

	case 1:
		{

			//Clear inputstream for successful user entry.
			clear_inputstream();
			cout << "Please Enter a New Assessment Name" << endl;

			//Ask user for the new Assessment name to edit this record with.
			string new_name;
			getline(cin, new_name);

			//Edit the record to user's specification.
			database->sql_update("assessment_name", "assessment", new_name, "assessment_id", assessment_id);
		}

		break;

	case 2:

		//Clear inputstream for successful user entry.
		clear_inputstream();

		//Ask user if this should be a research task or not.
		int research_task = menu.yes_no_menu("Would You Like to Set This Assessment to a Research Task?");

		//Make change to Asssessment based on user specification.
		database->sql_update("research_task", "assessment", to_string(research_task), "assessment_id", assessment_id);

		break;

	}

	cout << "Your New Value Has Been Inserted!" << endl;

	return;

}

void Assessment::remove_assessment(Database^ database)
{

	//Ask user to find an Assessment.
	string assessment_id = find_assessment(database);
	
	//Check if any Assessments were found during the search.
	if (assessment_id == "NO ASSESSMENTS FOUND")
	{

		//If not, inform the user and exit the function.
		cout << "No Assessments Found!" << endl;
		return;

	}

	//Store the found Assessment details into a vector.
	vector<string> assessment;

	//Search for the specified Assessment.
	database->perform_sql_action("SELECT * FROM assessment WHERE assessment_id=" + assessment_id, assessment);

	//Check if anything was found using that ID.
	if (assessment.size() == 0)
	{

		//Inform user and exit function if not, so they may try again.
		cout << "No Assessments Found!" << endl;
		return;

	}
	
	//Replace the delimiters with spaces and '|' chars for readability.
	fix_delimiters(assessment[0]);
	
	//Display column headers and the Assessment chosen.
	cout << "Assessment ID | Assessment Name | Research Task" << endl;
	cout << assessment[0] << endl;

	string input;

	//Keep looping until the user makes a decision.
	do {

		//Ask user to enter the Assessment ID for verification purposes.
		cout << "Please Enter the Assessment ID to Delete, or Enter 'N' to Return" << endl;
		cin >> input;

		//If they type 'N' exit the function, abort deletion.
		if (input[0] == 'N' || input[0] == 'n')
			return;

	} while (input != assessment_id); //As long as the user has not entered the ID.


	//If here is reached, the user has verified the deletion, remove the Assessment.
	database->sql_delete("assessment", "assessment_id", assessment_id);

	//Inform user that Assessment has been deleted.
	cout << "Assessment Deleted!" << endl;

	return;

}

//Removes ';' and replaces them with " | ".
void Assessment::fix_delimiters(string &input)
{

	//Replace all ';' with " |".
	string insert_value = " |";

	//Go through entire string looking for delimiters.
	for (size_t i = 0; i < input.length(); i++)
	{

		if (input[i] == ';')
		{

			input[i] = ' ';
			input.insert(i, insert_value);

		}

	}

	return;

}

string Assessment::find_assessment(Database^ database)
{

	//Ask user if they cqan specify an ID.
	int choice = menu.yes_no_menu("Can you specify the Assessment ID?");

	//String to store the Assessment ID.
	string id;

	//If the user can specify an ID.
	if (choice)
	{
		
		//Track valid inputs.
		bool valid_input = true;

		//Keep asking until input is valid.
		do {

			//Ask user for an Assessment ID.
			cout << "Please enter the Assessment ID" << endl;
			cin >> id;

			//Check ID is valid (is numerical).
			for (int i = 0; i < id.length(); i++)
			{
				
				//Check each char in turn is a digit.
				if (!isdigit(id[i]))
					valid_input = false;
				
			}

			//Inform user that that input was not valid.
			if(!valid_input)
				cout << "That input was invalid" << endl;

		} while (!valid_input);

	}
	else //If the user cannot specify an ID.
	{

		//Vector to store Asessments from search.
		vector<string> assessments;

		menu.clear_screen();

		//Clear inputstream for search term inputs.
		clear_inputstream();
		cout << "Please Enter the Name of the Assessment You Wish to Find" << endl;
		
		//Take user to keyword search for Assessments.
		database->keyword_search("assessment_name", "assessment", assessments, true);

		//Check if anything matched.
		if (assessments.size() == 0)
		{

			return "NO ASSESSMENTS FOUND";

		}

		//Dynamic array to store assessments returned from search.
		string * options = new string[assessments.size()];

		//Insert all Assessments from search into dynamic array.
		for (int i = 0; i < assessments.size(); i++)
			options[i] = assessments[i];
		
		//Allow user a choice of Assessment from their search.
		int choice = menu.create_menu("Please choose an Assessment", options, assessments.size(), true);
		
		//Empty vector, finished with this now.
		assessments.resize(0);

		//Extract the Assessment ID from the chosen Assessment.
		for (int i = 0; i < options[choice].length(); i++)
		{

			//When the first semicolon is found, break out of the loop.
			if (options[choice][i] == ';')
				break;

			//Keep adding chars onto Assessment ID string.
			id += options[choice][i];

		}
		
		//Release memory back to the freestore.
		delete[] options;
	}


	//Return the ID desired Assessment by the User.
	return id;

}

void Assessment::clear_inputstream()
{

	//Clear input buffer and ignore all chars until a newline.
	cin.clear();
	cin.ignore(INT_MAX, '\n');

	return;

}