#include "Transcript.h"
#include "Programme.h"
#include "Programme_Course.h"
#include "Course.h"
#include "Assessment.h"
#include "Student_Course.h"
#include "Student_programme.h"
#include "Student.h"
#include "Mark.h"
#include "Menu.h"
#include "Admin.h"
#include "Backup.h"


void programme_options(Database^ db);
void student_options(Database^ db);
void student_enrolment(Database^ db);
void course_options(Database^ db);
void uni_options(Database^ db);

void student_transcript(Database^ db);

int main()
{
		
	//Enables displaying of menus for user interaction.
	Menu menu;
	Assessment assessment;
	Admin admin;
	Backup backup;

	//Clear screen before beginning.
	menu.clear_screen();

	//Initialise database.
	Database^ db = gcnew Database();

	db->change_database("uni_database");

	short unsigned int choice = 0;

	do
	{

		//Ensure that the main database is in use.
		db->change_database("uni_database");

		//Main menu options.
		string options[] =
		{

				"Exit Program",
				"Programme Options",
				"Course Options",
				"Assessment Options",
				"Student Options",
				"University Details", 
				"Administration Options",
				"Backup Options"

		};
				
		menu.clear_screen();

		//Create a menu that allows user choice of the main menu options.
		choice = menu.create_menu("Please choose an option to begin", options, 8, true);

		//Clear the screen, a menu option has been chosen and the program will now move on.
		menu.clear_screen();

		switch (choice)
		{

		case 0:

			cout << "Program Ended\n\n";

			exit(0);
			return 0;

			break;

		case 1:

			programme_options(db);

			break;

		case 2:

			course_options(db);

			break;

		case 3:

			assessment.assessment_menu(db);

			break;

		case 4:

			student_options(db);

			break;

		case 5:

			uni_options(db);

			break;

		case 6:

			admin.admin_menu(db);

			break;

		case 7:

			backup.backup_menu(db);

			break;

		default:

			//If this point is reached, this means that the menu has failed somehow, or the database has had an issue.
			cout << "Something went wrong, are you sure you are connected to the database? Closing...." << endl;
			exit(1);

			break;

		}


	} while (choice > 0);
	cout << "Program Ended\n\n";

	exit(0);
	return 0;
}



void programme_options(Database^ db) {

	Menu menu;
	Programme programme;
	Programme_course programme_course;

	string options[] = {

		"Return to Main Menu",
		"Programme Options",
		"Programme Courses Options"

	};

	size_t choice = menu.create_menu("Please choose an option", options, 3, true);

	switch (choice) 
{

	case 0:

		return;

		break;

	case 1:
	
		//Take user to programme options.
		programme.programme_menu(db);
	
		break;

	case 2:
		
		//Take user to programme course options.
		programme_course.programmeCourse_menu(db);
	
		break;

	}

}

void student_options(Database^ db) 
{

	//This function needs use of Menu and Student class instances.
	Menu menu;
	Student student;
	Student_Course student_course;
	Mark mark;

	//Student Options menu options.
	string options[] = {

		"Return to Previous Menu",
		"Create, Edit and View Students",
		"Student Assessment Marking",
		"Student Enrolment",
		"Student Transcript"

	};

	//Ask user to choose what kind of student option they would like to use.
	int choice = menu.create_menu("Please select an option", options, 5, true);

	//Go to function that user has specified.
	switch (choice) 
	{

	case 0:
		
		return;

		break;

	case 1:

		//Take user to student operations.
		student.main_menu(db);

		break;

	case 2:
		
		//Take user to assessment marking.
		mark.mark_menu(db);

		break;

	case 3:

		//Take user to student enrolement menu.
		student_enrolment(db);

		break;

	case 4:

		//Take user to transcript operations.
		student_transcript(db);

		break;

	case 5:


		break;
	}

	return;

}

void student_enrolment(Database^ db)
{

	string options[] = {

		"Return to Previous Menu",
		"Student Course Enrolment",
		"Student Programme Enrolment",
		"Remove Student from Programme"


	};

	Menu menu;
	int choice = menu.create_menu("Please choose an option", options, 4, true);


	switch (choice) 
	{

	case 0:

		return;

		break;

	case 1:
	{

		//Take user to student course operations.
		Student_Course student_course;
		student_course.Student_Course_menu(db);
	}

		break;

	case 2:
	{

		//Take user to enrol a student on a programme.
		Student_programme stu_prog;

		//Ask user if they would like to enrol using a file.
		if (menu.yes_no_menu("Would you like to enrol many students by file?"))
			stu_prog.enrol_many_on_programme(db);
		else
			stu_prog.enrol_on_programme(db);

	}

		break;


	case 3:
	{

		//Take user to remove a student from a programme.
		Student_programme stu_prog;
		stu_prog.remove_student_from_programme(db);

	}

		break;
	}

	return;

}

void course_options(Database^ db)
{

	//Take user to course operations.
	Course course;
	course.CourseMenu(db);

}

void student_transcript(Database^ db) 
{

	Menu menu;

	string options[] = {

		"Return", 
		"Single Student Transcript",
		"Many Student Transcripts"

	};

	int choice = menu.create_menu("Please select a transcript option", options,  3, true);

	switch (choice) {

	case 0:

		return;

		break;

	case 1:

		{

			//Have user input or search for a student for the student ID.
			Student student;
			string student_id = student.get_student_id(db);

			if (student_id == "EXIT")
				return;

			//Display the specified transcript.
			Transcript transcript;
			string output;
			try
			{
				
				//Output a single student transcript based on user input.
				output = transcript.display_transcript(db, student_id);
								
			}
			catch (Unregistered e) //Catch unregistered student exceptions.
			{

				cout << "That student is not Registered on any Programmes!" << endl;

			}

			cout << output << endl;

			//Display a menu asking user about saving transcript.
			Menu menu;
			int user_choice = menu.yes_no_menu("Would you like to save this transcript?");

			//Create a file output stream.
			ofstream file;

			//If user chooses yes, print the transcript to a file.
			if (user_choice == 1)
				transcript.print_to_file(file, output);

			//Wait for a key press.
			cin.ignore(INT_MAX, '\n');

		}

		break;

	case 2:

		vector<string> student_ids;
		Student student;
		string student_id;

		do {

			student_id = student.get_student_id(db);

			if (student_id == "EXIT") 
{

				student_transcript(db);
				return;

			}

		} while (student_id == "NO STUDENTS FOUND");

		//Add first student ID, also makes the menu further down make more sense to the user!
		student_ids.push_back(student_id);

		//Options for menu.
		string options[] = {

			"Return to Previous Menu",
			"Stop Entering Students",
			"Choose Another Student"

		};

		
		Menu student_choosing_menu;

		bool choosing_students = true;

		//Whilst user wants to choose students.
		while(choosing_students)
		{

			//Display menu after each student chosen.
			int choice = student_choosing_menu.create_menu("Student Choosing Menu", options, 3, true);

			//Evaluate options based on user choice.
			switch (choice) 
{

			case 0:

				//If they choose return, return from this function.
				return;

				break;



			case 1:

				//If they choose to stop entering, this will end and the transcript printing can begin.
				choosing_students = false;

				break;



			case 2:

				//If they select to enter another student, have them find another and add it to the vector of student IDs.
				student_ids.push_back(student.get_student_id(db));

				break;

			}


		}

		//Array for holding student IDs.
		strptr students = new string[student_ids.size()];

		//Move all values to a dynamic array.
		for (unsigned int i = 0; i < student_ids.size(); i++)
			students[i] = student_ids[i];

		//Print out a batch of transcripts based on student ids entered.
		Transcript transcript;
		try
		{

			transcript.display_transcript(db, students, student_ids.size());

		}
		catch(Unregistered e)
		{

			cout << "That student is not Registered on any Programmes!" << endl;

		}


		return;

	}

	
}

//Allows user to view and edit university options.
void uni_options(Database^ db) 
{

	//Get all course codes in database.
	vector<string> values;
	db->sql_select("course_code", "course", values);

	//Get the number of course codes from vector telling how many courses there are.
	int num_of_courses = values.size();

	//Empty vector for new query.
	values.resize(0);

	//Get all student IDs from database.
	db->sql_select("student_id", "student", values);

	//Get the number of student IDs from vector telling how many students there are.
	int num_of_students = values.size();

	//Empty vector for new query.
	values.resize(0);

	//Get all information about the university.
	db->sql_select("*", "uni_information", values);

	//If no information entered, enter a row that can be edited.
	if (values.size() == 0)
	{
		db->perform_sql_action("INSERT INTO uni_information (university_name) VALUES (\"Liverpool Hope University\")");
		db->sql_select("*", "uni_information", values);
	}

	//Update the number of courses and students to latest values just obtained.
	db->perform_sql_action("UPDATE uni_information SET number_of_courses=" + to_string(num_of_courses));
	db->perform_sql_action("UPDATE uni_information SET number_of_students=" + to_string(num_of_students));

	//Notify user of action.
	cout << "Number of Courses and Students has been updated!\n\n";

	

	//Prepare an array to store these values.
	string uni_values[7];

	//Track the value being sorted.
	int current_value = 0;
	for (size_t i = 0; i < values[0].length(); i++) 
	{

		if (values[0][i] == ';') 
		{

			//If delimiter found, dont do anything with it and move tracker to next element of values array.
			current_value++;

		}
		else 
		{

			//Add on the next char from string to the current value in array.
			uni_values[current_value] += values[0][i];

		}


	}

	//These are the details to be output to the user, using a menu to format them.
	string details[] = {

		"University Name: " + uni_values[0],
		"Charity Number: " + uni_values[1],
		"Minimum Age: " + uni_values[2],
		"Number of Courses: " + uni_values[3],
		"Number of Students: " + uni_values[4],
		"Address: " + uni_values[5],
		"Phone Number: " + uni_values[6]

	};


	cout << "Press enter to continue..." << endl;

	//Prepare for inputs.
	cin.clear();
	cin.ignore(INT_MAX, '\n');

	//Show the details of the university.
	Menu menu;
	menu.clear_screen();
	menu.create_menu("University Details", details, 7, false);

	//Ask user for input regarding information.
	cout << "Choose an option to edit it, or press enter to return." << endl;

	//Grab user input.
	string choice;
	getline(cin, choice);
	
	//Check if return has been pressed, nothing entered, or if the character entered is not a digit.
	if ((choice == "\n") || (choice == "") || !(isdigit(choice[0])))
		return;

	//Otherwise get a user entry.
	cout << "Please enter a new value: ";
	string user_entry;
	getline(cin, user_entry);

	//Set that value in the values array.
	uni_values[stoi(choice)] = user_entry;

	//Setup array for the fields in the table.
	string fields[] = {

		"university_name",
		"charity_number",
		"minimum_age",
		"number_of_courses",
		"number_of_students",
		"address",
		"phone_number"


	};

	//Delete all entries from the table.
	db->perform_sql_action("DELETE FROM uni_information");

	//Insert teh entries back into the table with the user correction.
	db->sql_insert(fields, 7, "uni_information", uni_values, 7);

	menu.clear_screen();
	uni_options(db);

	return;

}


