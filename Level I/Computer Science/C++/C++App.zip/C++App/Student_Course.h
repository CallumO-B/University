// Created by Callum Owen-Bridge (15002504) latest version 22/03/2017
#pragma once
#include "Database.h"
#include "Student.h"
#include "Menu.h"
#include "Date.h"
#include <iostream>
#include <string>
#include <vector>

using namespace std;
using namespace Database_Application;

// inheritance used to access functions from student
class Student_Course : public Student
{
public:

	Student_Course();

	// preconditon:menu for student course, requires database instance to be initailised
	//postcondition: displays a menu of options for student course class
	void Student_Course_menu(Database^ db);

	// preconditon:collects information about a student and courses, requires database instance to be initailised, requires 3 string inputs to function
	//postcondition: collects data to enrol a specific student on a specific course code and automatically enrols user onto the assessemnst asscoaited with the course code
	void enrol_student(Database^ db, string student_id, string course_code, string attempt);

	// preconditon:collects information from user about a student and courses, requires database instance to be initailised, requires 3 string inputs to function
	//postcondition: collects data from user to enrol a specific student on a specific course code and automatically enrols user onto the assessemnst asscoaited with the course code
	void enrol_student(Database^ db);

	// preconditon:collects information from a file about a student and courses, requires database instance to be initailised
	//postcondition: reads a file of students to enrol onto a specific course sleected by the user
	void enrol_Many_students(Database^ db);

	// preconditon:collects data about a student, requires database instance to be initailised
	//postcondition: collects data about a student that a user wnats to delete and removes the student from the course specified 
	void remove_student(Database^ db);

	// preconditon:collects data from a file, requires database instance to be initailised
	//postcondition: reads a file of students to be removed from a specified course
	void remove_Many_students(Database^ db);

	// preconditon:collects data about a student from user, requires database instance to be initailised
	//postcondition: displays the courses a student is enrolled on for the user to see
	void view_student_courses(Database^ db);

	// preconditon:collects data about a course from user, requires database instance to be initailised
	//postcondition:displays all the students enrolled onto a specified course
	void view_students_enrolled_OnCourse(Database^ db);

private:
	
	Menu menu;
	Date date;

	void clear_inputstream();
	void input_checker(string inputs[]);
	void input_checker(string &input);
};