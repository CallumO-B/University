#pragma once
#include <iostream>
#include "Menu.h"
#include "Database.h"

using namespace std;
using namespace Menus;
using namespace Database_Application;

class Assessment {
	
public:

	void assessment_menu(Database^ database);

	string find_assessment(Database^ database);

private:

	Menu menu;
	

	void create_assessment(Database^ database);
	void view_assessment(Database^ database);
	void amend_assessment(Database^ database);
	void remove_assessment(Database^ database);

	void fix_delimiters(string & input);
	void clear_inputstream();

};