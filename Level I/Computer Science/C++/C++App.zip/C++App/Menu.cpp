#include "Menu.h"

using namespace Menus;

Menu::Menu()
{



}

Menu::Menu(shuint edge)
{

	edge_buffer = edge;

}

short int Menu::create_menu(string message, const string options[], size_t num_of_options, bool expect_input)
{

	//No elements in passed array, return -1!
	if (num_of_options == 0)
	{

		//Inform user of error.
		cout << "\n\nNO OPTIONS IN MENU\n\n";

		return -1;

	}

	short int return_value = (short int)num_of_options; //Setup a return value from user choice.
	size_t max_size = 20;		//Default manu width, specified to make windows look more consistent.
	shuint edge_buffer = 5;	//Buffer space between options and border.

	for (shuint i = 0; i < num_of_options; i++)
	{	//Find strings longer than 20.

		if ((options[i].length() + 3) > max_size)
			max_size = options[i].length() + 3;	//Change max size to length of longest string.

	}

	//Check if menu message is longer.
	if (message.length() > max_size)
		max_size = message.length();

	//Seperate menu from other lines so it prints out correctly.
	cout << char(218) << "\n ";

	//Print top bound.
	cout << top_left_corner;
	for (shuint i = 0; i < (max_size + (2 * edge_buffer)); i++)
		cout << top_bottom_border;
	cout << top_right_corner;

	//Print header.
	cout << "\n " << side_border;
	for (shuint i = 0; i < edge_buffer; i++)
		cout << ' ';
	//Print message at top of menu.
	cout << message;

	//Print blank line.
	for (shuint i = 0; i < edge_buffer + (max_size - message.length()); i++)
		cout << ' ';
	cout << side_border << "\n " << side_border;

	//Print blank line.
	for (shuint i = 0; i < (max_size + (2 * edge_buffer)); i++)
		cout << ' ';
	cout << side_border << "\n ";

	//Print out options available.
	for (shuint i = 0; i < num_of_options; i++)
	{
		cout << option_left_side_border;

		for (shuint j = 0; j < edge_buffer - 1; j++)
			cout << char(196);
		cout << ' ';

		cout << i << ". " << options[i];

		//Output a buffer with a min size, subtract the length of the string + length of the option indicator "(3 + int(i / 10))".
		for (shuint j = 0; j < ((max_size + edge_buffer) - (options[i].length() + (3 + int(i / 10)))); j++)
			cout << ' ';
		cout << side_border << "\n ";



	}
	cout << bottom_left_corner;
	for (shuint i = 0; i < (max_size + (2 * edge_buffer)); i++)
		cout << top_bottom_border;
	cout << bottom_right_corner << endl;

	for (unsigned int i = 0; i < (max_size + (2 * edge_buffer) + 3); i++)
		cout << ' ';
	cout << char(217);
	cout << "\n\n";

	if (expect_input)
	{

		cout << "\n\n" << "Please choose an option by it's number." << endl;

		cin >> return_value;

		while ((return_value >= (short int)num_of_options) || (return_value < 0))
		{

			cout << "Input invalid, please enter a valid choice." << endl;

			cin >> return_value;

			clear_inputstream();

		}

		cout << "You have chosen " << options[return_value] << endl;

	}

	return return_value;

}

shuint Menu::yes_no_menu(string message)
{

	//Options: 0. No, 1. Yes.
	string options[] =
	{

			"No",
			"Yes"

	};

	return create_menu(message, options, 2, true);

}

void Menu::change_border(char top_bottom_char, char sides_char)
{

	top_bottom_border = top_bottom_char;

	side_border = sides_char;

}

void Menu::clear_inputstream()
{

	//Clear input buffer and ignore all chars until a newline.
	cin.clear();
	cin.ignore(INT_MAX, '\n');

}

void Menu::clear_screen()
{

	//Print 100 newlines to remove old displayed items from screen.
	for (int i = 0; i < 100; i++)
		cout << "\n";

}