// Created by Callum Owen-Bridge (15002504) latest version 22/03/2017
#include "Mark.h"

Mark::Mark() {}

// This function creates the menu for the mark class
void Mark::mark_menu(Database^ db) {

	string options[] = {"Return to Main Menu", "View assessment mark", "Add assessment mark", "Amend assessment mark", "View course mark", "View overall level mark"};

	int choice = 1;
	while (choice > 0) {
		choice = menu.create_menu("Please choose an option", options, 6, true);

		switch (choice) {

		case 0:

			return;

			break;

		case 1:

			view_assessment_Mark(db);

			break;

		case 2:

			add_assessment_Mark(db);

			break;

		case 3:

			amend_assessment_Mark(db);

			break;
		case 4:

			course_Mark(db);

			break;
		case 5:

			total_level_Mark(db);

			break;

		}

	}
	return;
}

// This function allows the user to amend a student's assessment mark
void Mark::amend_assessment_Mark(Database^ db)
{ 
	string id[3], assessmentGrade, assessmentResult, mark, max, assessmentAttempt, results;
	int number_values = 3, column_size = 3, assessmentMark;
	bool loop = true;
	vector<string> value, assessment_details, attempts;

	// a do-while loop to allow the user to do the function again
	do 
	{

		menu.clear_screen();
		clear_inputstream();
		cout << "For which student would you like to amend the assessment mark?" << endl;

		//get student id, uses a fucntion from student class allowing the user to search for thr student id in multiple ways.
		id[0]=get_student_id(db);

		// if statement used to prevent the function from using null values
		if (id[0] == "NO STUDENTS FOUND")
		{
			cout << "No students found" << endl;
			return;
		}

		// loop allows the user to be certain its the correct assesment selected.
		do 
		{

			clear_inputstream();

			vector<string> assessment_list;

			db->sql_select("assessment_id, assessment_name", "assessment", assessment_list);

			cout << "Assessment ID | Assessment Name\n";

			for (int i = 0; i < assessment_list.size(); i++)
				cout << assessment_list[i] << endl;

			cout << "\n";

			cout << "Which assessment's mark would you like to amend ? (Please enter assessment ID)" << endl;
			cin >> id[1];

			// input checker allows the user to correct entry value
			input_checker(id[1]);

			//sql function to select assessment details to allow the user ot view them 
			db->perform_sql_action("SELECT * FROM assessment  WHERE  assessment_id =\"" + id[1] + '\"', assessment_details);

			// if statement used to prevent the function from using null values
			if (assessment_details.size() == 0)
			{
				cout << "no assessments found for that assessment ids" << endl;
				return;
			}

			cout << "ID  ||  name  ||  research task  ||" << endl;
			cout <<"Assessment name: "<< assessment_details[0]<<endl;

		} while (!(menu.yes_no_menu("Is this the correct assessment? ")));

		clear_inputstream();
		cout << "Please enter new mark, include any concessional codes? For example: 0PL " << endl;
		cin >> mark;
		input_checker(mark);
		
		//removes the concessional code and turns mark into an integer
		assessmentMark = remove_concessional_code(mark);

		//uses mark to find a grade to match
		assessmentGrade = grade(assessmentMark);

		// uses mark to calculate whether the student has passed the assesment or not
        assessmentResult = result(assessmentMark);		
		assessmentAttempt = "1";

		// uses mark to calculate the overall course result 
		if (assessmentMark > 40)
			results = "1";
		if (assessmentMark < 40)
			results = "0";

		// searches database for the number attempts by the student for the assessment
		db->perform_sql_action("SELECT attempt FROM student_assessment  WHERE  student_id=\"" + id[0] + "\" AND assessment_id=\"" + id[1] + '\"', attempts);
		cout << "Current assessment attempt is: " << attempts[0] << endl;

		max = "2";
		if (attempts[0] == max)
			cout << "Student has reached maximum number of attempts" << endl;
			
		if (attempts[0] < max) 
		{
			if (menu.yes_no_menu("Is this another attempt of the assessment by the student")) 
			{
				assessmentAttempt = 2;
				if (assessmentMark < 40)
					cout << "Student has failed the course and assessment" << endl;
		    }
		}

		cout << " Student:  " << id[0] << "   Assessment: " <<"  "<< id[1] << "\n" 
			<< " Grade: " << assessmentGrade << " Mark: " << mark << " Result: " << assessmentResult << " Attempt: " << attempts[0] << endl;

		if (menu.yes_no_menu("Are the above values correct?"))
		{
			// updates the database with the values entered by the user
			db->perform_sql_action("UPDATE student_assessment SET mark =\"" + mark + '\"' + " WHERE " + "student_id" + "=\"" + id[0] + "\" AND assessment_id=\"" + id[1] + '\"');
			db->perform_sql_action("UPDATE student_assessment SET Grade =\"" + assessmentGrade + '\"' + " WHERE " + "student_id" + "=\"" + id[0] + "\" AND assessment_id=\"" + id[1] + '\"');
			db->perform_sql_action("UPDATE student_assessment SET result =\"" + assessmentResult + '\"' + " WHERE " + "student_id" + "=\"" + id[0] + "\" AND assessment_id=\"" + id[1] + '\"');
			db->perform_sql_action("UPDATE student_assessment SET attempt =\"" + assessmentAttempt + '\"' + " WHERE " + "student_id" + "=\"" + id[0] + "\" AND assessment_id=\"" + id[1] + '\"');

			// adds the date into the database of when the amendment was made
			string command= "UPDATE student_assessment SET date_marked=now()";
			command += " WHERE ";
			command += "student_id";
			command += "=\"";
			command += id[0];
			command += "\" AND assessment_id=\"";
			command += id[1];
			command += '\"';
			db->perform_sql_action(command);

			// updates course result in the database
			db->perform_sql_action("UPDATE student_course SET latest_result =\"" + results + '\"');
			cout << "Amending complete" << endl;

			// allows the user to amend another assessment
			if (!menu.yes_no_menu("Would you like to amend another mark? "))
				break;
		}

		else
		{
			cout << "  Restarting Function  " << endl;
		}

	} while (loop);

	return;
}



// This function allows the user to add a mark to a student's assessment
void Mark::add_assessment_Mark(Database^ db) {

	string assessmentGrade, assessmentResult, columns[6] = {"student_id", "assessment_id", "mark", "grade", "attempt", "result"}, values[6], mark, latest_result, date_marked, results;
	int  assessmentMark, assessmentAttempt=1;
	bool loop = true;
	vector<string> value, assessment_details;

	do 
	{

		menu.clear_screen();
		clear_inputstream();
		cout << "Which student would you like to add the assessment mark to?" << endl;

		//get student id, uses a fucntion from student class allowing the user to search for thr student id in multiple ways.
		values[0] = get_student_id(db);

		// if statement used to prevent the function from using null values
		if (values[0] == "NO STUDENTS FOUND")
		{
			cout << "No students found" << endl;
			return;
		}

		// loop allows the user to be certain its the correct assesment selected.
		do 
		{
			clear_inputstream();

			vector<string> assessment_list;

			db->sql_select("assessment_id, assessment_name", "assessment", assessment_list);

			cout << "Assessment ID | Assessment Name\n";

			for (int i = 0; i < assessment_list.size(); i++)
				cout << assessment_list[i] << endl;

			cout << "\n";

			cout << "Which assessment would you like to add a mark to ? (Please enter assessment ID)" << endl;
			cin >> values[1];
			//input checker allows the user to re enter the value
			input_checker(values[1]);

			//sql function collects the details of selected assessment
			db->perform_sql_action("SELECT * FROM assessment  WHERE  assessment_id =\"" + values[1] + '\"', assessment_details);

			// if statement used to prevent the function from using null values
			if (assessment_details.size() == 0)
			{
				cout << "no assessments found for that assessment ids" << endl;
				return;
			}

			cout << "ID  ||  name  ||  research task  ||" << endl;
			cout << "Assessment name: " << assessment_details[0] << endl;

		} while (!(menu.yes_no_menu("Is this the correct assessment? ")));

		clear_inputstream();
		cout << "Please enter mark, include any concessional codes? For example: 0PL " << endl;
		cin >> mark;
		input_checker(mark);
		
		values[2] = mark;
		//removes the concessional code and turns mark into an integer
		assessmentMark = remove_concessional_code(mark);

		//uses mark to find a grade to match
		values[3] = assessmentGrade = grade(assessmentMark);

		//uses mark to find a result to match
		values[4] = "1";

		//stores 1st attempt 
		values[5] = assessmentResult = result(assessmentMark);

		// uses mark to calculate the overall course result 
		if (assessmentMark > 40)
			results = "1";
		if (assessmentMark < 40)
			results = "0";

		cout <<"student:  "<< values[0] << "   "<<"Assessment:  " << values[1] << "\n"
			<< " Grade: " << assessmentGrade << "  Mark: " << mark <<"  Attempt: "<<assessmentAttempt<<"  Result: " << assessmentResult << endl;  
			
		
		if (menu.yes_no_menu("Are the above values correct?"))
		{
			//adds values to database if they dont already exist
			db->sql_insert(columns, 6, "student_assessment", values, 6);
			db->perform_sql_action("UPDATE student_assessment SET mark=\"" + values[2] + "\", grade=\"" + values[3] + "\", result=" + results + ", attempt=1 WHERE student_id=" + values[0] + " AND assessment_id=" + values[1]);
			db->perform_sql_action("UPDATE student_assessment SET date_marked=now() WHERE student_id=\"" + values[0] + "\" AND assessment_id=\"" + values[1] + '\"');

			vector<string> course_codes, match;
			//sql function collects course codes which match the assessment id 
			db->sql_select("course_code", "course_assessment", "assessment_id", values[1], course_codes);

			for (unsigned int i = 0; i < course_codes.size(); i++)
			{
				//sql function collects course codes which match the previous course codes and student id
				db->perform_sql_action("SELECT course_code FROM student_course WHERE course_code=\"" + course_codes[i] + "\" AND student_id=" + values[0], match);

				// if statement used to prevent the function from using null values
				if (match.size() == 0)
				{
					cout << "no course codes match that course code and student id in database" << endl;
					return;
				}
				if (match.size() > 0)
					break;
			}

			if (match.size() > 0)
				//sql function updates the result of the students course depending on the assessment result
				db->perform_sql_action("UPDATE student_course SET latest_result=" + results + " WHERE student_id=" + values[0] + " AND course_code=\"" + match[0] + "\"");
			else
				cout << "Couldn't find student course entry, please ensure that one exists for this student" << endl;

			cout << "Mark added" << endl;
			// allows user to add another mark
			if (!menu.yes_no_menu("Would you like to add another student assessment mark? "))
				break;
		}
		// function restarts so user can re enter values
		else
			cout << "  Restarting Function  " << endl;
	
	} while (loop);

	return;
}



//This fucntion allows the user to view a student's assessment mark
void  Mark::view_assessment_Mark(Database^ db){
string id[2], assessmentGrade, assessmentResult;
int assessmentMark;
vector<string> mark, assessment_details, attempts;

do
{
	menu.clear_screen();
	clear_inputstream();
	cout << "Which student would you like to view the assessment mark of?" << endl;
	// get student id 
	id[0] = get_student_id(db);

	// if statement to tell user that no values are present in search
	if (id[0] == "NO STUDENTS FOUND")
	{
		cout << "No students found" << endl;
		return;
	}

	// do-while allows user to find the correct assessment
	do 
	{

		clear_inputstream();

		vector<string> assessment_list;

		db->sql_select("assessment_id, assessment_name", "assessment", assessment_list);

		cout << "Assessment ID | Assessment Name\n";

		for (int i = 0; i < assessment_list.size(); i++)
			cout << assessment_list[i] << endl;

		cout << "\n";

		cout << "Which assessment's mark would you like to view ? (Please enter assessment ID)" << endl;
		cin >> id[1];
		input_checker(id[1]);

		// sql function to allow the user to veiw details of selected assessment
		db->perform_sql_action("SELECT * FROM assessment  WHERE  assessment_id =\"" + id[1] + '\"', assessment_details);

		// if statement to tell user that no values are present in search
		if (assessment_details.size() == 0)
		{
			cout << "no assessments found for that assessment ids" << endl;
			return;
		}

		cout << "ID  ||  name  ||  research task  ||" << endl;
		cout << assessment_details[0] << endl;

	} while (!(menu.yes_no_menu("Is this the correct assessment? ")));

	// sql function to select mark from selected assessment
	db->perform_sql_action("SELECT mark FROM student_assessment  WHERE  student_id =\"" + id[0] + "\" AND assessment_id=\"" + id[1] + '\"', mark);

	// if statement to tell user that no values are present in search
	if (mark.size()==0)
	{
		cout << "No mark found for that student or assessment" << endl;
		return;
	}

	// sql function selects attempt from students assessment 
	db->perform_sql_action("SELECT attempt FROM student_assessment  WHERE  student_id =\"" + id[0] + "\" AND assessment_id=\"" + id[1] + '\"', attempts);

	// if statement to tell user that no values are present in search
	if (attempts.size() == 0)
	{
		cout << "Student is not enrolled on that assessment" << endl;
		return;
	}

	assessmentMark = remove_concessional_code(mark);
	assessmentGrade = grade(assessmentMark);
	assessmentResult = result(assessmentMark);
	
	clear_inputstream();
	cout <<"For studnet: "<<id[0]<< "  for assessment "<<"  "<< id[1]<<"\n"
		<< "Mark is: " << mark[0] << "  Grade is: " << assessmentGrade << "  Result is: " << assessmentResult<< "  Current assessment attempt is: " << attempts[0] << endl;

	
} while (menu.yes_no_menu("Would you like to view another mark? "));

return;
}

//This function allows the user to view a student's overall course mark for a particular level 
void  Mark::course_Mark(Database^ db){  ///////// student course///////
string id[3], courseGrade, courseResult;
int arrayamount=0, courseMark=0;	
vector<string>course_assessmentIDS, student_assessmentIDS, marks, course_name, attempts;
bool fail=1;

// do-while allows the user to execute the function again
do
{
	menu.clear_screen();
	clear_inputstream();
	cout << "Which student would you like to view the course code mark of?" << endl;
	id[0] = get_student_id(db);

	// if to tell user that no values exist in database
	if (id[0] == "NO STUDENTS FOUND")
	{
		cout << "No students found" << endl;
		return;
	}

	//do-while allows user to find course
	do 
	{

		clear_inputstream();

		vector<string> course_list;

		db->sql_select("course_code", "student_course", "student_id", id[0], course_list);

		cout << "Course Codes\n";

		for (int i = 0; i < course_list.size(); i++)
			cout << course_list[i] << endl;

		cout << "\n";

		cout << "Please enter the course code of the course's mark you would like to view" << endl;
		cin >> id[1];
		input_checker(id[1]);

		//sql selects course names to help user identify course
		db->sql_select("course_name", "course", "course_code", id[1], course_name);

		// if to tell user that no values exist in database
		if (course_name.size() == 0)
		{
			cout << "No courses found in database that match that code" << endl;
			return;
		}

		cout << id[1] << "  " << course_name[0] << endl;
	} while (!menu.yes_no_menu("Is this the correct course ? "));

	db->sql_select("assessment_id", "student_assessment", "student_id", id[0], student_assessmentIDS);

	// if to tell user that no values exist in database
	if (student_assessmentIDS.size()==0)
	{
		cout << "No assessments found for that student id" << endl;
		return;
	}

	db->sql_select("assessment_id", "course_assessment", "course_code", id[1], course_assessmentIDS);

	// if to tell user that no values exist in database
	if (course_assessmentIDS.size()==0)
	{
		cout << "No assessments found for that course code" << endl;
		return;
	}

	// for loops and if statment finds assessments student has completed on a course code and sums the mark of each matched assessment
	for(unsigned int i=0; i<course_assessmentIDS.size(); i++)
	{
		for (unsigned int j = 0; j < student_assessmentIDS.size(); j++)
		{
			if (course_assessmentIDS[i] == student_assessmentIDS[j])
			{
				arrayamount++;
				db->sql_select("mark", "student_assessment", "assessment_id", student_assessmentIDS[j], marks);
				courseMark += remove_concessional_code(marks);
				if (courseMark < 40)
					fail = 0;
			}
		}
	}

	// if to tell user that no values exist in database
	if(arrayamount == 0)
	{
		cout << "The student has no assessments associated with the chosen course code" << endl;
		return;
	}

	courseMark=courseMark/arrayamount;
	courseGrade = grade(courseMark);

	// if else updates course result 
	if (fail)
		courseResult = result(courseMark);
	else
		courseResult = "FAIL";

	db->perform_sql_action("SELECT attempt FROM student_course  WHERE  student_id=\"" + id[0] + "\" AND course_code=\"" + id[1] + '\"', attempts);

	// if to tell user that no values exist in database
	if (attempts.size() == 0)
	{
		cout << "Student enrolled on course" << endl;
		return;
	}
   
	cout << "For student " << id[0] << "   and course  " << course_name[0]
		 << "Course results  "<<"  Mark is: " <<courseMark<< "  Grade is: "<< courseGrade<<"  Result is: "<<courseResult <<"  Attempt: " << attempts[0] << endl;

} while (menu.yes_no_menu("Would you like to view another assessment mark ? "));

return;
}



//This fucntion allows the user o view the overall level mark of a student
void  Mark::total_level_Mark(Database^ db){   /////////student level ///////////
string id[3], levelGrade, levelResult, level;
int arrayamount = 0, levelmark = 0;
vector<string> course_assessmentIDS, student_assessmentIDS, marks, courseCodes, codes;
bool fail=1;

// do-while allows user to execute function again
do {
	menu.clear_screen();
	clear_inputstream();
	cout << "Which student would you like to view the overall level mark of?" << endl;
	id[0] = get_student_id(db);

	// if to tell user that no values exist in database
	if (id[0] == "NO STUDENTS FOUND")
	{
		cout << "No students found" << endl;
		return;
	}

	clear_inputstream();
	cout << "Which level would you like to view (levels: C or I or H)" << endl;
	cin >> level;
	input_checker(level);

	db->sql_select("course_code", "student_course", "student_id", id[0], courseCodes);
	// if to tell user that no values exist in database
	if (courseCodes.size() == 0)
	{
		cout << "stduent is not enrolled onto any courses, please try again." << endl;
		return;
	}

	for (unsigned int i=0; i<courseCodes.size(); i++) 
	{
		db->perform_sql_action("SELECT course_code FROM course WHERE course_code=\""+ courseCodes[i] + "\" AND course_level=\"" + level+"\"", codes);
		// if to tell user that no values exist in database
		if (codes.size() == 0)
		{
			cout << "course does not contain that course code, please try again." << endl;
			return;
		}

	}

	for (unsigned int i = 0; i < codes.size(); i++)
	{
		db->sql_select("assessment_id", "course_assessment", "course_code", codes[i], course_assessmentIDS);
		// if to tell user that no values exist in database
		if (course_assessmentIDS.size() == 0)
		{
			cout << "No assessments found for that course code 1" << endl;
			return;
		}
	}



	db->sql_select("assessment_id", "student_assessment", "student_id", id[0], student_assessmentIDS);
	// if to tell user that no values exist in database
	if (student_assessmentIDS.size()==0)
	{
		cout << "No assessments found for that student id" << endl;
		return;
	}

	// for loops and if statment finds assessments student has completed on a course code and sums the mark of each matched assessment
	for (unsigned int i = 0; i<course_assessmentIDS.size(); i++)
	{
		for (unsigned int j = 0; j < student_assessmentIDS.size(); j++)
		{
			if (course_assessmentIDS[i] == student_assessmentIDS[j])
			{
				arrayamount++;
				db->sql_select("mark", "student_assessment", "assessment_id", student_assessmentIDS[j], marks);
				levelmark += remove_concessional_code(marks);
				if (levelmark < 40)
					fail = 0;
			}
		}
	}


   if (arrayamount == 0)
   {
	   cout << "The student has no assessments associated with the chosen course code" << endl;
	   return;
   }

	levelmark=levelmark/arrayamount;
	levelGrade = grade(levelmark);

	if (fail)
		levelResult = result(levelmark);

	else
		levelResult = "FAIL";

    cout<< "Level results "<< "Mark is: " <<levelmark<<"  Grade is: "<< levelGrade<<"  Result is: "<<levelResult<< endl;

} while (menu.yes_no_menu("Would you like to view another level mark? "));

return;
}


// grade function calculates letter equivalent of mark
string Mark::grade(const int mark)
{
	string grade;

	if (mark >= 75 && mark <= 100)
		grade = "A+";
	
	if (mark >= 70 && mark <= 74)
		grade = "A";

	if (mark >= 65 && mark <= 69)
		grade = "B+";

	if (mark >= 60 && mark <= 64)
		grade = "B";

	if (mark >= 55 && mark <= 59)
		grade = "C+";

	if (mark >= 50 && mark <= 54)
		grade = "C";

	if (mark >= 45 && mark <= 49)
		grade = "D";

	if (mark >= 40 && mark <= 44)
		grade = "E";

	if (mark<40)
		grade = "U";

	return grade;
}
// result function calculates pass or fail
string Mark::result(const int mark)
{
	string result;

	if (mark >= 40)
		result = "1";

	if (mark < 40)
		result = "0";

	return result;
}

//  input checker function allows user to re enter value
void Mark::input_checker(string inputs[]) {
	bool result = false;

	//do-while loops until the value is correct
	do 
	{

		for (int i = 0; i < sizeof(inputs); i++)
			cout << "Value entered: " << inputs[i] << endl;

		if (menu.yes_no_menu("Are the above values correct "))
			result = true;

		else {
			clear_inputstream();
			cout << "Please re-enter both values" << endl;
			for (int i = 0; i < sizeof(inputs); i++)
			{
				clear_inputstream();
				getline(cin, inputs[i]);
			}
		}
	} while (!result);
}

//  input checker function allows user to re enter value
void Mark::input_checker(string& input) {
	bool result = false;

	//do-while loops until the value is correct
	do 
	{
		cout << "Value entered:  " << input << endl;

		if (menu.yes_no_menu("Are the above values correct "))
			result = true;

		else
		{
			clear_inputstream();
			cout << "Please re-enter value " << endl;
			getline(cin, input);
		}
	} while (!result);
}

// clears the input stream
void Mark::clear_inputstream() {
	//Clear input buffer and ignore all chars until a newline.
	cin.clear();
	cin.ignore(INT_MAX, '\n');
}

//removes concessional code from mark
int Mark::remove_concessional_code(string& input) {
	char temp2[5];
	int intMark;
	string input2 = input;

	// searches for integer values in user input
    for(unsigned int i = 0; i < input2.length(); i++)
    {
        if((isdigit(input2[i])))
             temp2[i]=input2[i];
    }
    temp2[5]='\0';
    intMark=atoi(temp2);
	
	return intMark;
}

//removes concessional code from mark
int Mark::remove_concessional_code(vector<string> input) {
	int intMark;
	string input2;
	char temp2[5];

	// searches for integer values in user input
	for (unsigned int i = 0; i < input[0].size(); i++)
	{
		if ((isdigit(input[0][i])))
			temp2[i] = input[0][i];
	}
	temp2[5] = '\0';
	intMark = atoi(temp2);

	return intMark;
}

