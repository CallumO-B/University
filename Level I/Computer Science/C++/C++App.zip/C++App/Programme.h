// Created by Callum Owen-Bridge (15002504) latest version 22/03/2017
#pragma once
#include "Database.h"
#include "Student.h"
#include "Date.h"
#include "Menu.h"
#include "programme_course.h"
#include <iostream>
#include <string>
#include <vector>
#include <numeric>
#include <cstring>
#include <stdlib.h>

using namespace std;
using namespace Database_Application;

class Programme
{

public:

	// friend function allows student programme class to use public functions in programme class
	friend class student_programme;

	Programme();

	// preconditon: menu for programme, requires database instance to be initailised
	//postcondition:displays a menu for programme for user to choose an option
	void programme_menu(Database^ database);

	// preconditon:collects data from user for programme, requires database instance to be initailised
	//postcondition: collects data from user to adda programme to the database
	void add_programme(Database^ db);

	// preconditon:collects data from user about programmes, requires database instance to be initailised
	//postcondition:collects data from user to allow them to amend a stored programme and updates the databse
	void amend_programme(Database^ db);

	// preconditon: collects information about a programme from user, requires database instance to be initailised
	//postcondition: collects information from user abvout a programme the user would like to delet from the databse, then deletes programme from database
	void delete_programme(Database^ db);

	// preconditon: collects data about a programme from user, requires database instance to be initailised
	//postcondition: allows the user to view a programme's details 
	void view_programme(Database^ db);

	// preconditon:collects data about a programme from user, requires database instance to be initailised
	//postcondition: allows the user to view the students enrolled on selected programme showing ids frist name and last name of student
	void view_studentsOnprogramme(Database^ db);


private:
	Menu menu;
	Date date, s_date, e_date;
	Programme_course programmeCourse;

protected: 

	void clear_inputstream();
	void input_checker(string inputs[]);
	void input_checker(string &input);

};