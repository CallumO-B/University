#include "Transcript.h"


void Transcript::display_transcript(Database^ database, const string student_ids[], const int number_of_ids) 
{

	ofstream file;
	string output;
	bool outputting_to_file = false;

	//Print out many individual transcripts.
	for (int i = 0; i < number_of_ids && !outputting_to_file; i++) 
{

		cout << "i: " << i << endl;

		try 
{

			//Get whole transcript string for output.
			output = display_transcript(database, student_ids[i]);
			
		}
		catch (Unregistered e) //Catch the exception of unregistered students.
		{	

			cout << "Student is not Registered on any Programme!" << endl;
			clear_transcript();

			if(number_of_ids > 1)
				display_transcript(database, student_ids, number_of_ids);
			
			return;

		}
						

			//Print data to console.
			print_data(output);

			string options[] = {

				"Exit Transcript Viewing",
				"View Previous Transcript",
				"View Next Transcript",
				"Save this Transcript to File",
				"Save all Transcripts to file"

			};

			Menu menu;
			shuint choice = menu.create_menu("Please Select an Option", options, 5, true);

			switch (choice) 
			{

			case 0:

				//User wants to exit transcript viewing.
				return;

				break;

			case 1:

				//Check if user has reached beginning of transcript list.
				if (i <= 0)
				{
					
					i = -1;

					cout << "No More Transcripts!" << endl;

				}
				else
					i -= 2;

				break;

			case 2:

				//Check if user has reached end of transcript list.
				if (i >= number_of_ids)
					cout << "No More Transcripts!" << endl;

				break;

			case 3:

				//Save the current transcript.
				print_data(output, file);

				break;

			case 4:

				//Start for loop again and set flag to true;
				print_all(database, file, student_ids, number_of_ids);
				outputting_to_file = true;
				return;

				break;

			}

			//Clear transcript for next student's data.
			clear_transcript();

		}

		
		
}

string Transcript::display_transcript(Database^ database, const string student_id) 
{

	//Retrieve all relevent details about this student for the transcript.
	find_student_details(database, student_id);
	find_programme_details(database);

	if (status == false) 
	{

		return "Student " + student_id + " not Registered on any programme!";

	}

	get_details(database, student_id);

	cout << "Here";

	//Calculate grades and marks for course based on assessment criteria.
	calculate_course_stats();
	calculate_degree_aggregate();

	string output_data;

	//Print separator.
	for (int j = 0; j < 30; j++)
		output_data += char(205);

	//Print Heading
	output_data += " Student Transcript ";


	//Print separator.
	for (int j = 0; j < 30; j++)
		output_data +=char(205);

	//Print Programme and Student information.

	//Set Date instance to today's date.
	today.set_to_current_date();

	//Keep adding data to ouput string, (to_string() used many times to prevent auto casting to System String).

	//Output data about transcript and student.
	output_data += "\n\nDate Produced: " + to_string(today.get_day()) + "/" + to_string(today.get_month()) + "/" + to_string(today.get_year()) + "\n\n";
	output_data += "Student Name: "+ student_name + '\n';
	output_data += "University Reference: " + student_id + '\n';
	output_data += "Qualification: " + qualification + '\n';
	
	//Output this student's programme information.
	output_data += "\n\nProgramme Name: " + programme_name + '\n';
	output_data += "Programme ID: " + programme_id + '\n';
	output_data += "Programme Dates: " + start_date + " - " + end_date + '\n';
	output_data += "Attendance Mode: " + attendance_mode + "\n\n";

	student_levels[0].current_level = 'C';
	student_levels[1].current_level = 'I';
	student_levels[2].current_level = 'H';

	//Print headings ###
	output_data +="\t\t\t   Weighting | Grade | Mark | Result | Credit | Attempt\n";

	for (int i = 0; i < 3; i++) 
	{

		//Print current level.
		output_data += " Level ";
		output_data += student_levels[i].current_level;
		output_data += "\n";

		//Print separator.
		for (int j = 0; j < 80; j++)
			output_data += char(205);
		output_data += '\n';

		for (int j = 0; j < 2; j++) 
		{

			output_data += "\n\n ";
			//Print course details. (Course Code - Course Name - Weighting - Grade - Mark - Result - Credit - Attempt).
			output_data +=student_levels[i].courses[j].course_code + "\t" + student_levels[i].courses[j].course_name;

			output_data += "\t";

			if (student_levels[i].courses[j].course_name.length() < 14)
				output_data += "\t";

			//Output weighting, mark, result and attempt.
			output_data += student_levels[i].courses[j].weighting + "\t" + student_levels[i].courses[j].grade + "\t";
			output_data += student_levels[i].courses[j].mark + "\t";

			//If the course has not had any assessments.
			if (student_levels[i].courses[j].mark == "-")
			
			{

				output_data += "-";

			}
			else
			{

				//Condition for evaluating what result to print from boolean.
				if (student_levels[i].courses[j].result)
					output_data += "Pass";
				else
					output_data += "Fail";

			}

			//Output the credit and number of attempts.
			output_data += "\t";
			output_data += student_levels[i].courses[j].credit + "\t" + student_levels[i].courses[j].attempt + "\n";

			//Output each assessment.
			for (unsigned int k = 0; k < student_levels[i].courses[j].assessments.size(); k++) 
			{

				//Output assessment name.
				output_data += "\n ";
				output_data += student_levels[i].courses[j].assessments[k].name;

				//Condition for entering an extra tab to line columns up.
				if (student_levels[i].courses[j].assessments[k].name.length() < 22)
					output_data += "\t\t";
				else
					output_data += "\t";


				//Output weighting, grade and result.
				output_data += student_levels[i].courses[j].assessments[k].weighting + "\t";
				output_data += student_levels[i].courses[j].assessments[k].grade + "\t" + student_levels[i].courses[j].assessments[k].mark + "\t";
				
				//Condition for evaluating what result to print from boolean.
				if (student_levels[i].courses[j].assessments[k].result)
					output_data += "Pass";
				else
					output_data += "Fail";

				output_data += student_levels[i].courses[j].assessments[k].attempt;
				
			}
			
			output_data += "\n\n";

		}

	}

	//Output Research Data.
	output_data += "Research Task Details\n\n";
	output_data += "Name: " + student_levels[2].research_task.name + '\n';
	output_data += "ID: " + student_levels[2].research_task.assessment_id + '\n';
	output_data += "Mark: " + student_levels[2].research_task.mark + '\n';
	output_data += "Grade: " + student_levels[2].research_task.grade + '\n';

	output_data += "Result: ";

	if (student_levels[2].research_task.result)
		output_data += "PASS\n";
	else
		output_data += "FAIL\n";

	output_data += "Weighting: " + student_levels[2].research_task.weighting + '\n';

	output_data += "Degree Result Based on Current Stats: " + degree_result + '\n';


	//Print separator final.
	for (int j = 0; j < 31; j++)
		output_data += char(205);

	output_data += "\n\n" + key + "\n\n";

	return output_data;

}

void Transcript::print_all(Database^ database, ofstream &file_stream, const string student_ids[], const int number_of_ids) 
{
	

	
	
	for (int i = 0; i < number_of_ids; i++) 
	{

		if (file_stream.is_open())
			file_stream.close();

		clear_transcript();

		string output = display_transcript(database, student_ids[i]);

		print_data(output, file_stream);


	}

}

void Transcript::print_data(string output) 
{

	cout << output << endl;

}

void Transcript::print_data(string output, ofstream &file_stream) 
{

	//Get today's date for the file name.
	today.set_to_current_date();

	//Construct the new name for the file.
	string file_name = "Student_Transcript_" + to_string(today.get_day()) + "-" + to_string(today.get_month()) + "-" + to_string(today.get_year()) + ".txt";

	//Open file stream up for editing at end of file.
	file_stream.open(file_name, ios::app);
	
	//Check for file opening failures.
	if (file_stream.fail())
	{
	
		cout << "File Opening Failed, is the file already in use?" << endl;
		file_name = "Student_Transcript_Temp.txt";
		file_stream.open(file_name, ios::app);
		return;

	}

	//Replace extended ASCII chars with standard ASCII chars.
	for (unsigned int i = 0; i < output.length(); i++) 
	{

		//Iterate through string char by char.
		if (output[i] == char(205))
			output.replace(i, 1, "-");


	}

	output += "\n";
	//Add a separator for in file reading.
	for (int i = 0; i < 80; i++)
		output += "-";
	
	//Output the data to the new file.
	file_stream << output;
	file_stream << "\n\n\n";

}

void Transcript::get_details(Database^ database, const string student_id) 
{

	
	string programme[7];

	//Vectors to store IDs.
	vector<string> programme_search;
	
	//Get the programme the student is on.
	database->sql_select("programme_id", "student_programme", "student_id", student_id, programme_search);

	if (programme_search.size() == 0) 
	{

		cout << "Student Not Resgistered on any Programme of Study" << endl;
		return;

	}


	//Find all courses details.
	find_course_details(database);


	//Store programme_id.
	programme[0] = programme_search[0];

	programme_search.resize(0);

	//Get all details about programme.
	database->sql_select("*", "programme", "programme_id", programme[0], programme_search);

	//Put Programme values into an array.
	extract_values(programme, programme_search[0], 7);


	//Find all assessment details for each course associated with this student.
	find_assessment_details(database);


}

void Transcript::find_course_details(Database^ database) 
{

	///Insert all course information into appropriate structures.

	vector<string> course_search, course_years;

	//Get all courses belonging to that programme.
	database->sql_select("course_code", "programme_course", "programme_id", programme_id, course_search);
	database->sql_select("begin_year, end_year", "programme_course", "programme_id", programme_id, course_years);
	
	string * begin_end_years = new string[2];
	
	//Group courses together by level.
	vector<string> level_c_courses, level_i_courses, level_h_courses;

	find_courses_at_level(database, course_search, level_c_courses, 'C');
	find_courses_at_level(database, course_search, level_i_courses, 'I');
	find_courses_at_level(database, course_search, level_h_courses, 'H');
	
	string course_values[4];

	int course_number = 0;

	for (unsigned int i = 0; i < level_c_courses.size(); i++) 
	{

		extract_values(begin_end_years, course_years[course_number], 2);
		course_number++;
		extract_values(course_values, level_c_courses[i], 4);

		vector<string> course_attempt;
		database->perform_sql_action("SELECT attempt FROM student_course WHERE course_code=\"" + course_values[0] + "\" AND student_id=" + student_id, course_attempt);
		
		if (course_attempt.size() == 0) 
		{
			course_attempt.push_back("-1");

			student_levels[0].courses[i].course_code = course_values[0];	//Insert course code.
			student_levels[0].courses[i].course_name = course_values[1];	//Insert course name.
			student_levels[0].courses[i].level = course_values[2];			//Insert course level.
			student_levels[0].courses[i].credit = course_values[3];			//Insert course credit value.
			student_levels[0].courses[i].weighting = "50";					//Insert default weighting value.
			student_levels[0].courses[i].attempt = course_attempt[0];		//Insert this student's attempt for this course.
			student_levels[0].courses[i].begin_year = begin_end_years[0];
			student_levels[0].courses[i].end_year = begin_end_years[1];

		}
		else
		{

			student_levels[0].courses[i].course_code = course_values[0];	//Insert course code.
			student_levels[0].courses[i].course_name = course_values[1];	//Insert course name.
			student_levels[0].courses[i].level = course_values[2];			//Insert course level.
			student_levels[0].courses[i].credit = course_values[3];			//Insert course credit value.
			student_levels[0].courses[i].weighting = "50";					//Insert default weighting value.
			student_levels[0].courses[i].attempt = course_attempt[0];		//Insert this student's attempt for this course.
			student_levels[0].courses[i].begin_year = begin_end_years[0];
			student_levels[0].courses[i].end_year = begin_end_years[1];

		}
	}

	for (unsigned int i = 0; i < level_i_courses.size(); i++) 
	{

		extract_values(begin_end_years, course_years[course_number], 2);
		course_number++;
		extract_values(course_values, level_i_courses[i], 4);
		vector<string> course_attempt;
		database->perform_sql_action("SELECT attempt FROM student_course WHERE course_code=\"" + course_values[0] + "\" AND student_id=" + student_id, course_attempt);

		if (course_attempt.size() == 0)
			course_attempt.push_back("-1");

		student_levels[1].courses[i].course_code = course_values[0];	//Insert course code.
		student_levels[1].courses[i].course_name = course_values[1];	//Insert course name.
		student_levels[1].courses[i].level = course_values[2];			//Insert course level.
		student_levels[1].courses[i].credit = course_values[3];			//Insert course credit value.
		student_levels[1].courses[i].weighting = "50";					//Insert default weighting value.
		student_levels[1].courses[i].attempt = course_attempt[0];		//Insert this student's attempt for this course.
		student_levels[1].courses[i].begin_year = begin_end_years[0];
		student_levels[1].courses[i].end_year = begin_end_years[1];

	}

	for (unsigned int i = 0; i < level_h_courses.size(); i++) 
	{


		extract_values(begin_end_years, course_years[course_number], 2);
		course_number++;
		extract_values(course_values, level_h_courses[i], 4);

		cout << "2";
		vector<string> course_attempt;
		database->perform_sql_action("SELECT attempt FROM student_course WHERE course_code=\"" + course_values[0] + "\" AND student_id=" + student_id, course_attempt);

		if (course_attempt.size() == 0)
			course_attempt.push_back("-1");

		student_levels[2].courses[i].course_code = course_values[0];	//Insert course code.
		student_levels[2].courses[i].course_name = course_values[1];	//Insert course name.
		student_levels[2].courses[i].level = course_values[2];			//Insert course level.
		student_levels[2].courses[i].credit = course_values[3];			//Insert course credit value.
		student_levels[2].courses[i].weighting = "33";					//Insert default weighting value.
		student_levels[2].courses[i].attempt = course_attempt[0];		//Insert this student's attempt for this course.
		student_levels[2].courses[i].begin_year = begin_end_years[0];
		student_levels[2].courses[i].end_year = begin_end_years[1];

	}

}

void Transcript::find_assessment_details(Database^ database) 
{

	///Insert all assessment information into structure.

	//Firstly, grab the research task.
	vector<string> research_task;
	string research_id;

	database->sql_select("assessment_id", "programme_research", "programme_id", programme_id, research_task);

	if (research_task.size() > 0) 
	{

		research_id = research_task[0];

		student_levels[2].research_task.assessment_id = research_id;

		research_task.resize(0);
		database->sql_select("assessment_name", "assessment", "assessment_id", research_id, research_task);

		student_levels[2].research_task.name = research_task[0];

		research_task.resize(0);
		database->sql_select("*", "student_assessment", "assessment_id", research_id, research_task);

	}

	if (research_task.size() > 0) 
	{

		strptr research_values = new string[7];

		for (int i = 0; i < 7; i++)
			research_values[i] = research_task[i];

		research_task.resize(0);

		student_levels[2].research_task.attempt = research_values[4];
		student_levels[2].research_task.grade = research_values[3];
		student_levels[2].research_task.level = "H";
		student_levels[2].research_task.mark = research_values[2];

		if (research_task[5] == "1")
			student_levels[2].research_task.result = true;
		else
			student_levels[2].research_task.result = false;

		student_levels[2].research_task.weighting = "34";

		research_task_found = true;

	}

	//For each level.
	for (int i = 0; i < 3; i++) 
	{

		char current_level;

		if (i == 0)
			current_level = 'C';
		else if (i == 1)
			current_level = 'I';
		else
			current_level = 'H';

		//For each course.
		for (int j = 0; j < 2; j++) 
		{

			//Get the assessments for this course.
			vector<string> assessment_ids;
			database->sql_select("assessment_id, weighting", "course_assessment", "course_code", student_levels[i].courses[j].course_code, assessment_ids);
			
			//For each assessment.
			for (unsigned int k = 0; k < assessment_ids.size(); k++) 
			{

				string course_assessment_details[2];
				extract_values(course_assessment_details, assessment_ids[k], 2);

				//Find all assessments on this course that this student is registered for.
				vector<string> student_assessments;
				database->perform_sql_action("SELECT assessment_id, mark, grade, attempt, result FROM student_assessment WHERE student_id=" + student_id + " AND assessment_id=" + course_assessment_details[0], student_assessments);

				//Get the name of this assessment.
				vector<string> assessment_name, assessment_weighting;
				database->sql_select("assessment_name", "assessment", "assessment_id", course_assessment_details[0], assessment_name);
				
				for (unsigned int l = 0; l < student_assessments.size(); l++) 
				{

					string values[5];
					extract_values(values, student_assessments[l], 5);

					bool assessment_marked = true;

					//Check if the assessment has been marked by checking if there is a mark or attempt.
					if (values[3].length() == 0) 
					{

						values[3] = "-1";
						assessment_marked = false;

					}
					if (values[1].length() == 0) 
					{

						values[1] = "-1";
						assessment_marked = false;

					}
					
					//Create a new instance of assessment details.
					assessment_details new_assessment;
					new_assessment.assessment_id = values[0];

					//Check whether the assessment has been marked.
					if (!assessment_marked)
					{

						//Assessment hasn't been marked, enter placeholders.
						new_assessment.mark = "-";
						new_assessment.grade = "-";
						new_assessment.result = "-";

					}
					else
					{

						//Assessment has marking details entered, enter details!
						new_assessment.mark = values[1];
						new_assessment.grade = values[2][0];
						new_assessment.attempt = values[3];

						//Insert the result based on the condition from the database.
						if (values[4] == "1")
							new_assessment.result = true;
						else
							new_assessment.result = false;


					}

					new_assessment.level = current_level;
					new_assessment.weighting = course_assessment_details[1];
					
					if(isdigit(new_assessment.attempt[0]))
					{

						//If there is more than one attempt at an assessment, then that assessment is a resit.
						if ((stoi(new_assessment.attempt) > 1))
							assessment_name[0].insert(0, "[R] ");

					}

					new_assessment.name = assessment_name[0];

					//Add new assessment to correct course in structure.
					student_levels[i].courses[j].assessments.push_back(new_assessment);

				}

			}
		}
	}

}

void Transcript::find_courses_at_level(Database^ database, const vector<string> course_codes, vector<string> &return_values, const char level) 
{

	char uppercase_level = toupper(level);
	char lowercase_level = tolower(level);

	//Find only the level C courses from the query results.
	string query = "SELECT * FROM course WHERE (course_code=\"" + course_codes[0] + "\"";
	for (unsigned int i = 1; i < course_codes.size(); i++)
		query += " OR course_code=\"" + course_codes[i] + "\"";	//Keep adding the course codes to the query.
	
	//Finish the query by specifying the level wanted.
	query += ") AND (course_level=\"";
	query += uppercase_level;
	query += "\" OR course_level=\"";
	query += lowercase_level;
	query+= "\")";	

	database->perform_sql_action(query, return_values);

}

void Transcript::find_student_details(Database^ database, const string specified_student_id) 
{

	vector<string> details;

	database->sql_select("*", "student", "student_id", specified_student_id, details);

	string student_details[9];

	extract_values(student_details, details[0], 9);

	student_id = student_details[0];

	student_name += student_details[1];
	student_name += ' ';
	student_name += student_details[2];

	visa_expiry = student_details[8];

}

void Transcript::find_programme_details(Database^ database) 
{

	vector<string> query_result;

	//Get the programme this student is on.
	database->sql_select("programme_id", "student_programme", "student_id", student_id, query_result);
	
	if (query_result.size() == 0) 
	{

		//Query found nothing, set status to false and return.
		status = false;
		return;

	}

	status = true;

	programme_id = query_result[0];

	query_result.resize(0);

	//Select the programme with the found id.
	database->sql_select("*", "programme", "programme_id", programme_id, query_result);

	string programme_details[7];

	extract_values(programme_details, query_result[0], 7);

	//Store programme details.
	programme_name = programme_details[1];
	qualification = programme_details[2];
	attendance_mode = programme_details[3];
	start_date = programme_details[4];
	end_date = programme_details[5];


}

void Transcript::extract_values(string values_arr[], const string values_str, const int size) 
{

	//String to store any value that is obtained and an integer to track which value is being taken.
	string current_value;
	int current_index = 0;

	//Get each value in the string in turn.
	for (unsigned int i = 0; i < values_str.length(); i++) 
	{

		//If a delimiter is encountered, then another value has been found, increment counter.
		if (values_str[i] == ';') 
		{
			//Check for empty values and put this into the string.
			if (current_value.length() == 0)
				values_arr[current_index] == "NULL";
			else //Otherwise, enter the value into the array at the correct index.
				values_arr[current_index] = current_value;
			current_value = "";
			current_index++;

		}
		else //Add on each character that isnt a delimiter to the current value.
			current_value += values_str[i];


	}
	


}

void Transcript::calculate_course_stats() 
{

	Mark mark;

	int total_level_marks = 0, total_level_credits = 0;
	

	//For each level
	for (int i = 0; i < 3; i++) 
	{
		//For each course
		for (int j = 0; j < 2; j++) 
		{


			if (student_levels[i].courses[j].credit.length() != 0) 
			{

				//Add on the credits from this course to the level total.
				total_level_credits += stoi(student_levels[i].courses[j].credit);

				//Store average mark for course.
				double total_mark = 0;
				int number_of_assessments = student_levels[i].courses[j].assessments.size();


				//For each assessment.
				for (unsigned int k = 0; k < student_levels[i].courses[j].assessments.size(); k++) 
				{
					
					int current_mark = 0;

					if(student_levels[i].courses[j].assessments[k].mark != "-")
						current_mark = stoi(student_levels[i].courses[j].assessments[k].mark);

					//Add on the mark for each assessment if value found wasn't null (-1).
					if (current_mark == -1) 
					{

						//Disregard this assessment in the average, it hasn't been marked yet.
						number_of_assessments--;

						//Store default values for an assessment.
						student_levels[i].courses[j].assessments[k].mark = "0";
						student_levels[i].courses[j].assessments[k].grade = "U";
						student_levels[i].courses[j].assessments[k].result = false;

					}
					else 
					{

						//Add to the total mark for this course (assessment mark  *  assessment weighting).
						if (isdigit(student_levels[i].courses[j].assessments[k].mark[0]) && isdigit(student_levels[i].courses[j].assessments[k].weighting[0]))
							total_mark += stod(student_levels[i].courses[j].assessments[k].mark) * stod(student_levels[i].courses[j].assessments[k].weighting) / 100;

						//Get and store the correct grade for this mark.
						student_levels[i].courses[j].assessments[k].grade = mark.grade(current_mark);

						//Get the result for this mark.
						string mark_result = mark.result(current_mark);

						//Set correct values for result.
						if (mark_result == "PASS")
							student_levels[i].courses[j].assessments[k].result = true;
						else
							student_levels[i].courses[j].assessments[k].result = false;

					}
				}

				//Check that there are assessments, and that the course has been attempted.
				if ((number_of_assessments > 0) && (student_levels[i].courses[j].attempt != "-1") && (student_levels[i].courses[j].mark != "-"))
				{

					//Divide by number of assessments for average, round the value to an integer.
					student_levels[i].courses[j].mark = to_string((int)(total_mark + 0.5));

					//Get the course mark.
					int course_mark = stoi(student_levels[i].courses[j].mark);
					//Work out the grade for this mark.
					string grade = mark.grade(course_mark);

					//Store this grade.
					student_levels[i].courses[j].grade = grade;

					//Work out the result.
					string result = mark.result(course_mark);

					//Store the relevent values.
					if (result == "PASS")
						student_levels[i].courses[j].result = true;
					else
						student_levels[i].courses[j].result = false;


				}
				else 
				{

					//Defaults for a course in which no assessments are found or there has not yet been an attempt.
					student_levels[i].courses[j].mark = "-";
					student_levels[i].courses[j].grade = "-";
					student_levels[i].courses[j].result = false;


				}

				//If at level H (i = level) then add the research mark to aggregate.
				if (i == 2 && research_task_found)
					total_level_marks += (int)(stod(student_levels[i].research_task.mark) * stod(student_levels[i].research_task.weighting) / 100);
					
					//Add the course mark to the total mark.
				if(student_levels[i].courses[j].mark != "-")
					total_level_marks += stoi(student_levels[i].courses[j].mark);
				
			}
		}

		//Level details.
		
		//Average the total marks for this level.
		total_level_marks /= 2;

		student_levels[i].credit = to_string(total_level_credits);
		student_levels[i].mark = to_string(total_level_marks);
		student_levels[i].grade = mark.grade(total_level_marks);

		string level_result = mark.result(total_level_marks);

		if (level_result == "PASS")
			student_levels[i].result = true;
		else
			student_levels[i].result = false;
			

	}

}

void Transcript::calculate_degree_aggregate() 
{


	bool considerations[4];
	int bands[3];
	double marks[3] = {

		stod(student_levels[0].mark),
		stod(student_levels[1].mark),
		stod(student_levels[2].mark)

	};

	//Work out band for each mark.
	for(int i = 0; i < 3; i++)
		bands[i] = (int)marks[i] / 10 % 10;
	


	//If all marks fall into same band evaluate normally.
	if(bands[0] == bands[1] == bands[3])
	{

		//Find aggregate for level C weighted at 10%
		degree_aggregate = stod(student_levels[0].mark) * 0.1;

		//Aggregate for level I weighted at 30%
		degree_aggregate += stod(student_levels[1].mark) * 0.3;

		//Level H weighted at 60%
		degree_aggregate += stod(student_levels[2].mark) * 0.6;

		//Round value appropriately.
		degree_aggregate = (int)degree_aggregate + 0.5;

		//Assign degree result appropriately.
		if (degree_aggregate >= 70) 
		{

			degree_result = "First Class Honors";

		} 
		else if (degree_aggregate >= 60) 
		{

			degree_result = "Upper Second Class Honors";

		}
		else if (degree_aggregate >= 50) 
		{

			degree_result = "Lower Second Class Honors";

		}
		else if (degree_aggregate >= 40) 
		{

			degree_result = "Third Class Honors";

		}
		else 
		{

			degree_result = "No Degree Awarded";

		}
	
	}

	//Find out which bands are to be considered from marks.
	for (int i = 0; i < 3; i++) 
	{

		if (bands[i] == 4)
			considerations[0] = true;
		else if (bands[i] == 5)
			considerations[1] = true;
		else if (bands[i] == 6)
			considerations[2] = true;
		else if (bands[i] == 7)
			considerations[3] = true;

	}

	//Track the lower and higher bands.
	int lower_band, higher_band;

	//Go through from lower to higher bands to find lowest achieved band.
	for (int i = 0; i < 4; i++) 
	{

		if (considerations[i])
			lower_band = i;

	}

	
	//Go through in reverse to find highest achieved band, unless the lowest band is a first class honors.
	for (int i = 3; i >= 0 && lower_band != 3; i--) 
	{

		if (considerations[i])
			higher_band = i;

	}

	string lower, higher;

	switch (lower_band) 
	{

	case 0:

		lower = "Third Class Honors";

		break;

	case 1:

		lower = "Lower Second Class Honors";

		break;

	case 2:

		lower = "Upper Second Class Honors";

		break;

	case 3:

		lower = "First Class Honors";

		break;


	}

	switch (higher_band) 
	{

	case 0:

		higher = "Third Class Honors";

		break;

	case 1:

		higher = "Lower Second Class Honors";

		break;

	case 2:

		higher = "Upper Second Class Honors";

		break;

	case 3:

		higher = "First Class Honors";

		break;


	}

	//String to display the aggregate results to be considered based on achieved bands.
	degree_result = "Considerations between " + lower + " and " + higher;

}

void Transcript::clear_transcript() 
{

	//Reset student and programme data.
	student_id = "";
	student_name = "";
	qualification = "";
	programme_id = "";
	programme_name = "";

	//For each level...
	for (int i = 0; i < 3; i++) 
	{

		//Reset all level details.
		student_levels[i].credit = "";
		student_levels[i].grade = "";
		student_levels[i].mark = "";
		student_levels[i].research_task.name = "";
		student_levels[i].research_task.assessment_id = "";
		student_levels[i].research_task.attempt = "";
		student_levels[i].research_task.grade = "";
		student_levels[i].research_task.mark = "";
		student_levels[i].research_task.result = "";
		student_levels[i].research_task.weighting = "";
		student_levels[i].result = "";
		

		//For each course...
		for (int j = 0; j < 2; j++) 
		{

			//Reset all course details.
			student_levels[i].courses[j].attempt = "";
			student_levels[i].courses[j].begin_year = "";
			student_levels[i].courses[j].course_code = "";
			student_levels[i].courses[j].course_name = "";
			student_levels[i].courses[j].course_name = "";
			student_levels[i].courses[j].credit = "";
			student_levels[i].courses[j].end_year = "";
			student_levels[i].courses[j].grade = "";
			student_levels[i].courses[j].level = "";
			student_levels[i].courses[j].mark = "";
			student_levels[i].courses[j].result = "";
			student_levels[i].courses[j].weighting = "";

			//Clear all assessments from the course.
			student_levels[i].courses[j].assessments.resize(0);
				
		}
	}

}

void Transcript::print_to_file(ofstream & file_stream, string output) 
{

	if (file_stream.is_open())
		file_stream.close();

	print_data(output, file_stream);

	return;

}
