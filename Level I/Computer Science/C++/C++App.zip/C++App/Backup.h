#pragma once
#include <iostream>
#include <fstream>
#include "Database.h"
#include "Menu.h"
#include "Date.h"

using namespace std;
using namespace Menus;
using namespace Database_Application;

class Backup 
{
	
public:


	void backup_menu(Database ^ database);



private:

	Menu menu;
	
	void backup(Database^ database);
	void restore(Database^ database);

	void encrypt(string & in_string);
	void decrypt(string & in_string);

	void backup_all(Database^ database);

	void backup_students(Database^ database);
	void backup_courses(Database^ database);
	void backup_programmes(Database^ database);

	void restore_all(Database^ database);

	void restore(Database^ database, string type);
	void restore_courses(Database^ database);
	void restore_programmes(Database^ database);

	void extract_values(string values_arr[], const string values_str, const int size);
	void clear_inputstream();
};