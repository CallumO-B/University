#pragma once
#include <iostream>
#include <string>


/*
*
*	Keiran Brown - Menu Class
*	
*	This class allows creation of menus and takes user input as required. 
*	These function as small dialog boxes in which options are chosen using the corresponding number.
*	These menus are drawn using extended ascii characters.
*
*/

using namespace std;

typedef short unsigned int shuint;

namespace Menus
{

	class Menu
	{

	public:

		Menu();
		Menu(shuint edge);

		//Creates a menu using the options provided and specify whether input is required.
		short int create_menu(string message, const string options[], size_t num_of_options, bool expect_input);
		shuint yes_no_menu(string message);

		void change_border(char top_bottom, char sides);
		void clear_screen();

	private:

		char top_bottom_border = char(205), side_border = char(186), option_left_side_border = char(204), top_left_corner = char(201), top_right_corner = char(187), bottom_left_corner = char(200), bottom_right_corner = char(188);
		shuint edge_buffer = 5;

		void clear_inputstream();


	};

}
