#include "Date.h"

Date::Date()
{


}

//Mutators
void Date::input_date()
{

	//Track valid input.
	shuint input_valid = false;
	string date;

	//Allow user to retry entry should it be incorrect.
	do
	{
		//Prompt user for date entry, advise on format.
		cout << "Enter dates in this format: DD/MM/YYYY, or press enter for null date." << endl;
		
		//Get user input.
		getline(cin, date);

		//Allow user to not input date.
		if (date == "\n" || date == "") 
		{

			date_entered = false;
			return;

		}
		else
			date_entered = true;

		string delimiter, day, month, year;

		bool delim_found = false, date_valid = false;

		//Count through and find delimiter for date.
		for (size_t i = 0; i < date.length(); i++)
		{

			//Check for when delimiter begins (when the first number ends).
			if (!isdigit(date[i]))
				delim_found = true;

			//Check for if the next number has begun after the delimiter.
			if (delim_found && isdigit(date[i]))
			{

				input_valid = true;

				break;

			}

			//Add delimiter characters onto date delimiter.
			if (delim_found)
				delimiter += date[i];

		}//End for

		if (!input_valid)
		{

			cout << "Invalid input" << endl;
			//input_date();

		}
		else
		{

			//Find first delimiter
			size_t delim_pos[2];
			delim_pos[0] = date.find(delimiter, 0);

			//Get day substring.
			day = date.substr(0, delim_pos[0]);

			//Find second delimiter.
			delim_pos[1] = date.find(delimiter, delim_pos[0] + delimiter.length());

			//Get month substring.
			month = date.substr(delim_pos[0] + delimiter.length(), date.find(delimiter, delim_pos[0]));

			//Get year from previous position to end of string.
			year = date.substr(delim_pos[1] + delimiter.length(), date.length());

			//Return date in MySQL format!
			date = (year + '-' + month + '-' + day);

			//Store number of days in each month.
			int days_in_month[] =
			{

							31,
							28,
							31,
							30,
							31,
							30,
							31,
							31,
							30,
							31,
							30,
							31

			};

			//Month string for output to user.
			string months[] =
			{

							"January",
							"February",
							"March",
							"April",
							"May",
							"June",
							"July",
							"August",
							"September",
							"October",
							"November",
							"December",


			};

			//Convert strings to integers for processing.
			int day_int = stoi(day), month_int = stoi(month), year_int = stoi(year);

			//Pass these into struct to allow retrieval later.
			date_parts.day = day_int;
			date_parts.month = month_int;
			date_parts.year = year_int;

			//Feb has more days in a leap year.
			if ((year_int % 4) == 0)
				days_in_month[1] = 29;


			//Month should be within year 1 - 12.
			if ((month_int < 1) || (month_int > 12))
			{

				input_valid = false;

				cout << "Month is not correct, it should be in the range --> 1 - 12 " << endl;

			}
			//Check if the number of days is more than it should be for given month.
			if ((day_int > days_in_month[month_int - 1]) || day_int < 1 && input_valid)
			{

				input_valid = false;

				//Special condition for february for better user information.
				if (month_int == 2 && year_int % 4 > 0)
					cout << "The year entered is not a leap year" << endl;

				cout << "The max number of days in " << months[month_int - 1] << " is " << days_in_month[month_int - 1] << endl;
				cout << "You entered " << day_int << endl;

			}

			//Year bound for any mistakes.
			if ((year_int) < 1900 && input_valid)
			{

				cout << "Please enter a year that is 1900 or after";

				//input_date();
				input_valid = false;

			}

			if (!input_valid)
			{

				cout << "\n\nPlease try again." << endl;
				//input_date();

			}

			if (input_valid)
			{

				//Prompt user confirmation...
				cout << "You have entered DD/MM/YYYY " << date << endl;

				input_valid = menu.yes_no_menu("Is this date correct?");


			}



		}

	} while (!input_valid);

	sql_format_date = date;

	return;


}

void Date::set_sql_date(string sql_date)
{

	bool is_month = false, is_day = true;
	
	string date_part;

	for (unsigned int i = 0; i < sql_date.length(); i++)
	{

		if (is_day && (sql_date[i] == '-' || sql_date[i] == '/'))
		{
			i++;
			is_day = false;
			is_month = true;

			date_parts.day = stoi(date_part);

			date_part = "";

		}
		else if (is_month && (sql_date[i] == '-' || sql_date[i] == '/'))
		{
			i++;
			is_month = false;

			date_parts.month = stoi(date_part);

			date_part = "";

		}

		date_part += sql_date[i];


	}

	date_parts.year = stoi(date_part);

}

void Date::set_date(shuint day, shuint month, shuint year)
{

	//Add these parameters to the current date object.
	date_parts.day = day;
	date_parts.month = month;
	date_parts.year = year;

}

//Operator Overloads
bool Date::operator==(Date& other)
{

	//Return whether all parts of both dates are equal or not.

	return(

		(get_date_value() == other.get_date_value())

		);

}

bool Date::operator<(Date& other)
{


	//Return whether the value of date 1 is less than date 2.
	return(get_date_value() < other.get_date_value());

}

bool Date::operator>(Date& other)
{

	//Return whether the value of date 1 is more than date 2.
	return(get_date_value() > other.get_date_value());

}

bool Date::operator>=(Date& other)
{


	//Return true is the local date is more than the other date OR if they are equal.
	return(

		(get_date_value() > other.get_date_value()) ||	//More than or...
		(get_date_value() == other.get_date_value())	//Equal to!

		);

}

bool Date::operator<=(Date& other)
{

	//Return true is the local date is less than the other date OR if they are equal.
	return(

		(get_date_value() < other.get_date_value()) ||	//Less than or...
		(get_date_value() == other.get_date_value())	//Equal to!

		);

}

//Within Date; Operations
unsigned long long Date::get_date_value()
{

	//Work out a value representing the date, more power given to each part so it can be evaulated as an integer.
	date_value = (__int64)(date_parts.day + pow(date_parts.month, 2) + pow(date_parts.year, 3));

	return date_value;

}

void Date::set_to_current_date() 
{

	//Get the time.
	time_t current_time = time(0);
	//Pointer to struct containing time.
	struct tm time_parts;
	localtime_s(&time_parts, &current_time);

	//Get the current date from system time struct.
	date_parts.day = time_parts.tm_mday,			//Get the day. 
	date_parts.month = time_parts.tm_mon + 1,		//Get the month.
	date_parts.year = time_parts.tm_year + 1900;	//Get the year.

	sql_format_date = to_string(date_parts.year);
	sql_format_date += '-';
	sql_format_date += to_string(date_parts.month);
	sql_format_date += '-';
	sql_format_date += to_string(date_parts.day);

	

}

//Accessors
void Date::get_sql_date(string & date_string)
{

	//Make date string a date in sql_format.
	date_string = sql_format_date;

}

shuint Date::get_day()
{

	return date_parts.day;

}

shuint Date::get_month()
{

	return date_parts.month;

}

shuint Date::get_year()
{

	return date_parts.year;

}

bool Date::is_entered() 
{

	return date_entered;

}