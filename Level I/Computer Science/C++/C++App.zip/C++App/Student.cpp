#include "Student.h"




Student::Student() 
{
};

void Student::main_menu(Database^ database)
{

	menu.clear_screen();
	
	cout << "Accesing database...";
	
	//Access Database.
	database->change_database("uni_database");
	cout << "Database accessed" << endl;

	//Setup options for Student Menu.
	string options[] =
	{

			"Return to Main Menu",
			"View Student",
			"Create New Student",
			"Ammend a Student",
			"Remove a Student"

	};

	shuint choice = 100;

	while (choice > 0)
	{

		//Returns index input by user.
		choice = menu.create_menu("Please choose an option", options, 5, true);

		menu.clear_screen();
		//Database to be passed around as needed.

		switch (choice)
		{

		case 0:

			return;

			break;

		case 1:

			current_task = "View Student";
			view_student(database);

			break;

		case 2:

			current_task = "New Student";
			new_student(database);

			break;

		case 3:

			current_task = "Amend Student";
			ammend_student(database);

			break;

		case 4:

			current_task = "Delete Student";
			remove_student(database);

			break;

		}

	}

	return;

}

void Student::view_student(Database^ database)
{

	vector<string> student_values, fields;

	get_table_fields(database, fields);

	menu.clear_screen();

	//User navigation input.
	string options[] =
	{

			"Return to Student Menu",
			"Search for Students",
			"Show all Students"

	};

	cout << current_task << "\n\n";
	int choice = menu.create_menu("How would you like to view students?", options, 3, true);
	menu.clear_screen();

	switch (choice)
	{

	case 0:

		//Return to previous main menu.
		return;

		break;

	case 1:

		//Searches database for students, vector passed by reference will contain students matching search.
		search_for_student(database, student_values);

		break;

	case 2:

		//Select all students from database.
		database->sql_select("*", "student", student_values);

		//Put into array to allow showing in a menu.
		strptr values = new string[student_values.size()];

		//Put all student rows into new string array.
		for (size_t i = 0; i < student_values.size(); i++)
		{

			fix_delimiters(student_values[i]);

			values[i] = student_values[i];

		}

		delete[] values;

		break;

	}//End Outer Switch

	cout << "Student Search Complete!\n\n";

	cout << student_values.size() << " students found" << endl;

	cout << "= = = = = = = = " << endl;

	//Display field headers.
	for (shuint i = 0; i < fields.size(); i++)
	{
		//Add a delimiter for between fields for easier reading whilst displaying.
		fields[i] += " | ";
		cout << fields[i];

	}

	//Spacing out for easier reading.
	cout << "\n\n";

	//Display all found records.
	for (shuint i = 0; i < student_values.size(); i++)
	{

		fix_delimiters(student_values[i]);
		cout << student_values[i] << "\n\n";

	}

	cout << "= = = = = = = = " << endl;

	return;

}

//Takes user through the steps to find a selection of students using various searches.
void Student::search_for_student(Database^ database, vector<string> &returned_values)
{

	//User navigation input.
	string options[] =
	{

			"Return to Student Menu",
			"Enter Student ID",
			"Search by Name",
			"Search by Address",
			"Search by Course"

	};

	cout << current_task << "\n\n";
	shuint choice = menu.create_menu("How would you like to search?", options, 5, true);
	menu.clear_screen();

	switch (choice)
	{

	case 0:

		//Return to previous function.
		return;

		break;

	case 1:
	{
		cout << "Please enter Student ID" << endl;

		string id;

		cin >> id;

		database->sql_select("*", "student", "student_id", id, returned_values);

	}
	break;

	case 2://Inner


	{//Braces stop transfer of control error.

		search_student_by_name(database, returned_values);

	}//End of scope.

	break;//Inner Case 0;

	case 3://Inner

		search_student_by_address(database, returned_values);

		break; //Inner case 1

	case 4:

		search_student_by_course(database, returned_values);

		break;


	}//End Inner Switch

	return;

}

//Offset search from higher search as task of searching for students via courses takes more work.
void Student::search_student_by_course(Database^ database, vector<string> &returned_values)
{

	//Search for course code of user specified course.
	string options[] =
	{
			
			"Course Name",
			"Course Code"

	};

	int choice = menu.create_menu("How would you like to search for a course?", options, 2, true);
	
	menu.clear_screen();
	clear_inputstream();


	string column = "course_code";

	//Find course code of course with specified name in course table.
	if (choice == 0)
	{
	
		column = "course_name";

	}
		/*database->perform_sql_action("SELECT course_code FROM course WHERE course_name=\"" + user_input + "\"", returned_values);
		
		//vector<string> search_values;
		//Find student_ids that are registered with that course via the found course_code.
		database->sql_select("student_id", "student_course", "course_code", returned_values[0], returned_values);

		//Delete the first element as course_code is no longer needed.
		returned_values.erase(returned_values.begin());
		*/

		database->keyword_search(column, "course", returned_values, false);

		strptr rows = new string[returned_values.size()];

		//Put the course codes into a dynamic array.
		for (size_t i = 0; i < returned_values.size(); i++)
		{
			
			rows[i] = returned_values[i];

		}

		//Allow user to choose course.
		choice = menu.create_menu("Please choose a course", rows, returned_values.size(), true);

		//Track how many course codes there are then remove them all.
		int course_codes = returned_values.size();
		returned_values.resize(0);

		//Search student_course table for rows matching the course code chosen.
		for (int i = 0; i < course_codes; i++) {
		
			database->sql_select("student_id", "student_course", "course_code", rows[i], returned_values);

		}

		delete[] rows;
		
		rows = new string[returned_values.size()];

		//Move the student ids into dynamic array.
		for(unsigned int i = 0; i < returned_values.size(); i++)
		{
		
			rows[i] = returned_values[i];
		
		}
		
		//Track how many student ids there are and then remove them all from vector.
		int student_ids= returned_values.size();
		returned_values.resize(0);

	//Search for all students that have the student_ids that have been found.
	for (shuint i = 0; i < student_ids; i++)
	{

		database->sql_select("*", "student", "student_id", rows[i], returned_values);

	}

	//Student details found, return to previous function.
	return;


}

void Student::search_student_by_address(Database^ database, vector<string> &returned_values)
{

	//User navigation input.
	string options[] =
	{

			"Return to Student Menu",
			"Search by Street Address",
			"Search by Town/City",
			"Search by Postcode"

	};

	int choice = menu.create_menu("How would you like to search for a student?", options, 4, true);
	menu.clear_screen();

	switch (choice)
	{

	case 0:

		//Return to 
		return;

		break;

	case 1://Inner^2
	{

		bool space_found = false, valid_address = false;
		string house_number, street;

		clear_inputstream();

		cout << "Please enter search term for the address first line" << endl;

		string street_address;
		getline(cin, street_address);

		bool is_number = true;

		//Go through entire string to check is a number has been entered.
		for (size_t i = 0; i < street_address.length(); i++)
		{

			//Check is the current digit is not a number and change the tracker.
			if (!(isdigit(street_address[i])))
				is_number = false;

		}


		if (is_number) 
		{

			database->sql_select("*", "student", "house_number", street_address, returned_values);
			
			return;

		}
		else 
		{

			database->keyword_search("street", "student", returned_values, true);

		}



	}

	break;

	case 2://Inner^2

		   //Search database for address l2.
		database->keyword_search("town_city", "student", returned_values, true);

		break;

	case 3://Inner^2

		   //Search database for postcode.
		database->keyword_search("postcode", "student", returned_values, true);

		break;

	}

	return;

}

void Student::search_student_by_name(Database^ database, vector<string> &returned_values)
{

	//User navigation input.
	string options[] =
	{

			"First Name",
			"Last Name"

	};

	int choice = menu.create_menu("Which name would you like to search using?", options, 2, true);
	menu.clear_screen();
	clear_inputstream();

	if (choice == 0)
	{

		//Search for first names.
		database->keyword_search("first_name", "student", returned_values, true);



	}
	else
	{

		//Search for last names.
		database->keyword_search("last_name", "student", returned_values, true);

	}


	return;

}

//Defaults keyword search to student table.
void Student::keyword_search(Database^ database, const string column, vector<string> &rows)
{

	//Perform a keyword search on student table.
	keyword_search(database, column, "student", rows);

	return;

}

string Student::find_student(Database^ database, const string student_id)
{

	vector<string> rows;

	//Perform a keyword search on student table.
	database->sql_select("*", "student", "student_id", student_id, rows);

	//Return the found student ID, there should only be one.
	return rows[0];

}

//Searches for keywords in a table in a certain column, returns each row matched.
void Student::keyword_search(Database^ database, const string column, const string table, vector<string> &rows)
{

	cout << "Press enter to continue..." << endl;

	clear_inputstream();

	//Get user input.
	cout << "\nPlease enter the term you would like to search" << endl;


	string key_term;
	getline(cin, key_term);

	cout << "You entered: " << key_term << endl;

	vector<string> comparison, full_details;

	//Perform keyword search.
	database->change_database("uni_database");
	database->perform_sql_action("SELECT " + column + " FROM student", comparison);
	database->perform_sql_action("SELECT * FROM student", full_details);

	for (size_t i = 0; i < comparison.size(); i++)
	{

		if (search_string(key_term, comparison[i]))
			rows.push_back(full_details[i]);

	}
			
	return;

}


bool Student::search_string(string key_term, string comparison) {

	//Check for strings that are too short, prevents stack overflow!
	if (key_term.length() <= 1) 
	{

		return false;

	}

	//Track when searches start.
	bool start_search = false;

	//Trackers, keyword index, matched and different chars.
	size_t j = 0, matches = 0, differences = 0;

	//Iterate through comparison string.
	for (size_t i = 0; i < comparison.length() && j < key_term.length(); i++)
	{

			//Look for matches.
			if (comparison[i] == key_term[j]) 
			{

				//Start the search...
				start_search = true;
				matches++;

			}

			//After finding at lease one match, start tracking differences.
			if (start_search && (comparison[i] != key_term[j]))
				differences++;

			//Increment key index to forward search.
			if (start_search)
				j++;

	}

	//If started search and matched, return true.
	if (start_search && (matches > differences))
	{
		
		return true;

	}
	//If started the search and not matched, return false.
	else if (start_search && (matches < differences)) 
	{
		
		return false;

	}
	//Otherwise, call function again with first keyword char removed.
	else
	{

		key_term.erase(0, 1);
		return search_string(key_term, comparison);

	}

	return "NO STUDENTS FOUND";

}

//Removes ';' and replaces them with " | ".
void Student::fix_delimiters(string &row)
{

	//Replace all ';' with " |".
	string insert_value = " |";

	//Go through entire string looking for delimiters.
	for (size_t i = 0; i < row.length(); i++)
	{

		if (row[i] == ';')
		{

			row[i] = ' ';
			row.insert(i, insert_value);

		}

	}

	return;

}

//Creates a new student using user input or many from a file specified.
void Student::new_student(Database^ database)
{

	menu.clear_screen();

	//Get navigation input from user.
	string options[] =
	{

			"Return to Student Menu",
			"Enter a new Student",
			"Add Students by File"

	};

	int choice = menu.create_menu("How would you like to enter students?", options, 3, true);

	switch (choice)
	{

	case 0:

		//Return to previous function.
		return;

		break;

	case 1:

		//Insert student values into database, not using file.
		insert_student_values(database);

		break;

	case 2:

		vector<string> temp;

		//Insert student values into database, using a file.
		insert_student_by_file(database, temp);

		temp.resize(0);

		break;

	}

	return;

}

void Student::insert_student_values(Database^ database)
{

	vector<string> column_names;

	//Add option for exiting choosing rows.
	column_names.push_back("Return to Student Menu");

	//Get the field headers from the database.
	get_table_fields(database, column_names);

	//Change back to the university database.
	database->change_database("uni_database");

	//There are two extra options being stored in this array.
	size_t extra_options = 2;
	///Manual Student Details Input

	//Minus 2 from size of columns vector size as it also contains a menu exit option and the student id which isn't added manually.
	strptr columns = new string[column_names.size() - extra_options];
	strptr values = new string[column_names.size() - extra_options];

	//Clear the input stream to allow for safe inputs.
	clear_inputstream();

	bool input_verified = false, verifying = false;

	size_t i = 0;

	//Data entry by user.
	while (!input_verified && i < column_names.size() - extra_options)
	{

		menu.clear_screen();

		//Remove semicolons and copy into string array.
		column_names[i + extra_options].erase(column_names[i + extra_options].end());
		columns[i] = column_names[i + extra_options];

		cout << "Press return(Enter) for an empty value" << endl;

		//Ask user for dates using the Date class.
		if (columns[i] == "date_of_birth" || columns[i] == "visa_expiry")
		{

			//Have the user input the date, pass database and column name to function.
			values[i] = input_date(database, columns[i]);

		}
		//Ask user for email address using an email entry function.
		else if (columns[i] == "email")
		{

			string email_address = input_email();

			values[i] = email_address;

		}
		//Otherwise, no stringent formatting is applied, allow standard entry.
		else
		{

			//Ask user for input at column.
			cout << "Please enter " << columns[i] << endl;

			getline(cin, values[i]);

		}//End Else

		//Check for values that are empty, user pressed return.
		if (values[i] == "\n")
		{

			values[i] = "";

		}

		//Spacing for readability.
		cout << "\n\n";
		



		if (i == column_names.size() - (extra_options + 1))
			verifying = true;

		//End of input section.

		//Increment index counter.
		i++;

		//Verify data entry from here.
		if (verifying)
		{

			//User is now verifying their input.
			
			strptr fields_and_values = new string[column_names.size() - 1];

			fields_and_values[0] = "All Inputs are correct";


			//Put each field together with each value for displaying.
			for (shuint j = 1; j < column_names.size() - 1; j++)
			{

				//Add strings together for displaying.
				fields_and_values[j] = columns[j - 1] + " - " + values[j - 1];

			}
			
			menu.clear_screen();

			cout << "Choose an entry to amend it" << endl;

			//Allow user verification.
			size_t choice = menu.create_menu("Please verify that all of your entries are correct", fields_and_values, column_names.size() - 1, true);

			

			delete[] fields_and_values;

			//Check whether user is satisfied with current data input.
			if (choice == 0)
				input_verified = true;
			else
				i = choice - 1;
				
			clear_inputstream();			

		}


		//If verifying input, go to last iteration if for loop again.
		if (verifying && input_verified)
		{

			cout << "Input Verified!" << endl;

			//Exit loop.
			i = column_names.size() - 2;
			break;

		}

	}//End While


	database->change_database("uni_database");

	database->sql_insert(columns, column_names.size() - 2, "student", values, column_names.size() - 2);

	cout << "\nValues: ";

	for (shuint i = 0; i < column_names.size() - 2; i++)
	{

		cout << values[i] << " | ";

	}

	cout << "\nInserted Respectively into: ";

	for (shuint i = 0; i < column_names.size() - 2; i++)
	{

		cout << column_names[i] << " | ";

	}


	return;

}//End Scope
void Student::insert_student_by_file(Database^ database, vector<string> &student_ids)
{

	vector<string> column_names;

	//Add option for exiting choosing rows.
	column_names.push_back("Return to Student Menu");

	//Get the field headers from the database.
	get_table_fields(database, column_names);

	//Change back to the university database.
	database->change_database("uni_database");



	//Dynamic array, element for each field, element for each value for that field.
	strptr values, columns;

	//File path and input_stream.
	string file_path;
	ifstream read_file;

	//Allocate sizes to dynamic arrays.
	columns = new string[column_names.size()];
	values = new string[column_names.size()];

	//The delimiter to be used, no default is assigned.
	char delimiter;

	clear_inputstream();

	//Prompt user for file path.
	cout << "Please enter file path (Use '/' in place of '\\'): " << endl;
	getline(cin, file_path);

	cout << "Press enter to continue..." << endl;

	clear_inputstream();

	//Prompt user for the delimiters used in the file.
	cout << "What character seperates the values in the file? (Delimiter)" << endl;
	cin >> delimiter;


	//Cycle through all fields. 
	for (shuint i = 0; i < column_names.size(); i++)
	{

		//Remove semicolons and copy into string array offset by +1.
		columns[i] = column_names[i];

	}



	//Dynamic array to hold choices based on how many fields are present.
	shuint file_fields = 0;
	shuint * choices = new shuint[column_names.size()];

	clear_inputstream();

	//Create a menu which shows the table fields.
	menu.create_menu("Please select the order of the fields in the file", columns, column_names.size(), false);
	
	cout << "Enter choices with spaces separating and terminate with a zero" << endl
		<< "You are not required to use all choices." << endl
		<< "For Example: \"3 4 2 1 0\"\n\n";



	//Get inputs from user specifyiing order of existing fields in file.
	do
	{

		string user_input;
		shuint choice = 0;


		//Ask user for choice.
		cin >> user_input;

		//Convert user input to integer.
		choice = stoi(user_input);

		//Condition for if choice is out of range.
		if ((choice >= column_names.size() || choice < 0) || isalpha(user_input[0]))
		{

			cout << "Incorrect Input " << user_input[0] << ", please try again from there." << endl;

		}
		else
		{

			choices[file_fields] = choice;

			//If first option is a zero, exit this operation.
			if (choices[0] == 0)
				return;

			//Exit condition.
			if (choices[file_fields] == 0)
				break;

			//Increment index counter.
			file_fields++;

		}

	} while (file_fields < column_names.size()); //Note: file_fields now tracks how many fields were chosen!


	string *current_columns = new string[file_fields];

	//Delete old dynamic array, no longer needed.
	delete[] columns;


	//Move column Names into a dynamic array.
	for (shuint i = 0; i < file_fields; i++)
	{

		current_columns[i] = column_names[choices[i]];

	}


	//Open the file specified by user.
	read_file.open(file_path, ios::beg);

	cout << "\n\n";

	//Read the entire file.
	while (!read_file.eof())
	{

		//String to hold file input.
		string file_input;

		//Read file until newline.
		getline(read_file, file_input);


		//Remove delimiters from file fields.
		for (shuint i = 0; i < file_fields; i++)
		{

			//Reset the value in dynamic array.
			values[i] = "";

			//Read string and insert values into dynamic array.
			for (size_t j = 0; j < file_input.length(); j++)
			{


				//Should a delimiter be found.
				if ((file_input[j] == delimiter) || (file_input[j] == '\n'))
				{

					//Erase the characters that have been taken from input.
					file_input.erase(0, j + 1);

					j = file_input.length();
					//Break from the current loop.
					break;

				}
				else
				{

					//Add the found character to the current value.
					values[i] += file_input[j];

				}

			}//End inner for [j]

			cout << "Value " << values[i] << " inserted into " << current_columns[i] << endl;

			//Push back student ids for other uses.
			if (current_columns[i] == "student_id")
				student_ids.push_back(values[i]);

		}//End outer for [i]

		bool inserted = false;

		do
		{

			//Insert each row after removing the delimiter.
			database->sql_insert(current_columns, file_fields, "student", values, file_fields);

			if (database->get_last_exception() > 0)
			{

				int id = stoi(values[0]) + 1;

				cout << "Student ID: " << id - 1 << " was a duplicate, trying: " << id << "..." << endl;

				values[0]  = to_string(id);
				inserted = false;
			}
			else
				inserted = true;

		} while (!inserted);

	}

	//Free memory to freestore.
	delete[] choices, current_columns;

	return;

}

string Student::choose_programme(Database^ database)
{

	database->change_database("uni_database");

	vector<string> programme_list;

	//Search for and return the names of all programmes.
	database->perform_sql_action("SELECT programme_id, programme_name FROM programme", programme_list);

	//Copy programmes into dynamic array.
	string *programme_ids = new string[programme_list.size()];

	for (shuint i = 0; i < programme_list.size(); i++)
	{

		programme_ids[i] = programme_list[i];

		fix_delimiters(programme_ids[i]);

	}

	//Ask user to choose a programme from the list of all programmes.
	int choice = menu.create_menu("Please select a programme", programme_ids, programme_list.size(), true);

	//No programmes exist, exit function.
	if (choice == -1)
		return "NO OPTIONS";

	//Done with the programme list vector now.
	programme_list.resize(0);

	//delimiter count.
	shuint delimiter = 0;

	//Read string until delimiter.
	while (programme_ids[choice].at(delimiter) != ' ')
		delimiter++;

	string programme;

	//Pass only programme id into return string.
	for (int i = 0; i < delimiter; i++)
		programme += programme_ids[choice][i];

	//Remove dynamic array.
	delete[] programme_ids;

	//return programme id.
	return programme;

}

string Student::input_date(Database^ database, string date_type)
{


	{//Start entry

		//clear_inputstream();


		bool date_incorrect = false;

		//Declare a local Date object and the system's current time.
		Date current_date, empty_date;

		current_date.set_to_current_date();
				
		//Verify DOB here, should be in the past by at least the minimum age.
		if (date_type == "date_of_birth")
			current_date.set_date(current_date.get_day(), current_date.get_month(), current_date.get_year() - minimum_student_age(database));

		do
		{

			//Ask user for input at column.
			cout << "Please enter " << date_type << "\n\n";

			string date_string;

			date.input_date();

			menu.clear_screen();
			
			//If nothing entered, return nothing.
			if (!date.is_entered())
			{

				return "";

			}
			else
			{


				//Check for valid data.
				if (((date_type == "date_of_birth") && (date < current_date)) || ((date_type == "visa_expiry") && (date > current_date)))
				{

					date_incorrect = false;

				}

				//Check whether the date of birth is in the past.
				if (date_type == "date_of_birth" && date >= current_date)
				{

					cout << "Date of Birth is incorrect!" << endl;

					date_incorrect = true;

				}
				//Check whether the visa expiry is valid.
				if (date_type == "visa_expiry" && date <= current_date)
				{

					cout << "Visa Expiry is today or it is in the past!" << endl;
					date_incorrect = true;

				}
			}



			//Clear input stream, date class leaves chars behind.
			clear_inputstream();

			cout << "The current date is: " << current_date.get_day() << '/' << current_date.get_month() << '/' << (current_date.get_year() + minimum_student_age(database)) << endl;
			cout << "Date entered: " << date.get_day() << '/' << date.get_month() << '/' << date.get_year() << endl;

		} while (date_incorrect);

		

	}//End entry

	string input_date;

	//Get the SQL format of the date string and return it.
	date.get_sql_date(input_date);

	return input_date;

}

string Student::get_student_id(Database^ database)
{

	//Change database back to uni_database.
	database->change_database("uni_database");

	//A list to store student information.
	vector<string> student_list;

	//Prompt user for method of finding student.
	string options[] =
	{

			"Return to Previous Menu",
			"Enter Student ID",
			"Search for a Student"

	};

	shuint choice = menu.create_menu("How would you like to find a student?", options, 3, true);

	if (choice == 0)
		return "EXIT";

	if (choice == 1)
	{

		//Boolean tracks when student was found.
		bool student_found = false;

		//Loop through until a student is found.
		do
		{

			//String for user input.
			string student_id;

			cout << "Enter a Student ID or type 'N' to return" << endl;
			cin >> student_id;

			//Find the student_id in the database.
			database->perform_sql_action("SELECT student_id FROM student WHERE student_id=\"" + student_id + "\"", student_list);

			//Check if a student was found or if exit condition, return from function.
			if (student_list.size() > 0)
				student_found = true;

			else if ((student_id[0] == 'N') || (student_id[0] == 'n'))
			{

				student_list.resize(0);
				return "NO STUDENTS FOUND";

			}
			else
			{

				cout << "No Students Found, Please try again" << endl;

			}


		} while (!student_found);

		//Return element containing student ID after displaying data.

		string student_details = get_student_details(database, student_list[0]);

		fix_delimiters(student_details);

		cout << "Student Found: " << endl << student_details << endl;

		return student_list[0];

	}



	//Search for a student by asking user for information.
	search_for_student(database, student_list);

	//Condition in which no students have been found.
	if (student_list.size() == 0)
		return "NO STUDENTS FOUND";

	//Put students into dynamic array.
	string *students = new string[student_list.size()];

	//For each student, only get the first few identification fields.
	for (shuint i = 0; i < student_list.size(); i++)
	{

		//Track delimiters and position in strings.
		shuint delimiter_count = 0, pos = 0;
		string student = "";

		//Find 4 fields.
		while (delimiter_count < 5)
		{

			//Add onto student string.
			student += student_list[i][pos];

			//Increment delimiter count if found.
			if (student_list[i][pos] == ';')
				delimiter_count++;

			//Increment position in string.
			pos++;
		}

		fix_delimiters(student);

		students[i] = student;

	}

	//Ask user to choose the student they would like to edit.
	choice = menu.create_menu("Please select a student", students, student_list.size(), true);

	//The student ID is the first field in the string.
	string chosen_student_id = students[choice].substr(0, students[choice].find(" |"));		//### MUST BE CHANGED IF USING DIFFERENT DELIMITER ###

	delete[] students;

	fix_delimiters(student_list[0]);

	cout << "Student Found: " << endl;
	cout << student_list[0] << endl;

	return chosen_student_id;

}

string Student::get_student_details(Database^ database, const string student_id)
{

	vector<string> student_details;

	database->sql_select("*", "student", "student_id", student_id, student_details);

	string all_details;

	for (shuint i = 0; i < student_details.size(); i++)
		all_details += student_details[i];
	
	if (all_details.size() == 0)
		all_details = "NO STUDENTS FOUND";

	return all_details;

}

string Student::input_email()
{

	//Booleans for tracking parts of the email address.
	bool found_at_symbol = false, found_domain_suffix = false, invalid_email = true;
	string email;

	//Loop through to ensure correct entry of email.
	do
	{

		cout << "Please enter e-mail address" << endl;

		getline(cin, email);

		menu.clear_screen();

		//ALlow user to not enter an email.
		if (email.length() == 0)
			return "";

		for (shuint i = 0; i < email.length(); i++)
		{

			//Firstly check that an '@' sign is found;
			if (email[i] == '@')
				found_at_symbol = true;

			//Next, check for a domain ('.' with string left over afterwards).
			if (found_at_symbol && (email[i] == '.') && (i < email.length() - 1))
				found_domain_suffix = true;

		}

		//If @ and domain suffix is invalid, ask again.
		if (found_at_symbol && found_domain_suffix)
			invalid_email = false;
		else
			cout << "\n\nEmail entered is invalid (For Example: \"email@address.com\")" << endl;


	} while (invalid_email);

	return email;

}

void Student::ammend_student(Database^ database)
{
	
	menu.clear_screen();

	//Find the student id that will be ammended.
	string chosen_student_id = get_student_id(database);


	//Should no students be found from search.
	if (chosen_student_id == "NO STUDENTS FOUND")
	{
	
		cout << "No Students Found!" << endl;

		return;

	}

	//Vector to store the fields.
	vector<string> table_fields;

	//Add option to Return to Student Menu as this vector is used for a menu.
	table_fields.push_back("Return to Student Menu");

	//Get the field headers for the student table.
	get_table_fields(database, table_fields);

	//Move fields into dynamic array.
	string* fields = new string[table_fields.size()];

	for (shuint i = 0; i < table_fields.size(); i++)
		fields[i] = table_fields[i];

	//Ask user which field for this student is to be edited.
	shuint choice = menu.create_menu("Please choose a field for editing", fields, table_fields.size(), true);

	if (choice == 0)
		return;

	string new_value;

	cout << "Press enter to continue..." << endl;
	clear_inputstream();

	//Perform checks for fields whose data has special requirements.
	if (fields[choice] == "email")
	{

		//Get email from user.
		new_value = input_email();

	}
	else if (fields[choice] == "date_of_birth" || fields[choice] == "visa_expiry")
	{

		
		//Get Date from user.
		new_value = input_date(database, fields[choice]);

	}
	else if (fields[choice] == "programme_name")
	{

		//Have user choose a programme from a list of programmes inside database.
		new_value = choose_programme(database);

	}
	else
	{

		//Ask user to enter new input.
		cout << "Press return(enter) to cancel entry" << endl
			<< "What new value would you like to insert?" << endl;

		getline(cin, new_value);

		//User has decided not to inser a value.
		if (new_value == "\n")
			return;

	}

	table_fields.resize(0);

	database->change_database("uni_database");
	database->sql_update(fields[choice], "student", new_value, "student_id", chosen_student_id);

	//Deallocate fields array.
	delete[] fields;

	return;

}

//This function uses the "INFORMATION_SCHEMA.COLUMNS" table to get the field headers for the student table.
void Student::get_table_fields(Database^ database, vector<string> &my_values)
{

	database->change_database("INFORMATION_SCHEMA");

	//Query the column names for the student table.
	database->perform_sql_action("SELECT COLUMN_NAME FROM COLUMNS WHERE TABLE_NAME=\"student\"", my_values);

	database->change_database("uni_database");

	return;

}

void Student::remove_student(Database^ database)
{
	
	menu.clear_screen();

	//Boolean to detect when student has been deleted.
	bool deleted = false;

	do
	{

		vector<string> columns;
		get_table_fields(database, columns);

		string all_columns;

		for (shuint i = 0; i < columns.size(); i++)
		{

			all_columns += columns[i];
			all_columns += " | ";
		}


		//Get the student ID to be deleted.
		string chosen_student_id = get_student_id(database);

		///If no student is found
		if (chosen_student_id == "NO STUDENTS FOUND")
		{

			cout << "No Students found!" << endl;

			shuint choice = menu.yes_no_menu("Would you like to try again?");

			if (choice == 0)
				return;

		}
		else
		{
			///If a student is found

			//Get the student information from the ID.
			string student_information = find_student(database, chosen_student_id);
			fix_delimiters(student_information);

			//Display student information.
			cout << "\n\nFields: " << all_columns << "\n\n";
			cout << "Student chosen: " << student_information << endl;

			//Allow for firm confirmation, ensure user is paying attention.
			cout << "\n\nAre you sure you would like to delete this student? This cannot be undone!" <<
				"\nPlease enter the student's student_id to confirm or 'N' to return\n\n";

			//Take user confirmation input.
			string confirmation;

			do
			{

				cin >> confirmation;

				//Allow for user to cancel this operation.
				if (confirmation == "N" || confirmation == "n")
					return;
				
				if (confirmation == chosen_student_id)
					break;
				else
					cout << "That ID is incorrect, please try again or press 'N' to exit." << endl;
				
			}
			while (confirmation != chosen_student_id);
			//If they have decided to go ahead


			//Make deleted true to exit loop.
			deleted = true;

			//Remove the student from the database.
			database->sql_delete("student", "student_id", chosen_student_id);
			
			cout << "Student Removed" << endl;

			return;

		}

	} while (!deleted);

	return;

}

void Student::clear_inputstream()
{

	//Clear input buffer and ignore all chars until a newline.
	cin.clear();
	cin.ignore(INT_MAX, '\n');

	return;

}

int Student::minimum_student_age(Database^ database)
{

	//Vector needed to store minimum age.
	vector<string> min_age;

	//Only a single age should be returned from a single record.
	database->sql_select("minimum_age", "uni_information", min_age);

	//Return the integer value in the minimum age.
	if ((min_age.size() == 0) || (!isdigit(min_age[0][0])))
		return 16;
	else
		return stoi(min_age[0]);

}


