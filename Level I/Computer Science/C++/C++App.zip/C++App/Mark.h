// Created by Callum Owen-Bridge (15002504) latest version 22/03/2017
#pragma once
#include "Database.h"
#include "Student.h"
#include "Menu.h"
#include <iostream>
#include <string>
#include <vector>
#include <numeric>
#include <cstring>
#include <stdlib.h>

using namespace std;
using namespace Database_Application;

// inheritance, inherits student class
class Mark : public Student
{
public:

	Mark();

	// preconditon: a menu of options, requires database instance to be initailised
	//postcondition: opens a menu of options for mark 
	void mark_menu(Database^ database);

	// preconditon: collects student id and course code to get mark, requires database instance to be initailised
	//postcondition: displays students course mark
	void course_Mark(Database^ db);

	// preconditon: collects student id and course codes to find mark, requires database instance to be initailised
	//postcondition: displays students level mark
	void total_level_Mark(Database^ db);

	// preconditon: collects assesment id and student id to calculate mark , requires database instance to be initailised
	//postcondition: adds an assesment mark for a particular course assement id and student id
	void add_assessment_Mark(Database^ db);

	// preconditon:collects student id and assessment id to find assessment mark, requires database instance to be initailised
	//postcondition: views a students assessment mark
	void view_assessment_Mark(Database^ db);

	// preconditon: collects new mark and converts value to grade result , requires database instance to be initailised
	//postcondition: alters the mark, result, attempt, grade
	void amend_assessment_Mark(Database^ db);

	// preconditon: takes an integer value and returns a string
	//postcondition: takes an integer value and converts it to a grade value and returns the value as a string
	string grade(const int mark);

	// preconditon: takes an integer value and returns a string 
	//postcondition: takes an integer value and converts it to pass or fail and returns this value as a string
	string result(const int mark);
	
private:
	Menu menu;
	Student student;

	void clear_inputstream();
	void input_checker(string inputs[]);
	void input_checker(string &input);
	int  remove_concessional_code(string& input);
	int  remove_concessional_code(vector<string> input);
};

