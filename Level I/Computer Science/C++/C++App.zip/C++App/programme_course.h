// Created by Callum Owen-Bridge (15002504) latest version 22/03/2017
#pragma once
#include "Database.h"
#include "Student.h"
#include "Menu.h"
#include "Date.h"
#include <iostream>
#include <string>
#include <vector>
#include <numeric>
#include <cstring>
#include <stdlib.h>

using namespace std;
using namespace Database_Application;

class Programme_course
{
public:

	Programme_course();

	// preconditon:menu for programme course, requires database instance to be initailised
	//postcondition:displays a menu of options fro programme course
	void programmeCourse_menu(Database^ db);

	// preconditon: collects data from user about course codes and programme, requires database instance to be initailised
	//postcondition: adds courses to a programme including a research task at level h 
	void add_ProgrammeCourse(Database^ db);

	// preconditon:collects data about a programme , requires database instance to be initailised
	//postcondition: allows the user to alter the courses on a programme and thier end and begin years
	void amend_ProgrammeCourse(Database^ db);

	// preconditon: collects data about a programme, requires database instance to be initailised
	//postcondition: displays courses and associated information on a programme for the user to see, such as course code, begin and end years
	void view_programmeCourse(Database^ db);

private:
	Menu menu;
	Date date;
	void clear_inputstream();
	void input_checker(string inputs[]);
	void input_checker(string &input);

};