// Created by Callum Owen-Bridge (15002504) latest version 22/03/2017
#include "Student_Course.h"

Student_Course::Student_Course() {}

// menu for student course
void Student_Course::Student_Course_menu(Database^ db) {

	string options[] = { "Return to Main Menu", "Enrol a student", "Enrol many students (by enetring a file","Remove a student from a course", "Remove many students from a course", "View what a student courses a student is enrolled on", "View which students are enrolled on a course" };

	int choice = 1;
	while (choice > 0) {
		//Database to be passed around as needed.
		choice = menu.create_menu("Please choose an option", options, 7, true);

		switch (choice) {

		case 0:

			return;

			break;

		case 1:

			enrol_student(db);

			break;

		case 2:

			enrol_Many_students(db);

			break;

		case 3:

			remove_student(db);

			break;

		case 4:

			remove_Many_students(db);

			break;
		case 5:

			view_student_courses(db);

			break;
		case 6:

			view_students_enrolled_OnCourse(db);

			break;

		}

	}
}

// function to enrol student overloaded
void Student_Course::enrol_student(Database^ db, string student_id, string course_code, string attempt) {

	db->perform_sql_action("INSERT INTO student_course (student_id, course_code, enrolment_date, attempt) VALUES (" + student_id + ", \"" + course_code + "\", now(), " + attempt + ")");

	vector<string> assessment_ids;
	db->sql_select("assessment_id", "course_assessment", "course_code", course_code, assessment_ids);

	// tells user that the value does not exist in database
	if (assessment_ids.size() == 0)
	{
		cout << "No assessments found for that course code" << endl;
		return;
	}

	// inserts students into database
	for (unsigned int i = 0; i < assessment_ids.size(); i++)
		db->perform_sql_action("INSERT INTO student_assessment (student_id, assessment_id) VALUES (\"" + student_id + "\", \"" + assessment_ids[i] + "\")");

}

// function to enrol student
void Student_Course::enrol_student(Database^ db) {
	string student_id, course_code, attempt, value[4], columns[4] = { "student_id", "course_code", "attempt", "enrolment_date"}, columns2[2] = { "student_id", "assessment_id" }, dates;
	vector<string> course_name, assessment_ids;
	bool loop = true;

	menu.clear_screen();
	//allows user to execute function again
	do {
		
		clear_inputstream();
		cout << "Please enter the course code you would like to enrol a student on" << endl;
		cin >> course_code;

		db->sql_select("course_name", "course", "course_code", course_code, course_name);

		// tells user that the value does not exist in database
		if (course_name.size() == 0)
		{
			cout << "no courses found for this course code" << endl;
			return;
		}

		cout << "Here is the course name for "<<course_code<<"   "<<course_name[0] << endl;
		input_checker(course_code);

		cout << "Which student would you like to enrol onto: " << course_name[0] << endl;
		student_id = get_student_id(db);

		value[0] = course_code;
		value[1] = student_id;

		// asks user whether it is the first attempt made by student
		if (menu.yes_no_menu("Is this the first attempt of the course by the student ?"))
			value[2] = attempt = "1";

		else
		{
			cout << "What attempt will this be ? (enter an integer value more than 1)" << endl;
			clear_inputstream();
			cin >> attempt;
			input_checker(attempt);
			value[2] = attempt;
		}

	    date.get_sql_date(dates);
		value[3] = dates;

		// asks user if values are correct before enerting into database
		if (menu.yes_no_menu("Would you like to enrol student id:  " + student_id + "  onto course code:  " + course_code + " on date: " + dates + " With attempt: " + attempt))
		{

			enrol_student(db, student_id, course_code, attempt);

			cout << "Student enrolled" << endl;
		}
		
	}while (menu.yes_no_menu("Would you like to enrol another student? "));
	return;
}

// function to enrol a batch of students
void Student_Course::enrol_Many_students(Database^ db) {
	string student_id, course_name, attempt, columns[4] = {"student_id", "course_code", "attempt", "enrolment_date" }, dates, file_name, value[4];
	ifstream in_stream;
	vector<string> course;
	char delimeter;

	menu.clear_screen();

	//allows user to execute function again
	do {
		
		string course_code;
		cout << "Please enter the course code you would like to enrol these students onto" << endl;
		cin >> course_code;

		vector<string> ids;
		insert_student_by_file(db, ids);

		//inserts students into database
		for (unsigned int i = 0; i < ids.size(); i++)
			db->perform_sql_action("INSERT INTO student_course (student_id, course_code, enrolment_date) VALUES (" + ids[i] + ", " + course_code + ", now())");

		// closes file stream
		in_stream.close();

	} while (menu.yes_no_menu("Would you like to enrol another batch of students onto a course? "));
	return;
}

// function to remove student from course
void Student_Course::remove_student(Database^ db) {
	string student_id, course_code;
	bool loop = true;
	vector<string> course_name;

	menu.clear_screen();

	//allows user to execute function again
	do {
		// allows user to find correct course
		do {

			clear_inputstream();
			cout << "Please enter the course code you would like to remove a student from" << endl; 
			cin >> course_code;

			db->sql_select("course_name", "course", "course_code", course_code, course_name);

			if (course_name.size() == 0)
			{
				cout << "no courses found for that course code" << endl;
				return;
			}

			cout << "Here is the course name for " << course_code << "   " << course_name[0] << endl;
			input_checker(course_code);

		} while (!menu.yes_no_menu("Is this the correct course ? "));

		cout << "Which student would you like to remove from the course: " << course_name[0] << endl;
		student_id=get_student_id(db);

		// tells user that the value does not exist in database
		if (student_id == "NO STUDENTS FOUND")
		{
			cout << "No students found" << endl;
			return;
		}

		// asks user if values are correct before deleting
		if (menu.yes_no_menu("Would you like to remove student:  " + student_id + "  from course:  " + course_name[0]))
		{
			db->perform_sql_action("DELETE FROM student_course WHERE course_code =\"" + course_code + "\" AND student_id = " + student_id);

			cout << "Student removed" << endl;

			if (!menu.yes_no_menu("Would you like to enrol another student? "))
				break;
		}

		else
			cout << "Function restarting" << endl;
		
	} while (loop);
	return;
}

// function to remove many students from course
void Student_Course::remove_Many_students(Database^ db) {
	string student_id, course_code, columns[3] = { "student_id", "course_code", "attendance_mode" }, file_name, value[3];
	ifstream in_stream;
	int column;
	bool loop = true, loop2 = true;
	vector<string> course;
	char delimeter;

	menu.clear_screen();

	//allows user to execute function again
	do {
		
		clear_inputstream();
		cout << "Please enter the name of the file of students you would like remove ( for example file.txt ) " << endl;
		cin >> file_name;
		input_checker(file_name);

		cout << "What delimeter is used to separate values in the file ( for example ;)" << endl;
		cin >> delimeter;

		cout << "Is course code in column 1 or 2 of the text file? ( enter 1 or 2) \n " 
			<<"For example:  course code, student ID   or    student ID, course code "<< endl;
		cin >> column;

		in_stream.open(file_name);

		// tells user that file failed to open
		if (in_stream.fail())
		{
			cout << " Input file opening failed." << endl;
			return;
		}

		// loop deletes students until end of file stream
		while (!in_stream.eof())
		{

			for (int i = 0; i<4; i++)
			{
				getline(in_stream, value[i], delimeter);
			}

			cout << endl;

			if(column==1)
				db->perform_sql_action("DELETE FROM student_course WHERE course_code =\"" + course_code + "\" AND student_id = " + student_id );
			else
				db->perform_sql_action("DELETE FROM student_course WHERE  student_id =" + student_id + " AND course_code = \"" + course_code+ "\"");

		}
		in_stream.close();
	} while (menu.yes_no_menu("Would you like to remove another batch of students onpt a course? "));
	
	return;
}

// view courses a students is enrolled on
void Student_Course::view_student_courses(Database^ db) {
	string student_id, course_code, result, pass;
	vector<string>courses, course_name, attempt, latest_result, enrolment_date;
	bool loop = true;

	menu.clear_screen();

	// do while allows users to execute function again
	do {
	
		cout << "Which student's courses list would you like to view?" << endl;
		student_id=get_student_id(db);

		// tells user that the value does not exist in database
		if (student_id == "NO STUDENTS FOUND")
		{
			cout << "No students found" << endl;
			return;
		}

		input_checker(student_id);

		db->perform_sql_action("SELECT course_code FROM student_course WHERE  student_id =\"" + student_id + '\"', courses);

		// tells user that the value does not exist in database
		if (courses.size() == 0)
		{
			cout << "no courses found for that student id" << endl;
			return;
		}

		// evaluates to true if there are more than one course
		if (courses.size() > 1) 
		{
			db->sql_select("course_name", "course", "course_code", courses[0], course_name);

			// tells user that the value does not exist in database
			if (course_name.size() == 0)
			{
				cout << "no courses found for that course code" << endl;
				return;
			}

			db->sql_select("course_name", "course", "course_code", courses[1], course_name);

			// tells user that the value does not exist in database
			if (course_name.size() == 0)
			{
				cout << "no courses found for that course code" << endl;
				return;
			}

			cout << "Student:  " << student_id << "  Course:  " << courses[0]<< "   " << course_name[0] << "  Course 2: " << courses[1] << "   " << course_name[1] << endl;
		}

		// occurs if there is only one course
		if (courses.size() == 1)
		{
			cout << "Student:  " << student_id << "  Course:  " << courses[0] << endl;

			db->sql_select("course_name", "course", "course_code", courses[0], course_name);

			// tells user that the value does not exist in database
			if (course_name.size() == 0)
			{
				cout << "no courses found for that course code" << endl;
				return;
			}
		}


		if (menu.yes_no_menu("Would you like to view a student's course"))
		{

			clear_inputstream();
			cout << "Please enter the course code you would like to view" << endl;
			cin >> course_code;
			input_checker(course_code);

			db->sql_select("course_name", "course", "course_code", course_code, course_name);

			// tells user that the value does not exist in database
			if (course_name.size() == 0)
			{
				cout << "no courses found for that course code" << endl;
				return;
			}

			db->perform_sql_action("SELECT attempt FROM student_course WHERE  student_id =" + student_id  + " AND course_code =\"" + course_code+"\"", attempt);

			// tells user that the value does not exist in database
			if (attempt.size() == 0)
			{
				cout << "no courses found for that student" << endl;
				return;
			}

			db->perform_sql_action("SELECT latest_result FROM student_course WHERE  student_id =" + student_id  + " AND course_code =\"" + course_code + "\"", latest_result);
		
			// tells user that the value does not exist in database
			if (latest_result.size() == 0)
			{
				cout << "no courses found for that student" << endl;
				return;
			}

			db->perform_sql_action("SELECT enrolment_date FROM student_course WHERE  student_id =" + student_id  + " AND course_code =\"" + course_code + "\"", enrolment_date);

			// tells user that the value does not exist in database
			if (enrolment_date.size() == 0)
			{
				cout << "no courses found for that student" << endl;
				return;
			}
			
			if (latest_result[0] =="1")
				result = "pass";
			else
				result = "fail";

			cout << "Here is the course name for " << course_name[0] <<"  Attempt: "<< attempt[0]<<" Result: "<< result <<" Enrolement date: "<< enrolment_date[0] << endl;

			
		}

	}while (menu.yes_no_menu("Would you like to view another student's course list"));
	return;
}

// view students on a course
void Student_Course::view_students_enrolled_OnCourse(Database^ db) {
	string student_id, course_code;
	int amount;
	vector<string>students, course_name;
	bool loop = true;

	menu.clear_screen();

	do {

		clear_inputstream();
		cout << "Which course would you like to view for students enrolled?" << endl;
		cin >> course_code;

		db->sql_select("course_name", "course", "course_code", course_code, course_name);

		// tells user that the value does not exist in database
		if (course_name.size() == 0)
		{
			cout << "no courses found for that course code" << endl;
			return;
		}

		cout << "Here is the course name for " << course_code << "   " << course_name[0] << endl;
		input_checker(course_code);

		db->perform_sql_action("SELECT student_id FROM student_course WHERE  course_code =\"" + course_code + '\"', students);

		// tells user that the value does not exist in database
		if (students.size() == 0)
		{
			cout << "no students found for that course code" << endl;
			return;
		}

		cout << " Here are all the student ids enrolled on:  " << course_code<< "   "<< course_name[0] << endl;
		amount = students.size();

		for (int i = 0; i < amount; i++) {
			cout << "Student id:  " << students[i] << endl;
		}


	} while (menu.yes_no_menu("Would you like to view another course for enrolled students ?"));
	return;
}


//  input checker function allows user to re enter value
void Student_Course::input_checker(string inputs[]) {
	bool result = false;

	//do-while loops until the value is correct
	do
	{

		for (int i = 0; i < sizeof(inputs); i++)
			cout << "Value entered: " << inputs[i] << endl;

		if (menu.yes_no_menu("Are the above values correct "))
			result = true;

		else {
			clear_inputstream();
			cout << "Please re-enter both values" << endl;
			for (int i = 0; i < sizeof(inputs); i++)
			{
				clear_inputstream();
				getline(cin, inputs[i]);
			}
		}
	} while (!result);
}

//  input checker function allows user to re enter value
void Student_Course::input_checker(string& input) {
	bool result = false;

	//do-while loops until the value is correct
	do
	{
		cout << "Value entered:  " << input << endl;

		if (menu.yes_no_menu("Are the above values correct "))
			result = true;

		else
		{
			clear_inputstream();
			cout << "Please re-enter value " << endl;
			getline(cin, input);
		}
	} while (!result);
}

// clears the input stream
void Student_Course::clear_inputstream() {
	//Clear input buffer and ignore all chars until a newline.
	cin.clear();
	cin.ignore(INT_MAX, '\n');
}