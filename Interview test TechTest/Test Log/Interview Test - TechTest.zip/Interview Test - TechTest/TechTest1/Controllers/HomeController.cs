﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TechTest1.Models;

namespace TechTest1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        // Update person view 
        public ActionResult UpdatePerson()
        {
            return View();
        }

        // gathers person data from database
        public JsonResult GetAllPeople()
        {
            TechTestEntities obj = new TechTestEntities();
            var persons = obj.People.Select(x => new
            {
                personId = x.PersonId,
                firstName = x.FirstName,
                lastName = x.LastName,
                Authorised = x.IsAuthorised,
                Enabled = x.IsEnabled
                

            }).ToList();

            return Json(persons, JsonRequestBehavior.AllowGet);
        }

        // gathers colour data from database
        public JsonResult GetColours()
        {
            TechTestEntities obj = new TechTestEntities();
            var Colour = obj.Colours.Select(y => new
            {
                colourId = y.ColourId,
                colourName = y.Name
            }).ToList();

            return Json(Colour, JsonRequestBehavior.AllowGet);
        }


        //gathers favourite colour data from database
        /*public JsonResult GetFavouriteColours()
        {
            TechTestEntities obj = new TechTestEntities();
            var FavouriteColour = obj.FavouriteColours.Select(y => new
            {
                personId = y.ColourId,
                colourName = y.Name
            }).ToList();

            return Json(FavouriteColour, JsonRequestBehavior.AllowGet);
        }*/
    }
}