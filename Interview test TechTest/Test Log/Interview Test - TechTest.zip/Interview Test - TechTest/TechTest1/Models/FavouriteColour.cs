﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechTest1.Models
{
    public class FavouriteColour
    {
        public string ColourId { get; set; }
        public string PersonId { get; set; }
    }
}