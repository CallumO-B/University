﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechTest1.Models
{
    public class People
    {
        public string PersonId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string IsAuthorised { get; set; }
        public string IsEnabled { get; set; }
    }
}