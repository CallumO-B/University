﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechTest1.Models
{
    public class Colour
    {
        public string Name { get; set; }
        public string ColourId { get; set; }
    }
}